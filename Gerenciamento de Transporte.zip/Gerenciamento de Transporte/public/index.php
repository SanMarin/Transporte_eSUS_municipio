<?php
require_once '../config/database_transp.php';
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

// Obter estatísticas para o dashboard
$conn = connectMySQL();

// Total de viagens
$result = $conn->query("SELECT COUNT(*) as total FROM trips");
$totalTrips = $result->fetch_assoc()['total'];

// Viagens agendadas
$result = $conn->query("SELECT COUNT(*) as total FROM trips WHERE status = 'scheduled'");
$scheduledTrips = $result->fetch_assoc()['total'];

// Total de pacientes
$result = $conn->query("SELECT COUNT(*) as total FROM patients");
$totalPatients = $result->fetch_assoc()['total'];

// Total de veículos
$result = $conn->query("SELECT COUNT(*) as total FROM vehicles");
$totalVehicles = $result->fetch_assoc()['total'];

// Próximas viagens
$result = $conn->query("
    SELECT t.id, t.trip_date, t.departure_time, l.name as location_name, v.plate, d.name as driver_name,
           (SELECT COUNT(*) FROM trip_passengers WHERE trip_id = t.id) as passenger_count
    FROM trips t
    JOIN locations l ON t.location_id = l.id
    JOIN vehicles v ON t.vehicle_id = v.id
    JOIN drivers d ON t.driver_id = d.id
    WHERE t.status = 'scheduled'
    ORDER BY t.trip_date, t.departure_time
    LIMIT 5
");
$upcomingTrips = $result->fetch_all(MYSQLI_ASSOC);

// Viagens recentes
$result = $conn->query("
    SELECT t.id, t.trip_date, l.name as location_name, v.plate, d.name as driver_name,
           (SELECT COUNT(*) FROM trip_passengers WHERE trip_id = t.id) as passenger_count
    FROM trips t
    JOIN locations l ON t.location_id = l.id
    JOIN vehicles v ON t.vehicle_id = v.id
    JOIN drivers d ON t.driver_id = d.id
    WHERE t.status = 'completed'
    ORDER BY t.trip_date DESC
    LIMIT 5
");
$recentTrips = $result->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <a href="trips.php?action=add" class="btn btn-sm btn-outline-primary">
                <i class="fas fa-plus me-1"></i> Nova Viagem
            </a>
            <a href="" class="btn btn-sm btn-outline-secondary">
                <i class="fas fa-file-export me-1"></i> Gerar BPA-I
            </a>
        </div>
    </div>
</div>

<!-- Cards de estatísticas -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2 card-dashboard">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total de Viagens</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalTrips ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-route fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2 card-dashboard">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Viagens Agendadas</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $scheduledTrips ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2 card-dashboard">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Total de Pacientes</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalPatients ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2 card-dashboard">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Total de Veículos</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalVehicles ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-car fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Próximas viagens e viagens recentes -->
<div class="row">
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Próximas Viagens</h6>
                <a href="trips.php" class="btn btn-sm btn-primary">
                    Ver Todas
                </a>
            </div>
            <div class="card-body">
                <?php if (count($upcomingTrips) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Destino</th>
                                    <th>Veículo</th>
                                    <th>Passageiros</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($upcomingTrips as $trip): ?>
                                    <tr>
                                        <td><?= date('d/m/Y', strtotime($trip['trip_date'])) ?> às <?= date('H:i', strtotime($trip['departure_time'])) ?></td>
                                        <td><?= htmlspecialchars($trip['location_name']) ?></td>
                                        <td><?= htmlspecialchars($trip['plate']) ?></td>
                                        <td><?= $trip['passenger_count'] ?></td>
                                        <td>
                                            <a href="trips.php?action=view&id=<?= $trip['id'] ?>" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Visualizar">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-center">Não há viagens agendadas.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Viagens Recentes</h6>
                <a href="trips.php?status=completed" class="btn btn-sm btn-primary">
                    Ver Todas
                </a>
            </div>
            <div class="card-body">
                <?php if (count($recentTrips) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Destino</th>
                                    <th>Motorista</th>
                                    <th>Passageiros</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentTrips as $trip): ?>
                                    <tr>
                                        <td><?= date('d/m/Y', strtotime($trip['trip_date'])) ?></td>
                                        <td><?= htmlspecialchars($trip['location_name']) ?></td>
                                        <td><?= htmlspecialchars($trip['driver_name']) ?></td>
                                        <td><?= $trip['passenger_count'] ?></td>
                                        <td>
                                            <a href="trips.php?action=view&id=<?= $trip['id'] ?>" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Visualizar">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-center">Não há viagens recentes.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
