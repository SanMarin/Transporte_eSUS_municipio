<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

require_once '../config/database_transp.php';
require_once '../tcpdf/tcpdf.php';

if (!isset($_GET['days'])) {
    die('Dias não especificados.');
}

$days = array_filter(explode(',', $_GET['days']));
if (empty($days)) {
    die('Nenhum dia selecionado para gerar o PDF.');
}

$conn = connectMySQL();

// Criar PDF
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
$pdf->SetCreator('Sistema de Transporte BPA');
$pdf->SetAuthor('Sistema de Transporte BPA');
$pdf->SetTitle('Relatório de Viagens');
$pdf->SetMargins(12, 12, 12);
$pdf->SetAutoPageBreak(TRUE, 12);
$pdf->AddPage();

// Cabeçalho do relatório
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(0, 10, 'Relatório de Viagens - Ipaussu', 0, 1, 'C');
$pdf->Ln(5);

foreach ($days as $day) {
    $pdf->SetFont('helvetica', 'B', 13);
    $pdf->SetFillColor(200, 220, 255);
    $pdf->Cell(0, 8, 'Data: ' . date('d/m/Y', strtotime($day)), 0, 1, 'L', true);
    $pdf->Ln(3);

    $stmt = $conn->prepare("
        SELECT t.id, t.trip_date, t.departure_time, t.status,
               v.plate, v.model, v.brand,
               d.name as driver_name,
               t.city as destination,
               (SELECT COUNT(*) FROM trip_passengers WHERE trip_id = t.id) as passenger_count
        FROM trips t
        JOIN vehicles v ON t.vehicle_id = v.id
        JOIN drivers d ON t.driver_id = d.id
        WHERE t.trip_date = ?
        ORDER BY t.departure_time
    ");
    $stmt->bind_param("s", $day);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $pdf->SetFont('helvetica', '', 11);
        $pdf->Cell(0, 6, 'Nenhuma viagem encontrada.', 0, 1);
        $pdf->Ln(3);
        continue;
    }

    while ($trip = $result->fetch_assoc()) {
        // --- Estimar altura aproximada da viagem para ver se cabe na página ---
        $pdf->startTransaction();
        $yStart = $pdf->GetY();

        // Bloco da viagem
        $pdf->SetFont('helvetica', 'B', 13);
        $pdf->SetFillColor(200, 220, 255);
        $pdf->Cell(0, 8, 'Viagem #' .  $trip['id'] . ' - Data: ' . date('d/m/Y', strtotime($day)). ' -  Destino: ' . $trip['destination'] . ' - Saída: ' . date('H:i', strtotime($trip['departure_time'])), 0, 1, 'L', true);
        $pdf->Ln(2);

        $pdf->SetFont('helvetica', '', 10);
        $html = '
        <table border="0" cellpadding="4">
            <tr>
                <td width="50%"><b>Veículo:</b></td>
                <td>'.$trip['plate'].' - '.$trip['model'].' '.$trip['brand'].'</td>
            </tr>
            <tr>
                <td><b>Motorista:</b></td>
                <td>'.$trip['driver_name'].'</td>
            </tr>
            <tr>
                <td><b>Total Passageiros:</b></td>
                <td>'.$trip['passenger_count'].'</td>
            </tr>
        </table>';
        $pdf->writeHTML($html, false, false, false, false, '');

        // Passageiros
        $passenger_stmt = $conn->prepare("
            SELECT p.name, tp.appointment_time
            FROM trip_passengers tp
            JOIN patients p ON tp.patient_id = p.id
            WHERE tp.trip_id = ?
            ORDER BY tp.appointment_time ASC, p.name ASC
        ");
        $passenger_stmt->bind_param("i", $trip['id']);
        $passenger_stmt->execute();
        $passenger_result = $passenger_stmt->get_result();

        if ($passenger_result->num_rows > 0) {
            $pdf->SetFont('helvetica', 'B', 10);
            $pdf->Ln(2);
            $pdf->Cell(0, 6, 'Passageiros:', 0, 1);

            $pdf->SetFont('helvetica', '', 9);

            // Montar tabela em duas colunas
            $html_pass = '<table border="1" cellpadding="3" cellspacing="0" width="100%"><tr>';
            $col = 0;

            while ($p = $passenger_result->fetch_assoc()) {
                $hora = $p['appointment_time'] ? ' (' . date('H:i', strtotime($p['appointment_time'])) . ')' : '';
                $html_pass .= '<td width="50%">'.htmlspecialchars($p['name']).$hora.'</td>';
                $col++;
                if ($col == 2) {
                    $html_pass .= '</tr><tr>';
                    $col = 0;
                }
            }

            if ($col == 1) {
                $html_pass .= '<td width="50%"></td></tr>';
            } else {
                $html_pass = preg_replace('/<tr>$/', '', $html_pass);
            }

            $html_pass .= '</table>';

            $pdf->writeHTML($html_pass, false, false, false, false, '');
        }

        $pdf->Ln(5);

        // --- Ajuste final para quebrar página apenas quando necessário ---
        $currentY = $pdf->GetY();
        $pageHeight = $pdf->getPageHeight() - $pdf->getBreakMargin(); // 12 mm de margem inferior
        if ($currentY > $pageHeight) {
            $pdf->rollbackTransaction(true); // descarta escrita parcial
            $pdf->AddPage();              // nova página
            $pdf->writeHTML($html, false, false, false, false, ''); // escreve viagem inteira
        } else {
            $pdf->commitTransaction();
        }
    }
}

$conn->close();
$pdf->Output('relatorio_viagens_' . date('Y-m-d') . '.pdf', 'I');
?>
