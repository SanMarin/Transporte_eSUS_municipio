<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Adicionar novo veículo
        if ($_POST['action'] === 'add') {
            $plate = $_POST['plate'];
            $model = $_POST['model'];
            $brand = $_POST['brand'];
            $year = $_POST['year'];
            $capacity = $_POST['capacity'];
            $active = isset($_POST['active']) ? 1 : 0;
            
            $stmt = $conn->prepare("
                INSERT INTO vehicles (plate, model, brand, year, capacity, active)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("sssiii", $plate, $model, $brand, $year, $capacity, $active);
            
            if ($stmt->execute()) {
                $message = "Veículo adicionado com sucesso.";
            } else {
                $error = "Erro ao adicionar veículo: " . $conn->error;
            }
            $stmt->close();
        }
        // Editar veículo
        else if ($_POST['action'] === 'edit' && isset($_POST['id'])) {
            $id = $_POST['id'];
            $plate = $_POST['plate'];
            $model = $_POST['model'];
            $brand = $_POST['brand'];
            $year = $_POST['year'];
            $capacity = $_POST['capacity'];
            $active = isset($_POST['active']) ? 1 : 0;
            
            $stmt = $conn->prepare("
                UPDATE vehicles 
                SET plate = ?, model = ?, brand = ?, year = ?, capacity = ?, active = ?
                WHERE id = ?
            ");
            $stmt->bind_param("sssiiii", $plate, $model, $brand, $year, $capacity, $active, $id);
            
            if ($stmt->execute()) {
                $message = "Veículo atualizado com sucesso.";
            } else {
                $error = "Erro ao atualizar veículo: " . $conn->error;
            }
            $stmt->close();
        }
        // Excluir veículo
        else if ($_POST['action'] === 'delete' && isset($_POST['id'])) {
            $id = $_POST['id'];
            
            // Verificar se o veículo está em alguma viagem
            $check = $conn->prepare("SELECT COUNT(*) as count FROM trips WHERE vehicle_id = ?");
            $check->bind_param("i", $id);
            $check->execute();
            $result = $check->get_result();
            $count = $result->fetch_assoc()['count'];
            
            if ($count > 0) {
                $error = "Não é possível excluir este veículo pois ele está associado a viagens.";
            } else {
                $stmt = $conn->prepare("DELETE FROM vehicles WHERE id = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $message = "Veículo excluído com sucesso.";
                } else {
                    $error = "Erro ao excluir veículo: " . $conn->error;
                }
                $stmt->close();
            }
        }
    }
}

// Definir ação
$action = $_GET['action'] ?? 'list';
$vehicle_id = $_GET['id'] ?? null;

// Obter dados para formulários
if ($action === 'edit' && $vehicle_id) {
    $stmt = $conn->prepare("SELECT * FROM vehicles WHERE id = ?");
    $stmt->bind_param("i", $vehicle_id);
    $stmt->execute();
    $vehicle = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$vehicle) {
        $error = "Veículo não encontrado.";
        $action = 'list';
    }
}

// Listar veículos
if ($action === 'list') {
    $result = $conn->query("SELECT * FROM vehicles ORDER BY plate");
    $vehicles = $result->fetch_all(MYSQLI_ASSOC);
}

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <?php if ($action === 'add'): ?>
            <i class="fas fa-plus-circle me-2"></i>Novo Veículo
        <?php elseif ($action === 'edit'): ?>
            <i class="fas fa-edit me-2"></i>Editar Veículo
        <?php else: ?>
            <i class="fas fa-car me-2"></i>Gerenciamento de Veículos
        <?php endif; ?>
    </h1>
    
    <?php if ($action === 'list'): ?>
        <a href="?action=add" class="btn btn-sm btn-success">
            <i class="fas fa-plus me-1"></i> Novo Veículo
        </a>
    <?php else: ?>
        <a href="vehicles.php" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    <?php endif; ?>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($action === 'add' || $action === 'edit'): ?>
    <!-- Formulário de Veículo -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <?= $action === 'add' ? 'Novo Veículo' : 'Editar Veículo' ?>
            </h6>
        </div>
        <div class="card-body">
            <form method="post" action="vehicles.php">
                <input type="hidden" name="action" value="<?= $action ?>">
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="id" value="<?= $vehicle['id'] ?>">
                <?php endif; ?>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="plate" class="form-label">Placa*</label>
                        <input type="text" class="form-control" id="plate" name="plate" required 
                               value="<?= $action === 'edit' ? $vehicle['plate'] : '' ?>" 
                               placeholder="ABC-1234">
                    </div>
                    <div class="col-md-4">
                        <label for="model" class="form-label">Modelo*</label>
                        <input type="text" class="form-control" id="model" name="model" required 
                               value="<?= $action === 'edit' ? $vehicle['model'] : '' ?>" 
                               placeholder="Ex: Sprinter, Doblô, etc">
                    </div>
                    <div class="col-md-4">
                        <label for="brand" class="form-label">Marca*</label>
                        <input type="text" class="form-control" id="brand" name="brand" required 
                               value="<?= $action === 'edit' ? $vehicle['brand'] : '' ?>" 
                               placeholder="Ex: Mercedes, Fiat, etc">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="year" class="form-label">Ano*</label>
                        <input type="number" class="form-control" id="year" name="year" required 
                               value="<?= $action === 'edit' ? $vehicle['year'] : date('Y') ?>" 
                               min="1990" max="<?= date('Y') + 1 ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="capacity" class="form-label">Capacidade (passageiros)*</label>
                        <input type="number" class="form-control" id="capacity" name="capacity" required 
                               value="<?= $action === 'edit' ? $vehicle['capacity'] : '5' ?>" 
                               min="1" max="50">
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <div class="form-check form-switch mt-4">
                            <input class="form-check-input" type="checkbox" id="active" name="active" 
                                   <?= ($action === 'edit' && $vehicle['active'] == 1) || $action === 'add' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="active">Ativo</label>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Salvar
                    </button>
                    <a href="vehicles.php" class="btn btn-secondary ms-2">
                        <i class="fas fa-times me-1"></i> Cancelar
                    </a>
                </div>
            </form>
        </div>
    </div>
<?php else: ?>
    <!-- Lista de Veículos -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Veículos Cadastrados</h6>
        </div>
        <div class="card-body">
            <?php if (empty($vehicles)): ?>
                <div class="alert alert-info">
                    Nenhum veículo cadastrado. <a href="?action=add" class="alert-link">Cadastrar novo veículo</a>.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Placa</th>
                                <th>Modelo</th>
                                <th>Marca</th>
                                <th>Ano</th>
                                <th>Capacidade</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($vehicles as $vehicle): ?>
                                <tr>
                                    <td><?= $vehicle['plate'] ?></td>
                                    <td><?= $vehicle['model'] ?></td>
                                    <td><?= $vehicle['brand'] ?></td>
                                    <td><?= $vehicle['year'] ?></td>
                                    <td><?= $vehicle['capacity'] ?> passageiros</td>
                                    <td>
                                        <?php if ($vehicle['active'] == 1): ?>
                                            <span class="badge bg-success">Ativo</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Inativo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="?action=edit&id=<?= $vehicle['id'] ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-danger" 
                                                data-bs-toggle="modal" data-bs-target="#deleteModal<?= $vehicle['id'] ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        
                                        <!-- Modal de Confirmação de Exclusão -->
                                        <div class="modal fade" id="deleteModal<?= $vehicle['id'] ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Confirmar Exclusão</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Tem certeza que deseja excluir o veículo <strong><?= $vehicle['plate'] ?> - <?= $vehicle['model'] ?></strong>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                        <form method="post" action="vehicles.php">
                                                            <input type="hidden" name="action" value="delete">
                                                            <input type="hidden" name="id" value="<?= $vehicle['id'] ?>">
                                                            <button type="submit" class="btn btn-danger">Excluir</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
