<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();

// Verificar se a coluna city existe na tabela trips
$column_exists = $conn->query("SHOW COLUMNS FROM trips LIKE 'city'");
if ($column_exists && $column_exists->num_rows == 0) {
    // Adicionar coluna city
    $conn->query("ALTER TABLE trips ADD COLUMN city VARCHAR(100) AFTER trip_date");
    
    // Atualizar a coluna city com base nos locais existentes
    $conn->query("UPDATE trips t 
                  JOIN locations l ON t.location_id = l.id 
                  SET t.city = l.city");
}

// Verificar se a coluna location_id existe na tabela trip_passengers
$column_exists = $conn->query("SHOW COLUMNS FROM trip_passengers LIKE 'location_id'");
if ($column_exists && $column_exists->num_rows == 0) {
    // Adicionar coluna location_id
    $conn->query("ALTER TABLE trip_passengers ADD COLUMN location_id INT AFTER patient_id");
    
    // Atualizar a coluna location_id com base nas viagens existentes
    $conn->query("UPDATE trip_passengers tp
                  JOIN trips t ON tp.trip_id = t.id
                  SET tp.location_id = t.location_id
                  WHERE t.location_id IS NOT NULL");
}

// Verificar se a coluna appointment_time existe na tabela trip_passengers
$column_exists = $conn->query("SHOW COLUMNS FROM trip_passengers LIKE 'appointment_time'");
if ($column_exists && $column_exists->num_rows == 0) {
   // Adicionar coluna appointment_time
   $conn->query("ALTER TABLE trip_passengers ADD COLUMN appointment_time TIME AFTER location_id");
}

$message = '';
$error = '';

// Obter cidades únicas para o formulário de viagem
$cities_result = $conn->query("SELECT DISTINCT city FROM locations WHERE active = 1 ORDER BY city");
$cities = $cities_result->fetch_all(MYSQLI_ASSOC);

// Processar ações
$action = $_GET['action'] ?? 'list';
$trip_id = $_GET['id'] ?? null;

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Adicionar nova viagem
        if ($_POST['action'] === 'add') {
            $trip_date = $_POST['trip_date'];
            $city = $_POST['city'];
            $vehicle_id = $_POST['vehicle_id'];
            $driver_id = $_POST['driver_id'];
            $professional_id = $_POST['professional_id'];
            $departure_time = $_POST['departure_time'];
            $notes = $_POST['notes'] ?? '';
            
            // Obter o primeiro local da cidade selecionada para usar como padrão
            $location_stmt = $conn->prepare("SELECT id FROM locations WHERE city = ? AND active = 1 ORDER BY name LIMIT 1");
            $location_stmt->bind_param("s", $city);
            $location_stmt->execute();
            $location_result = $location_stmt->get_result();
            $location_id = null;

            if ($location_result && $location_result->num_rows > 0) {
                $location_id = $location_result->fetch_assoc()['id'];
                $location_stmt->close();

                $stmt = $conn->prepare("
                    INSERT INTO trips (
                        trip_date, city, location_id, vehicle_id, driver_id, professional_id, 
                        departure_time, notes, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'scheduled')
                ");
                $stmt->bind_param("ssiiiiss", $trip_date, $city, $location_id, $vehicle_id, $driver_id, $professional_id, $departure_time, $notes);
                
                if ($stmt->execute()) {
                    $trip_id = $conn->insert_id;
                    $message = "Viagem agendada com sucesso.";
                    header("Location: trips.php?action=view&id=$trip_id");
                    exit;
                } else {
                    $error = "Erro ao agendar viagem: " . $conn->error;
                }
                $stmt->close();
            } else {
                $error = "Erro: Não foi encontrado nenhum local para a cidade selecionada.";
                $location_stmt->close();
            }
        }
        // Editar viagem
        else if ($_POST['action'] === 'edit' && isset($_POST['id'])) {
            $id = $_POST['id'];
            $trip_date = $_POST['trip_date'];
            $city = $_POST['city'];
            $vehicle_id = $_POST['vehicle_id'];
            $driver_id = $_POST['driver_id'];
            $professional_id = $_POST['professional_id'];
            $departure_time = $_POST['departure_time'];
            $notes = $_POST['notes'] ?? '';
            
            // Obter o primeiro local da cidade selecionada para usar como padrão
            $location_stmt = $conn->prepare("SELECT id FROM locations WHERE city = ? AND active = 1 ORDER BY name LIMIT 1");
            $location_stmt->bind_param("s", $city);
            $location_stmt->execute();
            $location_result = $location_stmt->get_result();
            $location_id = null;

            if ($location_result && $location_result->num_rows > 0) {
                $location_id = $location_result->fetch_assoc()['id'];
                $location_stmt->close();

                $stmt = $conn->prepare("
                    UPDATE trips 
                    SET trip_date = ?, city = ?, location_id = ?, vehicle_id = ?, driver_id = ?, 
                        professional_id = ?, departure_time = ?, notes = ?
                    WHERE id = ?
                ");
                $stmt->bind_param("ssiiiissi", $trip_date, $city, $location_id, $vehicle_id, $driver_id, $professional_id, $departure_time, $notes, $id);
                
                if ($stmt->execute()) {
                    $message = "Viagem atualizada com sucesso.";
                    header("Location: trips.php?action=view&id=$id");
                    exit;
                } else {
                    $error = "Erro ao atualizar viagem: " . $conn->error;
                }
                $stmt->close();
            } else {
                $error = "Erro: Não foi encontrado nenhum local para a cidade selecionada.";
                $location_stmt->close();
            }
        }
        // Alterar status da viagem
        else if ($_POST['action'] === 'change_status' && isset($_POST['id']) && isset($_POST['status'])) {
            $id = $_POST['id'];
            $status = $_POST['status'];
            $return_time = null;
            
            if ($status === 'completed') {
                $return_time = date('H:i:s');
                
                // Verificar se a tabela de diárias existe
                $table_exists = $conn->query("SHOW TABLES LIKE 'driver_per_diem_settings'");
                if ($table_exists && $table_exists->num_rows > 0) {
                    // Redirecionar para a página de adição de diária
                    header("Location: trips.php?action=add_per_diem&id=$id");
                    exit;
                }
            }
            
            $stmt = $conn->prepare("UPDATE trips SET status = ?, return_time = ? WHERE id = ?");
            $stmt->bind_param("ssi", $status, $return_time, $id);
            
            if ($stmt->execute()) {
                $message = "Status da viagem alterado para " . ucfirst($status) . ".";
                header("Location: trips.php?action=view&id=$id");
                exit;
            } else {
                $error = "Erro ao alterar status da viagem: " . $conn->error;
            }
            $stmt->close();
        }
        // Adicionar diária
        else if ($_POST['action'] === 'add_per_diem' && isset($_POST['trip_id'])) {
            $trip_id = $_POST['trip_id'];
            $driver_id = $_POST['driver_id'];
            $per_diem_type = $_POST['per_diem_type'];
            $amount = $_POST['amount'];
            
            // Verificar se a tabela de diárias existe
            $table_exists = $conn->query("SHOW TABLES LIKE 'driver_per_diems'");
            if ($table_exists && $table_exists->num_rows > 0) {
                $stmt = $conn->prepare("
                    INSERT INTO driver_per_diems (
                        trip_id, driver_id, per_diem_type, amount
                    ) VALUES (?, ?, ?, ?)
                ");
                $stmt->bind_param("iisd", $trip_id, $driver_id, $per_diem_type, $amount);
                
                if ($stmt->execute()) {
                    // Atualizar status da viagem para completada
                    $return_time = date('H:i:s');
                    $status = 'completed';
                    
                    $stmt = $conn->prepare("UPDATE trips SET status = ?, return_time = ? WHERE id = ?");
                    $stmt->bind_param("ssi", $status, $return_time, $trip_id);
                    $stmt->execute();
                    
                    $message = "Viagem concluída e diária registrada com sucesso.";
                } else {
                    $error = "Erro ao registrar diária: " . $conn->error;
                }
                $stmt->close();
            } else {
                // Se a tabela não existir, apenas atualizar o status da viagem
                $return_time = date('H:i:s');
                $status = 'completed';
                
                $stmt = $conn->prepare("UPDATE trips SET status = ?, return_time = ? WHERE id = ?");
                $stmt->bind_param("ssi", $status, $return_time, $trip_id);
                $stmt->execute();
                
                $message = "Viagem concluída com sucesso.";
            }
            
            header("Location: trips.php?action=view&id=$trip_id");
            exit;
        }
        // Adicionar passageiro
        else if ($_POST['action'] === 'add_passenger' && isset($_POST['trip_id'])) {
            $trip_id = $_POST['trip_id'];
            $patient_id = $_POST['patient_id'];
            $location_id = $_POST['location_id'];
            $appointment_time = $_POST['appointment_time'] ?? null;
            $is_companion = isset($_POST['is_companion']) ? 1 : 0;
            $companion_of = $is_companion ? $_POST['companion_of'] : null;
            $cid_id = $_POST['cid_id'];
            $notes = $_POST['notes'] ?? '';
            
            $stmt = $conn->prepare("
                INSERT INTO trip_passengers (
                    trip_id, patient_id, location_id, appointment_time, is_companion, companion_of, cid_id, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("iiisiiss", $trip_id, $patient_id, $location_id, $appointment_time, $is_companion, $companion_of, $cid_id, $notes);
            
            if ($stmt->execute()) {
                $message = "Passageiro adicionado com sucesso.";
                header("Location: trips.php?action=view&id=$trip_id");
                exit;
            } else {
                $error = "Erro ao adicionar passageiro: " . $conn->error;
            }
            $stmt->close();
        }
        // Remover passageiro
        else if ($_POST['action'] === 'remove_passenger' && isset($_POST['passenger_id']) && isset($_POST['trip_id'])) {
            $passenger_id = $_POST['passenger_id'];
            $trip_id = $_POST['trip_id'];
            
            $stmt = $conn->prepare("DELETE FROM trip_passengers WHERE id = ?");
            $stmt->bind_param("i", $passenger_id);
            
            if ($stmt->execute()) {
                $message = "Passageiro removido com sucesso.";
                header("Location: trips.php?action=view&id=$trip_id");
                exit;
            } else {
                $error = "Erro ao remover passageiro: " . $conn->error;
            }
            $stmt->close();
        }
        // Editar passageiro
        else if ($_POST['action'] === 'edit_passenger' && isset($_POST['passenger_id']) && isset($_POST['trip_id'])) {
            $passenger_id = $_POST['passenger_id'];
            $trip_id = $_POST['trip_id'];
            $location_id = $_POST['location_id'];
            $appointment_time = $_POST['appointment_time'] ?? null;
            $notes = $_POST['notes'] ?? '';
            
            $stmt = $conn->prepare("
                UPDATE trip_passengers 
                SET location_id = ?, appointment_time = ?, notes = ?
                WHERE id = ?
            ");
            $stmt->bind_param("issi", $location_id, $appointment_time, $notes, $passenger_id);
            
            if ($stmt->execute()) {
                $message = "Passageiro atualizado com sucesso.";
                header("Location: trips.php?action=view&id=$trip_id");
                exit;
            } else {
                $error = "Erro ao atualizar passageiro: " . $conn->error;
            }
            $stmt->close();
        }
        // Excluir viagem
        else if ($_POST['action'] === 'delete' && isset($_POST['id'])) {
            $id = $_POST['id'];
            
            // Verificar se existem passageiros
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM trip_passengers WHERE trip_id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $count = $result->fetch_assoc()['count'];
            
            if ($count > 0) {
                // Excluir passageiros primeiro
                $stmt = $conn->prepare("DELETE FROM trip_passengers WHERE trip_id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
            }
            
            // Excluir viagem
            $stmt = $conn->prepare("DELETE FROM trips WHERE id = ?");
            $stmt->bind_param("i", $id);
            
            if ($stmt->execute()) {
                $message = "Viagem excluída com sucesso.";
                header("Location: trips.php");
                exit;
            } else {
                $error = "Erro ao excluir viagem: " . $conn->error;
            }
            $stmt->close();
        }
    }
}

// Obter dados para formulários
$locations = $conn->query("SELECT id, name, city, distance FROM locations WHERE active = 1 ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$vehicles = $conn->query("SELECT id, plate, model, brand, capacity FROM vehicles WHERE active = 1 ORDER BY plate")->fetch_all(MYSQLI_ASSOC);
$drivers = $conn->query("SELECT id, name FROM drivers WHERE active = 1 ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$professionals = $conn->query("SELECT id, name, cns, cbo FROM professionals WHERE active = 1 ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$patients = $conn->query("SELECT id, name, cns, phone FROM patients ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$cids = $conn->query("SELECT id, code, description FROM cid10 ORDER BY code")->fetch_all(MYSQLI_ASSOC);

// Verificar se a tabela de diárias existe
$per_diem_settings_exists = $conn->query("SHOW TABLES LIKE 'driver_per_diem_settings'");
$per_diem_settings = null;

if ($per_diem_settings_exists && $per_diem_settings_exists->num_rows > 0) {
    $per_diem_settings_result = $conn->query("SELECT * FROM driver_per_diem_settings WHERE id = 1");
    if ($per_diem_settings_result) {
        $per_diem_settings = $per_diem_settings_result->fetch_assoc();
    }
}

// Ação específica
if ($action === 'add_per_diem' && $trip_id) {
    // Obter detalhes da viagem
    $stmt = $conn->prepare("
        SELECT t.*, 
               l.name as location_name, l.city as location_city, l.distance,
               d.id as driver_id, d.name as driver_name
        FROM trips t
        JOIN locations l ON t.location_id = l.id
        JOIN drivers d ON t.driver_id = d.id
        WHERE t.id = ?
    ");
    $stmt->bind_param("i", $trip_id);
    $stmt->execute();
    $trip = $stmt->get_result()->fetch_assoc();
    
    if (!$trip) {
        $error = "Viagem não encontrada.";
        $action = 'list';
    }
} else if ($action === 'view' && $trip_id) {
    // Obter detalhes da viagem
    $stmt = $conn->prepare("
        SELECT t.*, 
           v.plate, v.model, v.brand, v.capacity,
           d.name as driver_name,
           p.name as professional_name, p.cns as professional_cns, p.cbo as professional_cbo
        FROM trips t
        JOIN vehicles v ON t.vehicle_id = v.id
        JOIN drivers d ON t.driver_id = d.id
        JOIN professionals p ON t.professional_id = p.id
        WHERE t.id = ?
    ");
    $stmt->bind_param("i", $trip_id);
    $stmt->execute();
    $trip = $stmt->get_result()->fetch_assoc();
    
    // Obter passageiros
    $stmt = $conn->prepare("
        SELECT tp.*, 
           p.name as patient_name, p.cns as patient_cns, p.phone as patient_phone,
           c.code as cid_code, c.description as cid_description,
           p2.name as companion_of_name,
           l.name as location_name, l.city as location_city, l.distance
        FROM trip_passengers tp
        JOIN patients p ON tp.patient_id = p.id
        JOIN cid10 c ON tp.cid_id = c.id
        LEFT JOIN patients p2 ON tp.companion_of = p2.id
        LEFT JOIN locations l ON tp.location_id = l.id
        WHERE tp.trip_id = ?
        ORDER BY tp.appointment_time, tp.is_companion, tp.id
    ");
    $stmt->bind_param("i", $trip_id);
    $stmt->execute();
    $passengers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Contar passageiros
    $passenger_count = count($passengers);
    $available_seats = $trip['capacity'] - $passenger_count;
} else if ($action === 'edit' && $trip_id) {
    // Obter dados da viagem para edição
    $stmt = $conn->prepare("SELECT * FROM trips WHERE id = ?");
    $stmt->bind_param("i", $trip_id);
    $stmt->execute();
    $trip = $stmt->get_result()->fetch_assoc();
} else if ($action === 'edit_passenger' && isset($_GET['passenger_id'])) {
    // Obter dados do passageiro para edição
    $passenger_id = $_GET['passenger_id'];
    $stmt = $conn->prepare("
        SELECT tp.*, p.name as patient_name, l.name as location_name, l.id as location_id
        FROM trip_passengers tp
        JOIN patients p ON tp.patient_id = p.id
        LEFT JOIN locations l ON tp.location_id = l.id
        WHERE tp.id = ?
    ");
    $stmt->bind_param("i", $passenger_id);
    $stmt->execute();
    $passenger = $stmt->get_result()->fetch_assoc();
    $trip_id = $passenger['trip_id'];
    
    // Obter dados da viagem para obter a cidade
    $stmt_trip = $conn->prepare("SELECT * FROM trips WHERE id = ?");
    $stmt_trip->bind_param("i", $trip_id);
    $stmt_trip->execute();
    $trip = $stmt_trip->get_result()->fetch_assoc();
} else {
    // Listar viagens - CORREÇÃO DA ORDENAÇÃO POR DATA
    $status_filter = $_GET['status'] ?? '';
    $order_by = $_GET['order_by'] ?? 'trip_date';
    $order_dir = $_GET['order_dir'] ?? 'DESC';
    
    // Validar direção da ordenação
    $order_dir = in_array(strtoupper($order_dir), ['ASC', 'DESC']) ? strtoupper($order_dir) : 'DESC';
    
    $where_clause = "";
    if ($status_filter) {
        $where_clause = "WHERE t.status = '$status_filter'";
    }
    
    // Consulta com ordenação correta por data
    $query = "
        SELECT t.id, t.trip_date, t.departure_time, t.return_time, t.status,
               t.city as city,
               v.plate, d.name as driver_name,
               (SELECT COUNT(*) FROM trip_passengers WHERE trip_id = t.id) as passenger_count
        FROM trips t
        JOIN vehicles v ON t.vehicle_id = v.id
        JOIN drivers d ON t.driver_id = d.id
        $where_clause
        ORDER BY
            CASE 
                WHEN t.status = 'scheduled' THEN 1
                WHEN t.status = 'in_progress' THEN 2
                WHEN t.status = 'completed' THEN 3
                WHEN t.status = 'cancelled' THEN 4
            END,
            t.trip_date $order_dir, t.departure_time
    ";
    
    $result = $conn->query($query);
    $trips = $result->fetch_all(MYSQLI_ASSOC);
}

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <?php if ($action === 'add'): ?>
            <i class="fas fa-plus-circle me-2"></i>Nova Viagem
        <?php elseif ($action === 'edit'): ?>
            <i class="fas fa-edit me-2"></i>Editar Viagem
        <?php elseif ($action === 'view'): ?>
            <i class="fas fa-eye me-2"></i>Detalhes da Viagem
        <?php elseif ($action === 'add_per_diem'): ?>
            <i class="fas fa-money-bill-wave me-2"></i>Registrar Diária
        <?php elseif ($action === 'edit_passenger'): ?>
            <i class="fas fa-user-edit me-2"></i>Editar Passageiro
        <?php else: ?>
            <i class="fas fa-route me-2"></i>Gerenciamento de Viagens
        <?php endif; ?>
    </h1>
    
    <?php if ($action === 'list'): ?>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="?status=" class="btn btn-sm <?= $status_filter === '' ? 'btn-primary' : 'btn-outline-primary' ?>">Todas</a>
                <a href="?status=scheduled" class="btn btn-sm <?= $status_filter === 'scheduled' ? 'btn-primary' : 'btn-outline-primary' ?>">Agendadas</a>
                <a href="?status=in_progress" class="btn btn-sm <?= $status_filter === 'in_progress' ? 'btn-primary' : 'btn-outline-primary' ?>">Em Andamento</a>
                <a href="?status=completed" class="btn btn-sm <?= $status_filter === 'completed' ? 'btn-primary' : 'btn-outline-primary' ?>">Concluídas</a>
                <a href="?status=cancelled" class="btn btn-sm <?= $status_filter === 'cancelled' ? 'btn-primary' : 'btn-outline-primary' ?>">Canceladas</a>
            </div>
            <a href="?action=add" class="btn btn-sm btn-success">
                <i class="fas fa-plus me-1"></i> Nova Viagem
            </a>
        </div>
    <?php elseif ($action === 'view'): ?>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="trips.php" class="btn btn-sm btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Voltar
                </a>
                
                <?php if ($trip['status'] === 'scheduled' || $trip['status'] === 'in_progress'): ?>
                    <a href="?action=edit&id=<?= $trip_id ?>" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-edit me-1"></i> Editar
                    </a>
                <?php endif; ?>
                
                <a href="trip_print.php?id=<?= $trip_id ?>" target="_blank" class="btn btn-sm btn-outline-info">
                    <i class="fas fa-print me-1"></i> Imprimir
                </a>
            </div>
        </div>
    <?php elseif ($action === 'add_per_diem'): ?>
        <a href="trips.php?action=view&id=<?= $trip_id ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    <?php elseif ($action === 'edit_passenger'): ?>
        <a href="trips.php?action=view&id=<?= $trip_id ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    <?php else: ?>
        <a href="trips.php" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    <?php endif; ?>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($action === 'add_per_diem' && $per_diem_settings): ?>
    <!-- Formulário de Diária -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Registrar Diária para Viagem #<?= $trip_id ?></h6>
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-6">
                    <h5>Informações da Viagem</h5>
                    <p><strong>Data:</strong> <?= date('d/m/Y', strtotime($trip['trip_date'])) ?></p>
                    <p><strong>Destino:</strong> <?= htmlspecialchars($trip['location_name']) ?> - <?= htmlspecialchars($trip['location_city']) ?></p>
                    <p><strong>Distância:</strong> <?= $trip['distance'] ?> km</p>
                </div>
                <div class="col-md-6">
                    <h5>Motorista</h5>
                    <p><strong>Nome:</strong> <?= htmlspecialchars($trip['driver_name']) ?></p>
                </div>
            </div>
            
            <form method="post">
                <input type="hidden" name="action" value="add_per_diem">
                <input type="hidden" name="trip_id" value="<?= $trip_id ?>">
                <input type="hidden" name="driver_id" value="<?= $trip['driver_id'] ?>">
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="per_diem_type" class="form-label">Tipo de Diária</label>
                        <select class="form-select" id="per_diem_type" name="per_diem_type" required onchange="updateAmount()">
                            <?php if (!$per_diem_settings['use_distance_based']): ?>
                                <option value="full_day" data-amount="<?= $per_diem_settings['full_day_amount'] ?>">Diária Inteira (R$ <?= number_format($per_diem_settings['full_day_amount'], 2, ',', '.') ?>)</option>
                                <option value="half_day" data-amount="<?= $per_diem_settings['half_day_amount'] ?>">Meia Diária (R$ <?= number_format($per_diem_settings['half_day_amount'], 2, ',', '.') ?>)</option>
                            <?php else: ?>
                                <?php if ($trip['distance'] <= $per_diem_settings['distance_threshold']): ?>
                                    <option value="short_trip" data-amount="<?= $per_diem_settings['short_trip_amount'] ?>">Viagem Próxima (R$ <?= number_format($per_diem_settings['short_trip_amount'], 2, ',', '.') ?>)</option>
                                <?php else: ?>
                                    <option value="long_trip" data-amount="<?= $per_diem_settings['long_trip_amount'] ?>">Viagem Distante (R$ <?= number_format($per_diem_settings['long_trip_amount'], 2, ',', '.') ?>)</option>
                                <?php endif; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="amount" class="form-label">Valor da Diária</label>
                        <div class="input-group">
                            <span class="input-group-text">R$</span>
                            <input type="number" class="form-control" id="amount" name="amount" step="0.01" min="0" required>
                        </div>
                    </div>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <a href="trips.php?action=view&id=<?= $trip_id ?>" class="btn btn-secondary me-md-2">Cancelar</a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Registrar Diária e Concluir Viagem
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function updateAmount() {
            const select = document.getElementById('per_diem_type');
            const option = select.options[select.selectedIndex];
            const amount = option.getAttribute('data-amount');
            document.getElementById('amount').value = amount;
        }
        
        // Inicializar o valor ao carregar a página
        document.addEventListener('DOMContentLoaded', function() {
            updateAmount();
        });
    </script>
<?php elseif ($action === 'add' || $action === 'edit'): ?>
    <!-- Formulário de Viagem -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <?= $action === 'add' ? 'Nova Viagem' : 'Editar Viagem' ?>
            </h6>
        </div>
        <div class="card-body">
            <form method="post">
                <input type="hidden" name="action" value="<?= $action ?>">
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="id" value="<?= $trip_id ?>">
                <?php endif; ?>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="trip_date" class="form-label">Data da Viagem</label>
                        <input type="date" class="form-control" id="trip_date" name="trip_date" required
                               value="<?= $action === 'edit' ? $trip['trip_date'] : date('Y-m-d') ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="departure_time" class="form-label">Horário de Saída</label>
                        <input type="time" class="form-control" id="departure_time" name="departure_time" required
                               value="<?= $action === 'edit' ? date('H:i', strtotime($trip['departure_time'])) : '07:00' ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="city" class="form-label">Cidade de Destino</label>
                        <select class="form-select" id="city" name="city" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($cities as $city_option): ?>
                                <option value="<?= $city_option['city'] ?>" 
                                        <?= ($action === 'edit' && $trip['city'] == $city_option['city']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($city_option['city']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="vehicle_id" class="form-label">Veículo</label>
                        <select class="form-select" id="vehicle_id" name="vehicle_id" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($vehicles as $vehicle): ?>
                                <option value="<?= $vehicle['id'] ?>" 
                                        data-capacity="<?= $vehicle['capacity'] ?>"
                                        <?= ($action === 'edit' && $trip['vehicle_id'] == $vehicle['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($vehicle['plate']) ?> - <?= htmlspecialchars($vehicle['model']) ?> (<?= $vehicle['capacity'] ?> lugares)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="driver_id" class="form-label">Motorista</label>
                        <select class="form-select" id="driver_id" name="driver_id" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($drivers as $driver): ?>
                                <option value="<?= $driver['id'] ?>" 
                                        <?= ($action === 'edit' && $trip['driver_id'] == $driver['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($driver['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="professional_id" class="form-label">Profissional Responsável</label>
                        <select class="form-select" id="professional_id" name="professional_id" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($professionals as $professional): ?>
                                <option value="<?= $professional['id'] ?>" 
                                        <?= ($action === 'edit' && $trip['professional_id'] == $professional['id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($professional['name']) ?> (<?= $professional['cbo'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="notes" class="form-label">Observações</label>
                    <textarea class="form-control" id="notes" name="notes" rows="3"><?= $action === 'edit' ? htmlspecialchars($trip['notes']) : '' ?></textarea>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <a href="trips.php" class="btn btn-secondary me-md-2">Cancelar</a>
                    <button type="submit" class="btn btn-primary">
                        <?= $action === 'add' ? 'Agendar Viagem' : 'Salvar Alterações' ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php elseif ($action === 'edit_passenger'): ?>
    <!-- Formulário de Edição de Passageiro -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Editar Passageiro</h6>
        </div>
        <div class="card-body">
            <form method="post">
                <input type="hidden" name="action" value="edit_passenger">
                <input type="hidden" name="trip_id" value="<?= $trip_id ?>">
                <input type="hidden" name="passenger_id" value="<?= $passenger['id'] ?>">
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Paciente</label>
                        <p class="form-control-static"><?= htmlspecialchars($passenger['patient_name']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <label for="location_id" class="form-label">Destino Específico</label>
                        <select class="form-select" id="location_id" name="location_id" required>
                            <option value="">Selecione...</option>
                            <?php 
                            // Reabrir conexão se estiver fechada
                            $conn = connectMySQL();
                            
                            // Obter locais da cidade selecionada
                            $filtered_locations = [];
                            if (!empty($trip['city'])) {
                                $locations_stmt = $conn->prepare("SELECT id, name, distance FROM locations WHERE city = ? AND active = 1 ORDER BY name");
                                if ($locations_stmt) {
                                    $locations_stmt->bind_param("s", $trip['city']);
                                    $locations_stmt->execute();
                                    $locations_result = $locations_stmt->get_result();
                                    if ($locations_result) {
                                        $filtered_locations = $locations_result->fetch_all(MYSQLI_ASSOC);
                                    }
                                    $locations_stmt->close();
                                }
                            }
                            $conn->close();
                            
                            foreach ($filtered_locations as $location): 
                            ?>
                                <option value="<?= $location['id'] ?>" data-distance="<?= $location['distance'] ?>" <?= $passenger['location_id'] == $location['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($location['name']) ?> (<?= $location['distance'] ?>km)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="appointment_time" class="form-label">Horário da Consulta</label>
                        <input type="time" class="form-control" id="appointment_time" name="appointment_time" value="<?= $passenger['appointment_time'] ? date('H:i', strtotime($passenger['appointment_time'])) : '' ?>">
                        <div class="form-text">Horário que o paciente deve estar no local de destino</div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="notes" class="form-label">Local de Espera</label>
                    <textarea class="form-control" id="notes" name="notes" rows="2" placeholder="Informe o local onde o paciente estará aguardando"><?= htmlspecialchars($passenger['notes']) ?></textarea>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <a href="trips.php?action=view&id=<?= $trip_id ?>" class="btn btn-secondary me-md-2">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                </div>
            </form>
        </div>
    </div>
<?php elseif ($action === 'view'): ?>
    <!-- Detalhes da Viagem -->
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Informações da Viagem</h6>
                    <span class="badge <?php 
                        if ($trip['status'] === 'scheduled') echo 'bg-warning';
                        else if ($trip['status'] === 'in_progress') echo 'bg-info';
                        else if ($trip['status'] === 'completed') echo 'bg-success';
                        else echo 'bg-danger';
                    ?>">
                        <?php 
                            if ($trip['status'] === 'scheduled') echo 'Agendada';
                            else if ($trip['status'] === 'in_progress') echo 'Em Andamento';
                            else if ($trip['status'] === 'completed') echo 'Concluída';
                            else echo 'Cancelada';
                        ?>
                    </span>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p><strong>Data:</strong> <?= date('d/m/Y', strtotime($trip['trip_date'])) ?></p>
                            <p><strong>Saída:</strong> <?= date('H:i', strtotime($trip['departure_time'])) ?></p>
                            <?php if ($trip['return_time']): ?>
                                <p><strong>Retorno:</strong> <?= date('H:i', strtotime($trip['return_time'])) ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Cidade de Destino:</strong> <?= htmlspecialchars($trip['city']) ?></p>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p><strong>Veículo:</strong> <?= htmlspecialchars($trip['plate']) ?></p>
                            <p><strong>Modelo:</strong> <?= htmlspecialchars($trip['model']) ?> <?= htmlspecialchars($trip['brand']) ?></p>
                            <p><strong>Capacidade:</strong> <?= $trip['capacity'] ?> lugares</p>
                            <p><strong>Ocupação:</strong> <?= $passenger_count ?>/<?= $trip['capacity'] ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Motorista:</strong> <?= htmlspecialchars($trip['driver_name']) ?></p>
                            <p><strong>Profissional:</strong> <?= htmlspecialchars($trip['professional_name']) ?></p>
                            <p><strong>CNS:</strong> <?= $trip['professional_cns'] ?></p>
                            <p><strong>CBO:</strong> <?= $trip['professional_cbo'] ?></p>
                        </div>
                    </div>
                    
                    <?php if ($trip['notes']): ?>
                        <div class="alert alert-info">
                            <strong>Observações:</strong>
                            <?= nl2br(htmlspecialchars($trip['notes'])) ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="d-flex gap-2">
                        <?php if ($trip['status'] === 'scheduled'): ?>
                            <form method="post" class="d-inline">
                                <input type="hidden" name="action" value="change_status">
                                <input type="hidden" name="id" value="<?= $trip_id ?>">
                                <input type="hidden" name="status" value="in_progress">
                                <button type="submit" class="btn btn-info">
                                    <i class="fas fa-play me-1"></i> Iniciar Viagem
                                </button>
                            </form>
                            
                            <form method="post" class="d-inline">
                                <input type="hidden" name="action" value="change_status">
                                <input type="hidden" name="id" value="<?= $trip_id ?>">
                                <input type="hidden" name="status" value="cancelled">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-ban me-1"></i> Cancelar Viagem
                                </button>
                            </form>
                        <?php elseif ($trip['status'] === 'in_progress'): ?>
                            <form method="post">
                                <input type="hidden" name="action" value="change_status">
                                <input type="hidden" name="id" value="<?= $trip_id ?>">
                                <input type="hidden" name="status" value="completed">
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-check me-1"></i> Concluir Viagem
                                </button>
                            </form>
                            
                            <form method="post" class="d-inline">
                                <input type="hidden" name="action" value="change_status">
                                <input type="hidden" name="id" value="<?= $trip_id ?>">
                                <input type="hidden" name="status" value="cancelled">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-ban me-1"></i> Cancelar Viagem
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Passageiros</h6>
                    <?php if (($trip['status'] === 'scheduled' || $trip['status'] === 'in_progress') && $available_seats > 0): ?>
                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addPassengerModal">
                            <i class="fas fa-plus me-1"></i> Adicionar Passageiro
                        </button>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if (count($passengers) > 0): ?>
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Destino e Horário</th>
                                    <th>Local de Espera</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($passengers as $passenger): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <span><?= htmlspecialchars($passenger['patient_name']) ?></span>
                                                <small class="text-muted">
                                                    CNS: <?= $passenger['patient_cns'] ?>
                                                    <?php if (!empty($passenger['patient_phone'])): ?>
                                                        | Tel: <?= $passenger['patient_phone'] ?>
                                                    <?php endif; ?>
                                                </small>
                                                <?php if ($passenger['is_companion']): ?>
                                                    <span class="badge bg-info mt-1">
                                                        <i class="fas fa-user-friends me-1"></i> Acompanhante de <?= htmlspecialchars($passenger['companion_of_name']) ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-primary mt-1">
                                                        <i class="fas fa-user me-1"></i> Paciente
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <span><?= htmlspecialchars($passenger['location_name']) ?></span>
                                                <small class="d-block text-muted"><?= $passenger['distance'] ?> km</small>
                                                <?php if (!empty($passenger['appointment_time'])): ?>
                                                    <span class="badge bg-warning text-dark mt-1">
                                                        <i class="fas fa-clock me-1"></i> <?= date('H:i', strtotime($passenger['appointment_time'])) ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="text-muted">Não definido</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td><?= nl2br(htmlspecialchars($passenger['notes'] ?? '')) ?></td>
                                        <td>
                                            <?php if ($trip['status'] === 'scheduled' || $trip['status'] === 'in_progress'): ?>
                                                <div class="btn-group">
                                                    <a href="?action=edit_passenger&passenger_id=<?= $passenger['id'] ?>" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="Editar">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <form method="post" class="d-inline">
                                                        <input type="hidden" name="action" value="remove_passenger">
                                                        <input type="hidden" name="passenger_id" value="<?= $passenger['id'] ?>">
                                                        <input type="hidden" name="trip_id" value="<?= $trip_id ?>">
                                                        <button type="submit" class="btn btn-sm btn-danger btn-delete" data-bs-toggle="tooltip" title="Remover">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            <?php else: ?>
                                                <button type="button" class="btn btn-sm btn-secondary" disabled>
                                                    <i class="fas fa-lock"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-center">Nenhum passageiro adicionado.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para adicionar passageiro -->
    <div class="modal fade" id="addPassengerModal" tabindex="-1" aria-labelledby="addPassengerModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="post">
                    <input type="hidden" name="action" value="add_passenger">
                    <input type="hidden" name="trip_id" value="<?= $trip_id ?>">
                    
                    <div class="modal-header">
                        <h5 class="modal-title" id="addPassengerModalLabel">Adicionar Passageiro</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" id="is_companion" name="is_companion">
                                    <label class="form-check-label" for="is_companion">
                                        É acompanhante
                                    </label>
                                </div>
                                
                                <div id="companion_of_div" class="mb-3 d-none">
                                    <label for="companion_of" class="form-label">Acompanhante de</label>
                                    <select class="form-select" id="companion_of" name="companion_of">
                                        <option value="">Selecione...</option>
                                        <?php foreach ($passengers as $p): ?>
                                            <?php if (!$p['is_companion']): ?>
                                                <option value="<?= $p['patient_id'] ?>"><?= htmlspecialchars($p['patient_name']) ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="cid_id" class="form-label">CID</label>
                                    <select class="form-select" id="cid_id" name="cid_id" required>
                                        <option value="">Selecione...</option>
                                        <?php foreach ($cids as $cid): ?>
                                            <option value="<?= $cid['id'] ?>" <?= $cid['id'] == 1 ? 'selected' : '' ?>>
                                                <?= $cid['code'] ?> - <?= htmlspecialchars($cid['description']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="location_id" class="form-label">Destino Específico</label>
                                <select class="form-select" id="location_id" name="location_id" required>
                                    <option value="">Selecione...</option>
                                    <?php 
                                    // Reabrir conexão se estiver fechada
                                    $conn = connectMySQL();
                                    
                                    // Obter locais da cidade selecionada
                                    $filtered_locations = [];
                                    if (!empty($trip['city'])) {
                                        $locations_stmt = $conn->prepare("SELECT id, name, distance FROM locations WHERE city = ? AND active = 1 ORDER BY name");
                                        if ($locations_stmt) {
                                            $locations_stmt->bind_param("s", $trip['city']);
                                            $locations_stmt->execute();
                                            $locations_result = $locations_stmt->get_result();
                                            if ($locations_result) {
                                                $filtered_locations = $locations_result->fetch_all(MYSQLI_ASSOC);
                                            }
                                            $locations_stmt->close();
                                        }
                                    }
                                    $conn->close();
                                    
                                    foreach ($filtered_locations as $location): 
                                    ?>
                                        <option value="<?= $location['id'] ?>" data-distance="<?= $location['distance'] ?>">
                                            <?= htmlspecialchars($location['name']) ?> (<?= $location['distance'] ?>km)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="appointment_time" class="form-label">Horário da Consulta</label>
                                <input type="time" class="form-control" id="appointment_time" name="appointment_time">
                                <div class="form-text">Horário que o paciente deve estar no local de destino</div>
                            </div>
                        </div>

                        <ul class="nav nav-tabs" id="patientTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="existing-tab" data-bs-toggle="tab" data-bs-target="#existing" type="button" role="tab">
                                    Paciente Existente
                                </button>
                            </li>
                        </ul>
                        
                        <div class="tab-content p-3 border border-top-0 rounded-bottom" id="patientTabsContent">
                            <div class="tab-pane fade show active" id="existing" role="tabpanel">
                                <div class="mb-3">
                                    <label for="patient_id" class="form-label">Selecione o Paciente</label>
                                    <input list="patients_list" id="patient_name" name="patient_name" placeholder="Digite o nome do paciente" autocomplete="off" required>
                                    <input type="hidden" id="patient_id" name="patient_id">

                                    <datalist id="patients_list">
                                        <?php foreach ($patients as $patient): ?>
                                            <option data-id="<?= $patient['id'] ?>" value="<?= htmlspecialchars($patient['name']) ?> - CNS: <?= $patient['cns'] ?>"></option>
                                        <?php endforeach; ?>
                                    </datalist>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3 mt-3">
                            <label for="notes" class="form-label">Local de Espera</label>
                            <textarea class="form-control" id="notes" name="notes" rows="2" placeholder="Informe o local onde o paciente estará aguardando"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary" id="add_passenger_button">Adicionar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('patient_name').addEventListener('input', function() {
            const val = this.value;
            const opts = document.getElementById('patients_list').childNodes;
            let foundId = '';

            for (let i = 0; i < opts.length; i++) {
                if (opts[i].value === val) {
                    foundId = opts[i].getAttribute('data-id');
                    break;
                }
            }

            document.getElementById('patient_id').value = foundId;
        });

        // Mostrar/ocultar campo de acompanhante
        document.getElementById('is_companion').addEventListener('change', function() {
            const companionDiv = document.getElementById('companion_of_div');
            const companionSelect = document.getElementById('companion_of');
            
            if (this.checked) {
                companionDiv.classList.remove('d-none');
                companionSelect.required = true;
                
                // Quando selecionar um paciente para ser acompanhante, copiar os dados do paciente selecionado
                companionSelect.addEventListener('change', function() {
                    const selectedPatientId = this.value;
                    if (selectedPatientId) {
                        // Buscar os dados do paciente selecionado via AJAX
                        fetch('get_patient_details.php?patient_id=' + selectedPatientId)
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    // Preencher os campos com os dados do paciente
                                    document.getElementById('location_id').value = data.location_id;
                                    document.getElementById('appointment_time').value = data.appointment_time;
                                    document.getElementById('notes').value = data.notes;
                                }
                            })
                            .catch(error => console.error('Erro:', error));
                    }
                });
            } else {
                companionDiv.classList.add('d-none');
                companionSelect.required = false;
            }
        });
    </script>
<?php else: ?>
    <!-- Lista de Viagens -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Viagens</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered datatable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Data</th>
                            <th>Destino</th>
                            <th>Veículo</th>
                            <th>Motorista</th>
                            <th>Passageiros</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                <tbody>
                    <?php foreach ($trips as $trip): ?>
                        <?php 
                            // garantir data segura
                            $dt = DateTime::createFromFormat('Y-m-d', $trip['trip_date']);
                            $isoDate = $dt ? $dt->format('Y-m-d') : '';
                            $displayDate = $dt ? $dt->format('d/m/Y') : '';
                        ?>
                        <tr>
                            <td><?= $trip['id'] ?></td>
                            <td data-order="<?= $isoDate ?>">
                                <?= $displayDate ?>
                            </td>
                            <td><?= htmlspecialchars($trip['city']) ?></td>
                            <td><?= htmlspecialchars($trip['plate']) ?></td>
                            <td><?= htmlspecialchars($trip['driver_name']) ?></td>
                            <td><?= $trip['passenger_count'] ?></td>
                            <td>
                                <?php if ($trip['status'] === 'scheduled'): ?>
                                    <span class="badge bg-warning">Agendada</span>
                                <?php elseif ($trip['status'] === 'in_progress'): ?>
                                    <span class="badge bg-info">Em Andamento</span>
                                <?php elseif ($trip['status'] === 'completed'): ?>
                                    <span class="badge bg-success">Concluída</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Cancelada</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="?action=view&id=<?= $trip['id'] ?>" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Visualizar">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    
                                    <?php if ($trip['status'] === 'scheduled'): ?>
                                        <a href="?action=edit&id=<?= $trip['id'] ?>" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="Editar">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        
                                        <form method="post" class="d-inline">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?= $trip['id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger btn-delete" data-bs-toggle="tooltip" title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    
                                    <a href="trip_print.php?id=<?= $trip['id'] ?>" target="_blank" class="btn btn-sm btn-secondary" data-bs-toggle="tooltip" title="Imprimir">
                                        <i class="fas fa-print"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>

                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>