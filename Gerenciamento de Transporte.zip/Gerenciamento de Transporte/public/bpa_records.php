<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Verificar se foi fornecido um header_id
if (!isset($_GET['header_id']) || !is_numeric($_GET['header_id'])) {
    $error = "ID do cabeçalho não fornecido ou inválido.";
} else {
    $header_id = $_GET['header_id'];
    
    // Obter dados do cabeçalho
    $stmt = $conn->prepare("SELECT * FROM bpa_headers WHERE id = ?");
    $stmt->bind_param("i", $header_id);
    $stmt->execute();
    $header = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$header) {
        $error = "Cabeçalho não encontrado.";
    } else {
        // Obter registros BPA
        $stmt = $conn->prepare("
            SELECT r.*, 
                   p.code as procedure_code, p.description as procedure_description
            FROM bpa_records r
            LEFT JOIN procedures p ON r.prd_pa = p.code
            WHERE r.header_id = ?
            ORDER BY r.prd_flh, r.prd_seq
        ");
        $stmt->bind_param("i", $header_id);
        $stmt->execute();
        $records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    }
}

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-list-alt me-2"></i>Registros BPA-I</h1>
    <div>
        <a href="bpa_generate.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
        <?php if (isset($header) && $header['status'] === 'finalized'): ?>
            <a href="bpa_generate.php?download=<?= $header_id ?>" class="btn btn-outline-primary ms-2">
                <i class="fas fa-download me-1"></i> Baixar Arquivo
            </a>
        <?php endif; ?>
    </div>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if (isset($header) && isset($records)): ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">
                Competência: <?= substr($header['cbc_mvm'], 0, 4) ?>/<?= substr($header['cbc_mvm'], 4, 2) ?>
                <span class="badge <?= $header['status'] === 'draft' ? 'bg-warning' : 'bg-success' ?> ms-2">
                    <?= $header['status'] === 'draft' ? 'Rascunho' : 'Finalizado' ?>
                </span>
            </h6>
            <div>
                <span class="text-muted">Total de registros: <?= count($records) ?></span>
            </div>
        </div>
        <div class="card-body">
            <?php if (count($records) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover" id="dataTable">
                        <thead>
                            <tr>
                                <th>Folha</th>
                                <th>Seq</th>
                                <th>Data</th>
                                <th>Paciente</th>
                                <th>CNS</th>
                                <th>Procedimento</th>
                                <th>Qtd</th>
                                <th>CID</th>
                                <th>Profissional</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($records as $record): ?>
                                <tr>
                                    <td><?= $record['prd_flh'] ?></td>
                                    <td><?= $record['prd_seq'] ?></td>
                                    <td><?= date('d/m/Y', strtotime($record['prd_dtaten'])) ?></td>
                                    <td><?= htmlspecialchars($record['prd_nmpac']) ?></td>
                                    <td><?= $record['prd_cnspac'] ?></td>
                                    <td>
                                        <?= $record['prd_pa'] ?> - 
                                        <?= isset($record['procedure_description']) ? htmlspecialchars($record['procedure_description']) : 'Não encontrado' ?>
                                    </td>
                                    <td><?= intval($record['prd_qt']) ?></td>
                                    <td><?= $record['prd_cid'] ?></td>
                                    <td><?= $record['prd_cnsmed'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    Nenhum registro BPA-I encontrado para este cabeçalho.
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<script>
    $(document).ready(function() {
        $('#dataTable').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Portuguese-Brasil.json'
            },
            pageLength: 25
        });
    });
</script>

<?php require_once 'includes/footer.php'; ?>
