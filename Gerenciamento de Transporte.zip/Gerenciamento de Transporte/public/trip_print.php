<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

// Verificar se o ID da viagem foi fornecido
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID de viagem inválido.");
}

$trip_id = $_GET['id'];
$conn = connectMySQL();

// Obter detalhes da viagem
$stmt = $conn->prepare("
    SELECT t.*, 
           l.name as location_name, l.city as location_city, l.distance,
           v.plate, v.model, v.brand, v.capacity,
           d.name as driver_name,
           p.name as professional_name, p.cns as professional_cns, p.cbo as professional_cbo
    FROM trips t
    JOIN locations l ON t.location_id = l.id
    JOIN vehicles v ON t.vehicle_id = v.id
    JOIN drivers d ON t.driver_id = d.id
    JOIN professionals p ON t.professional_id = p.id
    WHERE t.id = ?
");
$stmt->bind_param("i", $trip_id);
$stmt->execute();
$trip = $stmt->get_result()->fetch_assoc();

if (!$trip) {
    die("Viagem não encontrada.");
}

// Modificar a consulta SQL para incluir o agrupamento
$stmt = $conn->prepare("
        SELECT tp.*, 
               p.name as patient_name, p.cns as patient_cns, p.phone as patient_phone,
               c.code as cid_code, c.description as cid_description,
               p2.name as companion_of_name,
               l.name as location_name, l.city as location_city,
               tp.appointment_time,
               CASE 
                   WHEN tp.is_companion = 0 THEN tp.patient_id
                   WHEN tp.is_companion = 1 THEN tp.companion_of
               END as group_id
        FROM trip_passengers tp
        JOIN patients p ON tp.patient_id = p.id
        JOIN cid10 c ON tp.cid_id = c.id
        LEFT JOIN patients p2 ON tp.companion_of = p2.id
        LEFT JOIN locations l ON tp.location_id = l.id
        WHERE tp.trip_id = ?
        ORDER BY tp.appointment_time, group_id, tp.is_companion, tp.id
    ");

// Obter passageiros
$stmt->bind_param("i", $trip_id);
$stmt->execute();
$passengers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Obter configurações
$result = $conn->query("SELECT * FROM settings LIMIT 1");
$settings = $result->fetch_assoc();

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espelho de Viagem #<?= $trip_id ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 10px;
            font-size: 12pt;
        }
        .header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
            padding-bottom: 5px;
        }
        .logo-container {
            width: 80px;
            margin-right: 15px;
        }
        .logo {
            max-height: 80px;
            max-width: 80px;
        }
        .header-text {
            text-align: left;
            flex: 1;
        }
        h1 {
            font-size: 16pt;
            margin: 3px 0;
        }
        h2 {
            font-size: 14pt;
            margin: 10px 0 5px;
            border-bottom: 1px solid #eee;
            padding-bottom: 3px;
        }
        .info-container {
            display: flex;
            flex-wrap: wrap;
            gap: 5px;
            margin-bottom: 5px;
        }
        .info-block {
            flex: 1;
            min-width: 300px;
            margin-bottom: 5px;
        }
        .info-row {
            display: flex;
            margin-bottom: 2px;
        }
        .info-label {
            font-weight: bold;
            width: 150px;
        }
        .info-value {
            flex: 1;
        }
        .trip-notes {
            padding: 5px;
            margin-bottom: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 5px;
            margin-bottom: 10px;
            table-layout: fixed;
            border-spacing: 0 5px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
            vertical-align: top;
            height: auto;
            min-height: 50px;
        }
        th:nth-child(1), td:nth-child(1) {
            width: 35%;
        }
        th:nth-child(2), td:nth-child(2) {
            width: 40%;
        }
        th:nth-child(3), td:nth-child(3) {
            width: 25%;
        }
        th {
            background-color: #f2f2f2;
        }
        .passenger-info {
            display: flex;
            flex-direction: column;
            gap: 8px;
            padding: 5px 0;
        }
        .passenger-details {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            font-size: 0.9em;
            color: #555;
            margin-top: 5px;
            line-height: 1.4;
        }
        .passenger-type {
            display: flex;
            align-items: center;
        }
        .passenger-type i {
            margin-right: 5px;
        }
        .signature-block {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
        }
        .signature {
            width: 30%;
            text-align: center;
            border-top: 1px solid #000;
            padding-top: 5px;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            font-size: 10pt;
            color: #666;
        }
        .company-name {
            font-size: 9pt;
            color: #888;
            text-align: center;
            margin-top: 5px;
        }
        @media print {
            body {
                padding: 5px;
            }
            .no-print {
                display: none;
            }
            table {
                page-break-inside: auto;
            }
            th {
                background-color: #f2f2f2 !important;
                -webkit-print-color-adjust: exact;
            }
            .patient {
                background-color: #e3f2fd !important;
                -webkit-print-color-adjust: exact;
            }
            .companion {
                background-color: #f5f5f5 !important;
                -webkit-print-color-adjust: exact;
            }
            td {
                page-break-inside: auto;
            }
            .info-container {
                page-break-inside: auto;
            }
            table {
                page-break-inside: auto;
            }
            .signature-block {
                margin-top: 20px;
            }
            .footer {
                margin-top: 20px;
            }
            .info-container {
                margin-bottom: 5px;
            }
            .trip-notes {
                margin-bottom: 5px;
            }
            .info-block h2 {
                margin: 5px 0;
            }
            table {
                margin-top: 5px;
            }
            br {
                display: none;
            }
            .info-block {
                margin-bottom: 5px;
            }
        }
        .patient {
            background-color: #e3f2fd;
            font-weight: bold;
            border: 2px solid #007bff;
            border-radius: 10px;
            margin: 10px 0;
            padding: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .companion {
            background-color: #f5f5f5;
            border-left: 3px solid #007bff;
            margin-left: 20px;
            padding: 8px;
            margin-bottom: 5px;
        }
        td {
            line-height: 1.6;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }
    </style>
</head>
<body>
    <div class="info-container">
        <div class="info-block">
            <div class="logo-container">
                <?php if (!empty($settings['city_logo'])): ?>
                    <img src="data:<?= $settings['logo_mime_type'] ?>;base64,<?= base64_encode($settings['city_logo']) ?>" alt="Logo" class="logo">
                <?php endif; ?>

            </div>
            <div class="header-text">
                <h1><?= htmlspecialchars($settings['city_name']).' / '.'ESPELHO DE VIAGEM #'.$trip_id ?></h1>
                <p>Secretaria Municipal de Saúde de Ipaussu</p>
            </div>
        </div>
        <div class="info-block">
            <h2>Informações da Viagem</h2>
            <div class="info-row">
                <div class="info-label">Data:</div>
                <div class="info-value"><?= date('d/m/Y', strtotime($trip['trip_date'])) ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Horário de Saída:</div>
                <div class="info-value"><?= date('H:i', strtotime($trip['departure_time'])) ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Destino:</div>
                <div class="info-value"><?= htmlspecialchars($trip['location_city']) ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Distância:</div>
                <div class="info-value"><?= $trip['distance'] ?> km</div>
            </div>
        </div>
    </div>

    
    <div class="info-container">
         <div class="info-block">
            <h2>Veículo e Motorista</h2>
            <div class="info-row">
                <div class="info-label">Veículo:</div>
                <div class="info-value"><?= htmlspecialchars($trip['plate']) ?> - <?= htmlspecialchars($trip['model']) ?> <?= htmlspecialchars($trip['brand']) ?></div>
            </div>
            <div class="info-row">
                <div class="info-label">Motorista:</div>
                <div class="info-value"><?= htmlspecialchars($trip['driver_name']) ?></div>
            </div>
            <div class="info-row">
                <div class="info-label"><?php //Profissional:?></div>
                <div class="info-value"><?php //htmlspecialchars($trip['professional_name']) ?></div>
            </div>
        </div>


        <div class="info-block">
            <?php if ($trip['notes']): ?>
            <div class="trip-notes">
                <h2>Observações/Lembrete da Viagem</h2>
                <p><?= nl2br(htmlspecialchars($trip['notes'])) ?></p>
            </div>
            <?php endif; ?>
        </div>
        

    </div>
    

    
    <div class="info-block">
        <h2>Passageiros</h2>
        <?php if (count($passengers) > 0): ?>
            <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Local de Destino e Espera</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $current_group = null;
            foreach ($passengers as $passenger): 
                if ($passenger['group_id'] != $current_group) {
                    if ($current_group !== null) {
                        echo '</tr>'; // Fecha a linha anterior
                    }
                    $current_group = $passenger['group_id'];
                }
                
                // Adicionar classe CSS específica para paciente/acompanhante
                $class = $passenger['is_companion'] == 0 ? 'patient' : 'companion';
            ?>
                <tr class="<?= $class ?>">
                    <td>
                        <div class="passenger-info">
                            <strong><?= htmlspecialchars($passenger['patient_name']) ?>
                        <?php if ($passenger['is_companion']): ?>
                            <i class="fas fa-user-friends"></i> 
                        <?php endif; ?>                                

                            </strong>
                            <div class="passenger-details">
                                <span>CNS: <?= $passenger['patient_cns'] ?>
                                <?php if (!empty($passenger['patient_phone'])): ?>
                                    <span>- Tel: <?= $passenger['patient_phone'] ?></span>
                                <?php endif; ?>
                                </span>
                            </div>
                        </div>
                    </td>
                    <td>
                        <?= htmlspecialchars($passenger['location_name'] ?? 'Não especificado') ?>
                        <?php if (!empty($passenger['location_city'])): ?>
                            <small class="d-block"><?= htmlspecialchars($passenger['location_city']) ?></small>
                        <?php endif; ?>
                        <?php if (!empty($passenger['appointment_time'])): ?>
                            <?php echo '<br>Horário: '.date('H:i', strtotime($passenger['appointment_time'])) ?>
                        <?php else: ?>
                            <span class="text-muted">Horário: Não definido</span>
                        <?php endif; ?>
                        <?php if ($passenger['notes'] != null): ?>
                            <br>Local de Espera: <?= nl2br(htmlspecialchars($passenger['notes'] ?? '')) ?>  
                        <?php endif; ?>                                              
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
        <?php else: ?>
            <p>Nenhum passageiro registrado para esta viagem.</p>
        <?php endif; ?>
    </div>
    <br>
    <div>.</div><br>
    <div>.</div><br>
    <div class="signature-block">
        <br><br>
        <div class="signature">
            Motorista
        </div>
        <div class="signature">
            Responsável pelo Setor
        </div>
    </div>
    
    <div class="footer">
        Documento gerado em <?= date('d/m/Y H:i:s') ?>
        <br>
        Sistema de Gerenciamento de Transporte e BPA-I
        <div class="company-name">Lag Sistemas</div>
    </div>
    
    <div class="no-print" style="margin-top: 20px; text-align: center;">
        <button onclick="window.print();" style="padding: 10px 20px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">
            Imprimir
        </button>
        <button onclick="window.close();" style="padding: 10px 20px; background-color: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer; margin-left: 10px;">
            Fechar
        </button>
    </div>

    <!-- Font Awesome para ícones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</body>
</html>
