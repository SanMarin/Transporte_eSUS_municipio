<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
session_start();
require_once('../app_trans/config/config.php');
require_once('../config/database_transp.php');
require_once('includes/functions.php');

// Estabelecer conexão com o banco de dados
$conn = connectMySQL();

// Verificar se o usuário está logado e tem permissão de administrador
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Verificar permissão
if (!hasPermission('manage_users') && (!isset($_SESSION['role_id']) || $_SESSION['role_id'] < 2)) {
    header("Location: index.php?error=permission");
    exit();
}

// Processar ações
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Adicionar usuário
        if ($_POST['action'] === 'add') {
            $username = $conn->real_escape_string($_POST['username']);
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $name = $conn->real_escape_string($_POST['name']);
            $email = $conn->real_escape_string($_POST['email']);
            $role_id = (int)$_POST['role_id'];
            
            // Verificar se o nome de usuário já existe
            $check_query = "SELECT id FROM users WHERE username = '$username'";
            $check_result = $conn->query($check_query);
            
            if ($check_result->num_rows > 0) {
                $message = "Nome de usuário já existe. Por favor, escolha outro.";
                $messageType = "danger";
            } else {
                $query = "INSERT INTO users (username, password, name, email, role_id, active) 
                          VALUES ('$username', '$password', '$name', '$email', $role_id, 1)";
                
                if ($conn->query($query)) {
                    $message = "Usuário adicionado com sucesso!";
                    $messageType = "success";
                    
                    // Registrar atividade
                    log_activity($_SESSION['user_id'], 'add_user', "Adicionou o usuário: $username");
                } else {
                    $message = "Erro ao adicionar usuário: " . $conn->error;
                    $messageType = "danger";
                }
            }
        }
        
        // Editar usuário
        else if ($_POST['action'] === 'edit') {
            $id = (int)$_POST['id'];
            $name = $conn->real_escape_string($_POST['name']);
            $email = $conn->real_escape_string($_POST['email']);
            $role_id = (int)$_POST['role_id'];
            $active = isset($_POST['active']) ? 1 : 0;
            
            $query = "UPDATE users SET 
                      name = '$name', 
                      email = '$email', 
                      role_id = $role_id, 
                      active = $active 
                      WHERE id = $id";
            
            if ($conn->query($query)) {
                // Se uma nova senha foi fornecida, atualizá-la
                if (!empty($_POST['password'])) {
                    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    $query = "UPDATE users SET password = '$password' WHERE id = $id";
                    $conn->query($query);
                }
                
                $message = "Usuário atualizado com sucesso!";
                $messageType = "success";
                
                // Registrar atividade
                log_activity($_SESSION['user_id'], 'edit_user', "Editou o usuário ID: $id");
            } else {
                $message = "Erro ao atualizar usuário: " . $conn->error;
                $messageType = "danger";
            }
        }
        
        // Excluir usuário
        else if ($_POST['action'] === 'delete') {
            $id = (int)$_POST['id'];
            
            // Não permitir excluir o próprio usuário
            if ($id === $_SESSION['user_id']) {
                $message = "Você não pode excluir seu próprio usuário!";
                $messageType = "danger";
            } else {
                // Obter o nome do usuário antes de excluí-lo
                $get_name_query = "SELECT username FROM users WHERE id = $id";
                $get_name_result = $conn->query($get_name_query);
                $user_data = $get_name_result->fetch_assoc();
                $username = $user_data['username'];
                
                $query = "DELETE FROM users WHERE id = $id";
                
                if ($conn->query($query)) {
                    $message = "Usuário excluído com sucesso!";
                    $messageType = "success";
                    
                    // Registrar atividade
                    log_activity($_SESSION['user_id'], 'delete_user', "Excluiu o usuário: $username");
                } else {
                    $message = "Erro ao excluir usuário: " . $conn->error;
                    $messageType = "danger";
                }
            }
        }
    }
}

// Obter usuários
$query = "SELECT u.*, r.role_name 
          FROM users u 
          LEFT JOIN user_roles r ON u.role_id = r.id 
          ORDER BY u.name";
$users_result = $conn->query($query);

// Obter perfis
$query = "SELECT * FROM user_roles ORDER BY id";
$roles_result = $conn->query($query);

$page_title = "Gerenciamento de Usuários";
// Definir variável para controlar a exibição do cabeçalho
$skip_main_header = true;
include('includes/header.php');
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php //include 'includes/sidebar.php'; ?>
        
        <!-- Conteúdo principal -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><?php echo $page_title; ?></h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
                        <i class="bi bi-plus-circle"></i> Novo Usuário
                    </button>
                </div>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                </div>
            <?php endif; ?>
            
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome de Usuário</th>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>Perfil</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($user = $users_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['name']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['role_name'] ?? 'Não definido'); ?></td>
                                <td>
                                    <?php if ($user['active']): ?>
                                        <span class="badge bg-success">Ativo</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Inativo</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editUserModal<?php echo $user['id']; ?>">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteUserModal<?php echo $user['id']; ?>">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            
                            <!-- Modal de Edição -->
                            <div class="modal fade" id="editUserModal<?php echo $user['id']; ?>" tabindex="-1" aria-labelledby="editUserModalLabel<?php echo $user['id']; ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="editUserModalLabel<?php echo $user['id']; ?>">Editar Usuário</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                        </div>
                                        <form method="POST" action="">
                                            <div class="modal-body">
                                                <input type="hidden" name="action" value="edit">
                                                <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label for="username<?php echo $user['id']; ?>" class="form-label">Nome de Usuário</label>
                                                    <input type="text" class="form-control" id="username<?php echo $user['id']; ?>" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="name<?php echo $user['id']; ?>" class="form-label">Nome</label>
                                                    <input type="text" class="form-control" id="name<?php echo $user['id']; ?>" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="email<?php echo $user['id']; ?>" class="form-label">E-mail</label>
                                                    <input type="email" class="form-control" id="email<?php echo $user['id']; ?>" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="password<?php echo $user['id']; ?>" class="form-label">Nova Senha (deixe em branco para manter a atual)</label>
                                                    <input type="password" class="form-control" id="password<?php echo $user['id']; ?>" name="password">
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="role_id<?php echo $user['id']; ?>" class="form-label">Perfil</label>
                                                    <select class="form-select" id="role_id<?php echo $user['id']; ?>" name="role_id" required>
                                                        <?php 
                                                        // Resetar o ponteiro do resultado
                                                        $roles_result->data_seek(0);
                                                        while ($role = $roles_result->fetch_assoc()): 
                                                        ?>
                                                            <option value="<?php echo $role['id']; ?>" <?php echo ($user['role_id'] == $role['id']) ? 'selected' : ''; ?>>
                                                                <?php echo htmlspecialchars($role['role_name']); ?>
                                                            </option>
                                                        <?php endwhile; ?>
                                                    </select>
                                                </div>
                                                
                                                <div class="mb-3 form-check">
                                                    <input type="checkbox" class="form-check-input" id="active<?php echo $user['id']; ?>" name="active" <?php echo $user['active'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label" for="active<?php echo $user['id']; ?>">Ativo</label>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                <button type="submit" class="btn btn-primary">Salvar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Modal de Exclusão -->
                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                <div class="modal fade" id="deleteUserModal<?php echo $user['id']; ?>" tabindex="-1" aria-labelledby="deleteUserModalLabel<?php echo $user['id']; ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="deleteUserModalLabel<?php echo $user['id']; ?>">Confirmar Exclusão</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Tem certeza de que deseja excluir o usuário <strong><?php echo htmlspecialchars($user['username']); ?></strong>?</p>
                                                <p class="text-danger">Esta ação não pode ser desfeita.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                <form method="POST" action="">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                                    <button type="submit" class="btn btn-danger">Excluir</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>

<!-- Modal de Adição -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Novo Usuário</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">Nome de Usuário</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="name" class="form-label">Nome</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">E-mail</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Senha</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="role_id" class="form-label">Perfil</label>
                        <select class="form-select" id="role_id" name="role_id" required>
                            <?php 
                            // Resetar o ponteiro do resultado
                            $roles_result->data_seek(0);
                            while ($role = $roles_result->fetch_assoc()): 
                            ?>
                                <option value="<?php echo $role['id']; ?>">
                                    <?php echo htmlspecialchars($role['role_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Adicionar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
