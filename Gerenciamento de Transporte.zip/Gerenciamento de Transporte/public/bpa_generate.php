<?php
require_once '../config/database_transp.php';
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

// Iniciar buffer de saída para permitir envio de cabeçalhos posteriormente
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Processar download de arquivo BPA
if (isset($_GET['download']) && is_numeric($_GET['download'])) {
    $header_id = $_GET['download'];
    
    // Obter dados do cabeçalho
    $stmt = $conn->prepare("SELECT * FROM bpa_headers WHERE id = ?");
    $stmt->bind_param("i", $header_id);
    $stmt->execute();
    $header = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$header) {
        $error = "Cabeçalho não encontrado.";
    } else if ($header['status'] !== 'finalized') {
        $error = "Este cabeçalho ainda não foi finalizado.";
    } else {
        // Obter configurações
        $settings = getSettings();
        
        // Obter registros BPA
        $stmt = $conn->prepare("SELECT * FROM bpa_records WHERE header_id = ? ORDER BY prd_flh, prd_seq");
        $stmt->bind_param("i", $header_id);
        $stmt->execute();
        $records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Gerar arquivo BPA
        $filename = "BPA_" . $header['cbc_mvm'] . ".txt";
        
        // Iniciar buffer de saída
        ob_start();
        
        // Escrever cabeçalho
        echo "01";                                                // cbc-hdr (2)
        echo "#BPA#";                                             // cbc-hdr (5)
        echo $header['cbc_mvm'];                                  // cbc-mvm (6)
        echo str_pad($header['cbc_lin'], 6, "0", STR_PAD_LEFT);   // cbc-lin (6)
        echo str_pad($header['cbc_flh'], 6, "0", STR_PAD_LEFT);   // cbc-flh (6)
        echo str_pad($header['cbc_smt_vrf'], 4, "0", STR_PAD_LEFT); // cbc-smt-vrf (4)
        echo str_pad($settings['cbc_rsp'], 30, " ", STR_PAD_RIGHT); // cbc-rsp (30)
        echo str_pad($settings['cbc_sgl'], 6, " ", STR_PAD_RIGHT);  // cbc-sgl (6)
        echo str_pad($settings['cbc_cgccpf'], 14, "0", STR_PAD_LEFT); // cbc-cgccpf (14)
        echo str_pad($settings['cbc_dst'], 40, " ", STR_PAD_RIGHT);   // cbc-dst (40)
        echo $settings['cbc_dst_in'];                             // cbc-dst-in (1)
        echo str_pad($settings['cbc_versao'], 10, " ", STR_PAD_RIGHT); // cbc_versao (10)
        echo "\r\n";                                              // cbc-fim (2)
        
        // Função para remover acentos e caracteres especiais
        function removeAcentos($string) {
            $string = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
            return preg_replace('/[^A-Za-z0-9\s\.\,\-\_]/', '', $string); 
        }
        $cid = "";
        $raca = "";
        $etinia = "";
        $nasc = "";
        // Exemplo de uso dentro do loop
        foreach ($records as $record) {
            echo "03";                                                 
            echo str_pad($record['prd_cnes'], 7, "0", STR_PAD_LEFT);  
            echo $record['prd_cmp'];                                  
            echo str_pad($record['prd_cnsmed'], 15, "0", STR_PAD_LEFT); 
            echo str_pad($record['prd_cbo'], 6, " ", STR_PAD_RIGHT);  
            echo date('Ymd', strtotime($record['prd_dtaten']));       
            echo str_pad($record['prd_flh'], 3, "0", STR_PAD_LEFT);   
            echo str_pad($record['prd_seq'], 2, "0", STR_PAD_LEFT);   
            echo str_pad($record['prd_pa'], 10, "0", STR_PAD_LEFT);   
            echo str_pad($record['prd_cnspac'], 15, "0", STR_PAD_LEFT);
            echo $record['prd_sexo'];                                 
            echo '352090';
            echo str_pad($cid, 4, " ", STR_PAD_RIGHT);
            //echo str_pad($record['prd_cid'], 4, " ", STR_PAD_RIGHT);  
            echo str_pad($record['prd_idade'], 3, "0", STR_PAD_LEFT); 
            echo str_pad($record['prd_qt'], 6, "0", STR_PAD_LEFT);    
            echo str_pad($record['prd_caten'] ?? "", 2, "0", STR_PAD_LEFT); 
            echo str_pad($record['prd_naut'] ?? "", 13, " ", STR_PAD_RIGHT); 
            echo str_pad($record['prd_org'], 3, " ", STR_PAD_RIGHT);  
            echo str_pad(removeAcentos($record['prd_nmpac']), 30, " ", STR_PAD_RIGHT);
            echo date('Ymd', strtotime($record['prd_dtnasc']));       
            echo str_pad($raca, 2, " ", STR_PAD_RIGHT);
            echo str_pad($etinia, 4, " ", STR_PAD_RIGHT);
            echo str_pad($nasc, 3, " ", STR_PAD_RIGHT);
            //echo str_pad($record['prd_raca'] ?? "", 2, " ", STR_PAD_RIGHT); 
            //echo str_pad($record['prd_etnia'] ?? "", 4, " ", STR_PAD_RIGHT); 
            //echo str_pad($record['prd_nac'] ?? "", 3, " ", STR_PAD_RIGHT); 
            echo str_pad($record['prd_srv'] ?? "", 3, " ", STR_PAD_RIGHT); 
            echo str_pad($record['prd_clf'] ?? "", 3, " ", STR_PAD_RIGHT); 
            echo str_pad($record['prd_equipe_seq'] ?? "", 8, " ", STR_PAD_RIGHT); 
            echo str_pad($record['prd_equipe_area'] ?? "", 4, " ", STR_PAD_RIGHT); 
            echo str_pad($record['prd_cnpj'] ?? "", 14, " ", STR_PAD_RIGHT); 
            
            echo str_pad($record['prd_cep'] ?? "", 8, " ", STR_PAD_RIGHT); 
            echo str_pad($record['prd_lograd'] ?? "", 3, " ", STR_PAD_RIGHT); 
            echo str_pad(removeAcentos($record['prd_end'] ?? ""), 30, " ", STR_PAD_RIGHT); // <-- logradouro sem acento
            echo str_pad(removeAcentos($record['prd_compl'] ?? ""), 10, " ", STR_PAD_RIGHT); 
            echo str_pad($record['prd_num'] ?? "", 5, " ", STR_PAD_RIGHT); 
            echo str_pad(removeAcentos($record['prd_bairro'] ?? ""), 30, " ", STR_PAD_RIGHT); // <-- bairro sem acento
            echo str_pad($record['prd_ddtel'] ?? "", 11, " ", STR_PAD_RIGHT); 
            echo str_pad(removeAcentos($record['prd_email'] ?? ""), 40, " ", STR_PAD_RIGHT); 
            echo str_pad($record['prd_ine'] ?? "", 10, " ", STR_PAD_RIGHT); 
            echo "\r\n";                                              
        }
        
        $content = ob_get_clean();
        
        // Enviar arquivo para download
        // Limpar qualquer saída anterior
        ob_clean();
        
        header('Content-Description: File Transfer');
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename=' . $filename);
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . strlen($content));
        echo $content;
        exit;
    }
}

// Processar geração de BPA
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'generate' && isset($_POST['competence'])) {
        $competence = $_POST['competence'];
        $update_existing = isset($_POST['update_existing']) && $_POST['update_existing'] == 1;
        
        // Verificar se já existe um cabeçalho para esta competência
        $stmt = $conn->prepare("SELECT id, status FROM bpa_headers WHERE cbc_mvm = ?");
        $stmt->bind_param("s", $competence);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $header = $result->fetch_assoc();
            $header_id = $header['id'];
            
            // Se estamos atualizando um BPA existente e ele está finalizado, precisamos reabri-lo
            if ($update_existing && $header['status'] === 'finalized') {
                $stmt = $conn->prepare("UPDATE bpa_headers SET status = 'draft' WHERE id = ?");
                $stmt->bind_param("i", $header_id);
                $stmt->execute();
            }
        } else {
            // Criar novo cabeçalho
            $stmt = $conn->prepare("INSERT INTO bpa_headers (cbc_mvm, status) VALUES (?, 'draft')");
            $stmt->bind_param("s", $competence);
            $stmt->execute();
            $header_id = $conn->insert_id;
        }
        
        // Se estamos atualizando, precisamos resetar os flags de geração para permitir regenerar
        if ($update_existing) {
            $month = substr($competence, 4, 2);
            $year = substr($competence, 0, 4);
            
            $stmt = $conn->prepare("
                UPDATE trip_passengers tp
                JOIN trips t ON tp.trip_id = t.id
                SET tp.bpa_transport_generated = 0, tp.bpa_food_generated = 0
                WHERE MONTH(t.trip_date) = ? AND YEAR(t.trip_date) = ?
                  AND t.status = 'completed'
            ");
            $stmt->bind_param("ss", $month, $year);
            $stmt->execute();
        }
        
        // Obter configurações
        $settings = getSettings();
        
        // Obter CNES da configuração (exemplo)
        $cnes = isset($settings['cnes']) ? $settings['cnes'] : "1234567"; // Deve ser configurado nas configurações do sistema
        
        // Obter viagens da competência
        $month = substr($competence, 4, 2);
        $year = substr($competence, 0, 4);
        
        // Modificar a consulta para verificar se as colunas existem na tabela trip_passengers
        // Primeiro, verificamos se as colunas existem
        $checkColumnsQuery = "SHOW COLUMNS FROM trip_passengers LIKE 'bpa_transport_generated'";
        $result = $conn->query($checkColumnsQuery);
        $transportColumnExists = $result->num_rows > 0;
        
        $checkColumnsQuery = "SHOW COLUMNS FROM trip_passengers LIKE 'bpa_food_generated'";
        $result = $conn->query($checkColumnsQuery);
        $foodColumnExists = $result->num_rows > 0;
        
        // Se as colunas não existirem, vamos adicioná-las
        if (!$transportColumnExists) {
            $conn->query("ALTER TABLE trip_passengers ADD COLUMN bpa_transport_generated TINYINT(1) NOT NULL DEFAULT 0");
        }
        
        if (!$foodColumnExists) {
            $conn->query("ALTER TABLE trip_passengers ADD COLUMN bpa_food_generated TINYINT(1) NOT NULL DEFAULT 0");
        }
        
        // Agora podemos continuar com a consulta principal
        $stmt = $conn->prepare("
            SELECT tp.id, tp.trip_id, tp.patient_id, tp.is_companion, tp.cid_id,
                   t.trip_date, t.professional_id, l.distance, l.procedure_count,
                   p.name as patient_name, p.cns as patient_cns, p.birth_date, p.sex,
                   p.race, p.ethnicity, p.nationality, p.ibge_code, p.cep, p.address_type,
                   p.address, p.address_number, p.address_complement, p.neighborhood,
                   p.phone, p.email,
                   pr.cns as professional_cns, pr.cbo,
                   c.code as cid_code,
                   tp.bpa_transport_generated, tp.bpa_food_generated
            FROM trip_passengers tp
            JOIN trips t ON tp.trip_id = t.id
            JOIN locations l ON t.location_id = l.id
            JOIN patients p ON tp.patient_id = p.id
            JOIN professionals pr ON t.professional_id = pr.id
            JOIN cid10 c ON tp.cid_id = c.id
            WHERE MONTH(t.trip_date) = ? AND YEAR(t.trip_date) = ?
              AND t.status = 'completed'
              AND (tp.bpa_transport_generated = 0 OR tp.bpa_food_generated = 0)
        ");
        $stmt->bind_param("ss", $month, $year);
        $stmt->execute();
        $passengers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Contador para folha e sequência
        $folha = 1;
        $sequencia = 1;
        
        // Processar cada passageiro
        foreach ($passengers as $passenger) {
            // Calcular idade em anos
            $birthDate = new DateTime($passenger['birth_date']);
            $today = new DateTime();
            $age = $birthDate->diff($today)->y;
            
            // Procedimento de transporte - APENAS UM REGISTRO POR PASSAGEIRO
            if (!isset($passenger['bpa_transport_generated']) || $passenger['bpa_transport_generated'] == 0) {
                // Verificar se precisa avançar para nova folha
                if ($sequencia > 20) {
                    $folha++;
                    $sequencia = 1;
                }
                
                // Preparar todas as variáveis antes de bind_param
                $folha_str = str_pad($folha, 3, "0", STR_PAD_LEFT);
                $seq_str = str_pad($sequencia, 2, "0", STR_PAD_LEFT);
                $idade_str = str_pad($age, 3, "0", STR_PAD_LEFT);
                
                // Usar a quantidade de procedimentos da tabela locations
                $procedure_count = $passenger['procedure_count'];
                $qt_str = str_pad($procedure_count, 6, "0", STR_PAD_LEFT);
                
                $org = "BPA";
                $proc_code = "0803010125"; // Código do procedimento de transporte
                
                // Preparar variáveis para campos que podem ser nulos
                $patient_ibge = $passenger['ibge_code'] ?? "";
                $patient_race = $passenger['race'] ?? "";
                $patient_ethnicity = $passenger['ethnicity'] ?? "";
                $patient_nationality = $passenger['nationality'] ?? "";
                $patient_cep = $passenger['cep'] ?? "";
                $patient_address_type = $passenger['address_type'] ?? "";
                $patient_address = $passenger['address'] ?? "";
                $patient_complement = $passenger['address_complement'] ?? "";
                $patient_number = $passenger['address_number'] ?? "";
                $patient_neighborhood = $passenger['neighborhood'] ?? "";
                $patient_phone = $passenger['phone'] ?? "";
                $patient_email = $passenger['email'] ?? "";
                
                $stmt = $conn->prepare("
                    INSERT INTO bpa_records (
                        header_id, prd_cnes, prd_cmp, prd_cnsmed, prd_cbo, prd_dtaten,
                        prd_flh, prd_seq, prd_pa, prd_cnspac, prd_sexo, prd_ibge,
                        prd_cid, prd_idade, prd_qt, prd_org, prd_nmpac, prd_dtnasc,
                        prd_raca, prd_etnia, prd_nac, prd_cep, prd_lograd, prd_end,
                        prd_compl, prd_num, prd_bairro, prd_ddtel, prd_email,
                        trip_passenger_id
                    ) VALUES (
                        ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?,
                        ?
                    )
                ");
                
                $stmt->bind_param(
                    "issssssssssssssssssssssssssssi",
                    $header_id, $cnes, $competence, $passenger['professional_cns'], $passenger['cbo'], $passenger['trip_date'],
                    $folha_str, $seq_str, $proc_code, $passenger['patient_cns'], $passenger['sex'], $patient_ibge,
                    $passenger['cid_code'], $idade_str, $qt_str, $org, $passenger['patient_name'], $passenger['birth_date'],
                    $patient_race, $patient_ethnicity, $patient_nationality, $patient_cep, $patient_address_type, $patient_address,
                    $patient_complement, $patient_number, $patient_neighborhood, $patient_phone, $patient_email,
                    $passenger['id']
                );
                
                $stmt->execute();
                $sequencia++;
                
                // Marcar transporte como gerado
                $stmt = $conn->prepare("UPDATE trip_passengers SET bpa_transport_generated = 1 WHERE id = ?");
                $stmt->bind_param("i", $passenger['id']);
                $stmt->execute();
            }
            
            // Procedimento de alimentação - APENAS UM REGISTRO POR PASSAGEIRO
            if (!isset($passenger['bpa_food_generated']) || $passenger['bpa_food_generated'] == 0) {
                // Verificar se precisa avançar para nova folha
                if ($sequencia > 20) {
                    $folha++;
                    $sequencia = 1;
                }
                
                // Preparar todas as variáveis antes de bind_param
                $folha_str = str_pad($folha, 3, "0", STR_PAD_LEFT);
                $seq_str = str_pad($sequencia, 2, "0", STR_PAD_LEFT);
                $idade_str = str_pad($age, 3, "0", STR_PAD_LEFT);
                // Usar a quantidade de procedimentos da tabela locations para alimentação também
                $procedure_count = $passenger['procedure_count'];
                $qt_str = str_pad($procedure_count, 6, "0", STR_PAD_LEFT);
                $org = "BPA";
                $proc_code = "0803010028"; // Código do procedimento de alimentação
                
                // Preparar variáveis para campos que podem ser nulos
                $patient_ibge = $passenger['ibge_code'] ?? "";
                $patient_race = $passenger['race'] ?? "";
                $patient_ethnicity = $passenger['ethnicity'] ?? "";
                $patient_nationality = $passenger['nationality'] ?? "";
                $patient_cep = $passenger['cep'] ?? "";
                $patient_address_type = $passenger['address_type'] ?? "";
                $patient_address = $passenger['address'] ?? "";
                $patient_complement = $passenger['address_complement'] ?? "";
                $patient_number = $passenger['address_number'] ?? "";
                $patient_neighborhood = $passenger['neighborhood'] ?? "";
                $patient_phone = $passenger['phone'] ?? "";
                $patient_email = $passenger['email'] ?? "";
                
                $stmt = $conn->prepare("
                    INSERT INTO bpa_records (
                        header_id, prd_cnes, prd_cmp, prd_cnsmed, prd_cbo, prd_dtaten,
                        prd_flh, prd_seq, prd_pa, prd_cnspac, prd_sexo, prd_ibge,
                        prd_cid, prd_idade, prd_qt, prd_org, prd_nmpac, prd_dtnasc,
                        prd_raca, prd_etnia, prd_nac, prd_cep, prd_lograd, prd_end,
                        prd_compl, prd_num, prd_bairro, prd_ddtel, prd_email,
                        trip_passenger_id
                    ) VALUES (
                        ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?,
                        ?
                    )
                ");
                
                $stmt->bind_param(
                    "issssssssssssssssssssssssssssi",
                    $header_id, $cnes, $competence, $passenger['professional_cns'], $passenger['cbo'], $passenger['trip_date'],
                    $folha_str, $seq_str, $proc_code, $passenger['patient_cns'], $passenger['sex'], $patient_ibge,
                    $passenger['cid_code'], $idade_str, $qt_str, $org, $passenger['patient_name'], $passenger['birth_date'],
                    $patient_race, $patient_ethnicity, $patient_nationality, $patient_cep, $patient_address_type, $patient_address,
                    $patient_complement, $patient_number, $patient_neighborhood, $patient_phone, $patient_email,
                    $passenger['id']
                );
                
                $stmt->execute();
                $sequencia++;
                
                // Marcar alimentação como gerada
                $stmt = $conn->prepare("UPDATE trip_passengers SET bpa_food_generated = 1 WHERE id = ?");
                $stmt->bind_param("i", $passenger['id']);
                $stmt->execute();
            }
        }
        
        // Atualizar contadores do cabeçalho
        $stmt = $conn->prepare("
            UPDATE bpa_headers 
            SET 
                cbc_lin = (SELECT COUNT(*) FROM bpa_records WHERE header_id = ?),
                cbc_flh = ?
            WHERE id = ?
        ");
        $stmt->bind_param("iii", $header_id, $folha, $header_id);
        $stmt->execute();
        
        $message = "Registros BPA-I gerados com sucesso para a competência $competence.";
    }
}

// Obter competências disponíveis (meses com viagens)
$result = $conn->query("
    SELECT DISTINCT 
        CONCAT(YEAR(trip_date), LPAD(MONTH(trip_date), 2, '0')) as competence,
        CONCAT(YEAR(trip_date), '/', LPAD(MONTH(trip_date), 2, '0')) as competence_formatted
    FROM trips
    WHERE status = 'completed'
    ORDER BY competence DESC
");
$competences = $result->fetch_all(MYSQLI_ASSOC);

// Obter cabeçalhos existentes
$result = $conn->query("
    SELECT h.*, 
           (SELECT COUNT(*) FROM bpa_records WHERE header_id = h.id) as record_count
    FROM bpa_headers h
    ORDER BY h.cbc_mvm DESC
");
$headers = $result->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-file-export me-2"></i>Geração de BPA-I</h1>
    <a href="bpa_header.php" class="btn btn-outline-primary">
        <i class="fas fa-file-medical me-1"></i> Gerenciar Cabeçalhos
    </a>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Gerar BPA-I</h6>
            </div>
            <div class="card-body">
                <form method="post">
                    <input type="hidden" name="action" value="generate">
                    
                    <div class="mb-3">
                        <label for="competence" class="form-label">Competência</label>
                        <select class="form-select" id="competence" name="competence" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($competences as $comp): ?>
                                <option value="<?= $comp['competence'] ?>"><?= $comp['competence_formatted'] ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">Selecione o mês/ano para gerar o BPA-I</div>
                    </div>

                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Este processo irá gerar registros BPA-I para todas as viagens concluídas no período selecionado que ainda não foram processadas.
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-cogs me-1"></i> Gerar Registros BPA-I
                        </button>
                        
                        <button type="submit" name="update_existing" value="1" class="btn btn-warning">
                            <i class="fas fa-sync-alt me-1"></i> Atualizar BPA-I Existente
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Arquivos BPA-I Disponíveis</h6>
            </div>
            <div class="card-body">
                <?php if (count($headers) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Competência</th>
                                    <th>Registros</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($headers as $header): ?>
                                    <tr>
                                        <td>
                                            <?= substr($header['cbc_mvm'], 0, 4) ?>/<?= substr($header['cbc_mvm'], 4, 2) ?>
                                        </td>
                                        <td><?= $header['record_count'] ?></td>
                                        <td>
                                            <?php if ($header['status'] === 'draft'): ?>
                                                <span class="badge bg-warning">Rascunho</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Finalizado</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($header['status'] === 'finalized'): ?>
                                                <a href="?download=<?= $header['id'] ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-download me-1"></i> Baixar
                                                </a>
                                            <?php else: ?>
                                                <a href="bpa_header.php" class="btn btn-sm btn-secondary">
                                                    <i class="fas fa-edit me-1"></i> Finalizar
                                                </a>
                                            <?php endif; ?>
                                            <a href="bpa_records.php?header_id=<?= $header['id'] ?>" class="btn btn-sm btn-info">
                                                <i class="fas fa-eye me-1"></i> Visualizar
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-center">Nenhum arquivo BPA-I disponível.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Instruções</h6>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <h5>Como gerar o arquivo BPA-I:</h5>
                <ol>
                    <li>Selecione a competência (mês/ano) desejada</li>
                    <li>Clique em "Gerar Registros BPA-I"</li>
                    <li>Vá para "Gerenciar Cabeçalhos" e finalize o cabeçalho</li>
                    <li>Volte para esta tela e baixe o arquivo BPA-I</li>
                </ol>
            </div>
            <div class="col-md-6">
                <h5>Observações importantes:</h5>
                <ul>
                    <li>Apenas viagens com status "Concluída" são consideradas</li>
                    <li>Para cada passageiro são gerados dois registros: transporte e alimentação</li>
                    <li>A quantidade de procedimentos de transporte é calculada automaticamente com base na distância (1 a cada 50km)</li>
                    <li>O arquivo gerado segue o padrão BPA-I do DATASUS</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
