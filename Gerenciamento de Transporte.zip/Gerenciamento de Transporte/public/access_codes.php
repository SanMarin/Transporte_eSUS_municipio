<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

session_start();
require_once('../app_trans/config/config.php');
require_once('../config/database_transp.php');
require_once('includes/functions.php');

// Verificar se o usuário está logado e tem permissão
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Verificar permissão
if (!hasPermission('manage_drivers') && (!isset($_SESSION['role_id']) || $_SESSION['role_id'] < 2)) {
    header("Location: index.php?error=permission");
    exit();
}

// Estabelecer conexão com o banco de dados
$conn = connectMySQL();

// Verificar se a tabela de códigos de acesso existe
$check_table = $conn->query("SHOW COLUMNS FROM drivers LIKE 'access_code'");
if ($check_table->num_rows == 0) {
    // Adicionar coluna de código de acesso à tabela de motoristas
    $conn->query("ALTER TABLE drivers ADD COLUMN access_code VARCHAR(10) NULL");
    $conn->query("ALTER TABLE drivers ADD COLUMN access_code_generated_at TIMESTAMP NULL");
    $conn->query("ALTER TABLE drivers ADD COLUMN access_code_status ENUM('active', 'inactive') DEFAULT 'active'");
}

// Verificar se existe a coluna verification_code e migrar dados se necessário
$check_old_column = $conn->query("SHOW COLUMNS FROM drivers LIKE 'verification_code'");
if ($check_old_column->num_rows > 0) {
    // Migrar dados da coluna antiga para a nova
    $conn->query("UPDATE drivers SET access_code = verification_code WHERE verification_code IS NOT NULL AND access_code IS NULL");
    $conn->query("UPDATE drivers SET access_code_generated_at = NOW() WHERE verification_code IS NOT NULL AND access_code_generated_at IS NULL");
    $conn->query("UPDATE drivers SET access_code_status = 'active' WHERE verification_code IS NOT NULL AND access_code_status IS NULL");
    
    // Opcional: remover a coluna antiga após a migração
    // $conn->query("ALTER TABLE drivers DROP COLUMN verification_code");
    
    $message = "Códigos de acesso migrados com sucesso!";
    $messageType = "info";
}

// Processar ações
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Gerar novo código de acesso
        if ($_POST['action'] === 'generate') {
            $driver_id = (int)$_POST['driver_id'];
            
            // Gerar código único
            $access_code = generateUniqueAccessCode($conn);
            
            // Atualizar no banco de dados
            $query = "UPDATE drivers SET 
                      access_code = ?, 
                      access_code_generated_at = NOW(),
                      access_code_status = 'active'
                      WHERE id = ?";
            
            $stmt = $conn->prepare($query);
            $stmt->bind_param("si", $access_code, $driver_id);
            
            if ($stmt->execute()) {
                $message = "Código de acesso gerado com sucesso!";
                $messageType = "success";
                
                // Registrar atividade
                $driver_name = get_driver_name($driver_id);
                log_activity($_SESSION['user_id'], 'generate_access_code', "Gerou código de acesso para o motorista: $driver_name");
            } else {
                $message = "Erro ao gerar código de acesso: " . $conn->error;
                $messageType = "danger";
            }
            
            $stmt->close();
        }
        
        // Regenerar código de acesso
        else if ($_POST['action'] === 'regenerate') {
            $driver_id = (int)$_POST['driver_id'];
            
            // Gerar código único
            $access_code = generateUniqueAccessCode($conn);
            
            // Atualizar no banco de dados
            $query = "UPDATE drivers SET 
                      access_code = ?, 
                      access_code_generated_at = NOW(),
                      access_code_status = 'active'
                      WHERE id = ?";
            
            $stmt = $conn->prepare($query);
            $stmt->bind_param("si", $access_code, $driver_id);
            
            if ($stmt->execute()) {
                $message = "Código de acesso regenerado com sucesso!";
                $messageType = "success";
                
                // Registrar atividade
                $driver_name = get_driver_name($driver_id);
                log_activity($_SESSION['user_id'], 'regenerate_access_code', "Regenerou código de acesso para o motorista: $driver_name");
            } else {
                $message = "Erro ao regenerar código de acesso: " . $conn->error;
                $messageType = "danger";
            }
            
            $stmt->close();
        }
        
        // Revogar código de acesso
        else if ($_POST['action'] === 'revoke') {
            $driver_id = (int)$_POST['driver_id'];
            
            // Atualizar no banco de dados
            $query = "UPDATE drivers SET 
                      access_code_status = 'inactive'
                      WHERE id = ?";
            
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $driver_id);
            
            if ($stmt->execute()) {
                $message = "Código de acesso revogado com sucesso!";
                $messageType = "success";
                
                // Registrar atividade
                $driver_name = get_driver_name($driver_id);
                log_activity($_SESSION['user_id'], 'revoke_access_code', "Revogou código de acesso do motorista: $driver_name");
            } else {
                $message = "Erro ao revogar código de acesso: " . $conn->error;
                $messageType = "danger";
            }
            
            $stmt->close();
        }
        
        // Ativar código de acesso
        else if ($_POST['action'] === 'activate') {
            $driver_id = (int)$_POST['driver_id'];
            
            // Atualizar no banco de dados
            $query = "UPDATE drivers SET 
                      access_code_status = 'active'
                      WHERE id = ?";
            
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $driver_id);
            
            if ($stmt->execute()) {
                $message = "Código de acesso ativado com sucesso!";
                $messageType = "success";
                
                // Registrar atividade
                $driver_name = get_driver_name($driver_id);
                log_activity($_SESSION['user_id'], 'activate_access_code', "Ativou código de acesso do motorista: $driver_name");
            } else {
                $message = "Erro ao ativar código de acesso: " . $conn->error;
                $messageType = "danger";
            }
            
            $stmt->close();
        }
    }
}

// Obter lista de motoristas com seus códigos de acesso
$query = "SELECT d.id, d.name, d.document, d.license_number, d.active,
          d.access_code, d.access_code_generated_at, d.access_code_status
          FROM drivers d
          ORDER BY d.name";
$drivers_result = $conn->query($query);

// Função para gerar um código de acesso único
function generateUniqueAccessCode($conn) {
    $unique = false;
    $code = '';
    
    while (!$unique) {
        // Gerar código alfanumérico de 6 caracteres
        $code = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 6));
        
        // Verificar se o c��digo já existe
        $query = "SELECT id FROM drivers WHERE access_code = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $code);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 0) {
            $unique = true;
        }
        
        $stmt->close();
    }
    
    return $code;
}

$page_title = "Gerenciamento de Códigos de Acesso";
// Definir variável para controlar a exibição do cabeçalho
$skip_main_header = true;
include('includes/header.php');
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php// include 'includes/sidebar.php'; ?>
        
        <!-- Conteúdo principal -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><?php echo $page_title; ?></h1>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                </div>
            <?php endif; ?>
            
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-key me-1"></i>
                    Códigos de Acesso dos Motoristas
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <h5>Sobre os Códigos de Acesso</h5>
                        <p>Os códigos de acesso permitem que os motoristas façam login no Portal do Motorista usando um código único, sem necessidade de senha.</p>
                        <ul>
                            <li>Gere códigos para novos motoristas</li>
                            <li>Regenere códigos periodicamente para maior segurança</li>
                            <li>Revogue códigos quando necessário</li>
                        </ul>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Documento</th>
                                    <th>Código de Acesso</th>
                                    <th>Status</th>
                                    <th>Data de Geração</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($driver = $drivers_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($driver['name']); ?></td>
                                        <td><?php echo format_cpf(htmlspecialchars($driver['document'])); ?></td>
                                        <td>
                                            <?php if (!empty($driver['access_code'])): ?>
                                                <span class="badge bg-dark"><?php echo htmlspecialchars($driver['access_code']); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">Não gerado</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if (empty($driver['access_code'])): ?>
                                                <span class="badge bg-secondary">Não gerado</span>
                                            <?php elseif ($driver['access_code_status'] == 'active'): ?>
                                                <span class="badge bg-success">Ativo</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Inativo</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if (!empty($driver['access_code_generated_at'])): ?>
                                                <?php echo format_datetime($driver['access_code_generated_at']); ?>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if (empty($driver['access_code'])): ?>
                                                <form method="POST" action="" class="d-inline">
                                                    <input type="hidden" name="action" value="generate">
                                                    <input type="hidden" name="driver_id" value="<?php echo $driver['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-primary" title="Gerar Código">
                                                        <i class="fas fa-key"></i> Gerar
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <form method="POST" action="" class="d-inline">
                                                    <input type="hidden" name="action" value="regenerate">
                                                    <input type="hidden" name="driver_id" value="<?php echo $driver['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-warning" title="Regenerar Código">
                                                        <i class="fas fa-sync-alt"></i> Regenerar
                                                    </button>
                                                </form>
                                                
                                                <?php if ($driver['access_code_status'] == 'active'): ?>
                                                    <form method="POST" action="" class="d-inline">
                                                        <input type="hidden" name="action" value="revoke">
                                                        <input type="hidden" name="driver_id" value="<?php echo $driver['id']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-danger" title="Revogar Código">
                                                            <i class="fas fa-ban"></i> Revogar
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <form method="POST" action="" class="d-inline">
                                                        <input type="hidden" name="action" value="activate">
                                                        <input type="hidden" name="driver_id" value="<?php echo $driver['id']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-success" title="Ativar Código">
                                                            <i class="fas fa-check"></i> Ativar
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header bg-info text-white">
                    <i class="fas fa-history me-1"></i>
                    Histórico de Atividades
                </div>
                <div class="card-body">
                    <?php
                    // Verificar se a tabela de logs existe
                    $check_logs_table = $conn->query("SHOW TABLES LIKE 'activity_log'");
                    if ($check_logs_table->num_rows == 0) {
                        // Criar tabela de logs se não existir
                        $create_logs_table = "CREATE TABLE activity_log (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            user_id INT NOT NULL,
                            action VARCHAR(50) NOT NULL,
                            description TEXT,
                            ip_address VARCHAR(45),
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                        )";
                        $conn->query($create_logs_table);
                    }
                    
                    // Obter logs relacionados a códigos de acesso
                    $logs_query = "SELECT l.*, u.name as user_name
                                  FROM activity_log l
                                  LEFT JOIN users u ON l.user_id = u.id
                                  WHERE l.action IN ('generate_access_code', 'regenerate_access_code', 'revoke_access_code', 'activate_access_code')
                                  ORDER BY l.created_at DESC
                                  LIMIT 20";
                    $logs_result = $conn->query($logs_query);
                    
                    if ($logs_result && $logs_result->num_rows > 0):
                    ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Data/Hora</th>
                                    <th>Usuário</th>
                                    <th>Ação</th>
                                    <th>Detalhes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($log = $logs_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo format_datetime($log['created_at']); ?></td>
                                        <td><?php echo htmlspecialchars($log['user_name']); ?></td>
                                        <td>
                                            <?php 
                                            $action_label = '';
                                            $action_class = '';
                                            
                                            switch ($log['action']) {
                                                case 'generate_access_code':
                                                    $action_label = 'Geração';
                                                    $action_class = 'primary';
                                                    break;
                                                case 'regenerate_access_code':
                                                    $action_label = 'Regeneração';
                                                    $action_class = 'warning';
                                                    break;
                                                case 'revoke_access_code':
                                                    $action_label = 'Revogação';
                                                    $action_class = 'danger';
                                                    break;
                                                case 'activate_access_code':
                                                    $action_label = 'Ativação';
                                                    $action_class = 'success';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge bg-<?php echo $action_class; ?>"><?php echo $action_label; ?></span>
                                        </td>
                                        <td><?php echo htmlspecialchars($log['description']); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                        <p class="text-muted">Nenhum registro de atividade encontrado.</p>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<?php 
$conn->close();
include 'includes/footer.php'; 
?>
