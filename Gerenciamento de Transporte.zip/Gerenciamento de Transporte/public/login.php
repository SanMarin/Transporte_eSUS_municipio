<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
session_start();
include '../config/database_transp.php';
include 'includes/functions.php';

// Inicializa a conexão com o banco de dados
$conn = connectMySQL();

// Mensagem de erro
$error = '';
$debug_info = '';

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Verifica se os campos estão preenchidos
    if (empty($username) || empty($password)) {
        $error = 'Por favor, preencha todos os campos.';
    } else {
        // Consulta o banco de dados para verificar as credenciais
        $query = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Verifica a senha (usando password_verify para senhas com hash)
            if (password_verify($password, $user['password']) || $password === $user['password']) {
                // Login bem-sucedido
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role_id'] = $user['role_id'];
                $_SESSION['name'] = $user['name'];
                
                // Registra o login
                $log_query = "INSERT INTO user_logs (user_id, action, action_time) VALUES (?, 'login', NOW())";
                $log_stmt = $conn->prepare($log_query);
                $log_stmt->bind_param("i", $user['id']);
                $log_stmt->execute();
                
                // Redireciona para a página inicial
                header('Location: index.php');
                exit;
            } else {
                $error = 'Usuário ou senha incorretos.';
                $debug_info = 'Senha fornecida não corresponde à senha armazenada.';
            }
        } else {
            $error = 'Usuário ou senha incorretos.';
            $debug_info = 'Usuário não encontrado no banco de dados.';
        }
    }
    
    // Fallback para o login admin/admin apenas se o banco de dados não estiver configurado
    if ($username === 'admin' && $password === 'admin') {
        // Verificar se existem usuários no banco
        $check_query = "SELECT COUNT(*) as count FROM users";
        $check_result = $conn->query($check_query);
        $row = $check_result->fetch_assoc();
        
        if ($row['count'] == 0) {
            $_SESSION['user_id'] = 1;
            $_SESSION['username'] = 'admin';
            $_SESSION['role_id'] = 3; // Admin role
            $_SESSION['name'] = 'Administrador';
            
            header('Location: index.php');
            exit;
        } else {
            $debug_info .= ' Fallback admin/admin não utilizado porque existem usuários no banco.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Transporte</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo img {
            max-width: 150px;
        }
        .debug-info {
            margin-top: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .tools {
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
            <div class="logo">
                <h2>Sistema de Transporte</h2>
            </div>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username">Usuário</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Senha</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Entrar</button>
            </form>
            
            <?php if (!empty($debug_info)): ?>
                <div class="debug-info">
                    <h5>Informações de Depuração:</h5>
                    <p><?php echo $debug_info; ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
