<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'update_settings') {
        $city_name = $_POST['city_name'];
        $cbc_rsp = $_POST['cbc_rsp'];
        $cbc_sgl = $_POST['cbc_sgl'];
        $cbc_cgccpf = $_POST['cbc_cgccpf'];
        $cbc_dst = $_POST['cbc_dst'];
        $cbc_dst_in = $_POST['cbc_dst_in'];
        $cbc_versao = $_POST['cbc_versao'];
        
        // Verificar se foi enviado um logo
        $logo_data = null;
        $logo_mime = null;
        
        if (isset($_FILES['city_logo']) && $_FILES['city_logo']['error'] === UPLOAD_ERR_OK) {
            $logo_data = file_get_contents($_FILES['city_logo']['tmp_name']);
            $logo_mime = $_FILES['city_logo']['type'];
        }
        
        // Atualizar configurações
        if ($logo_data) {
            $stmt = $conn->prepare("
                UPDATE settings 
                SET city_name = ?, city_logo = ?, logo_mime_type = ?, 
                    cbc_rsp = ?, cbc_sgl = ?, cbc_cgccpf = ?, 
                    cbc_dst = ?, cbc_dst_in = ?, cbc_versao = ?
                WHERE id = 1
            ");
            $stmt->bind_param("sssssssss", $city_name, $logo_data, $logo_mime, $cbc_rsp, $cbc_sgl, $cbc_cgccpf, $cbc_dst, $cbc_dst_in, $cbc_versao);
        } else {
            $stmt = $conn->prepare("
                UPDATE settings 
                SET city_name = ?, cbc_rsp = ?, cbc_sgl = ?, 
                    cbc_cgccpf = ?, cbc_dst = ?, cbc_dst_in = ?, 
                    cbc_versao = ?
                WHERE id = 1
            ");
            $stmt->bind_param("sssssss", $city_name, $cbc_rsp, $cbc_sgl, $cbc_cgccpf, $cbc_dst, $cbc_dst_in, $cbc_versao);
        }
        
        if ($stmt->execute()) {
            $message = "Configurações atualizadas com sucesso.";
        } else {
            $error = "Erro ao atualizar configurações: " . $conn->error;
        }
        $stmt->close();
    }
}

// Obter configurações atuais
$result = $conn->query("SELECT * FROM settings LIMIT 1");
$settings = $result->fetch_assoc();

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-cog me-2"></i>Configurações do Sistema</h1>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Configurações Gerais</h6>
            </div>
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="update_settings">
                    
                    <div class="mb-3">
                        <label for="city_name" class="form-label">Nome da Cidade</label>
                        <input type="text" class="form-control" id="city_name" name="city_name" required
                               value="<?= htmlspecialchars($settings['city_name']) ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="city_logo" class="form-label">Logo da Cidade</label>
                        <?php if (!empty($settings['city_logo'])): ?>
                            <div class="mb-2">
                                <img src="data:<?= $settings['logo_mime_type'] ?>;base64,<?= base64_encode($settings['city_logo']) ?>" 
                                     alt="Logo atual" style="max-height: 100px; max-width: 300px;">
                            </div>
                        <?php endif; ?>
                        <input type="file" class="form-control" id="city_logo" name="city_logo" accept="image/*">
                        <div class="form-text">Deixe em branco para manter o logo atual.</div>
                    </div>
                    
                    <h5 class="mt-4 mb-3">Configurações do BPA</h5>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="cbc_rsp" class="form-label">Nome do Órgão Responsável</label>
                            <input type="text" class="form-control" id="cbc_rsp" name="cbc_rsp" required maxlength="30"
                                   value="<?= htmlspecialchars($settings['cbc_rsp']) ?>">
                            <div class="form-text">Máximo 30 caracteres</div>
                        </div>
                        <div class="col-md-6">
                            <label for="cbc_sgl" class="form-label">Sigla do Órgão</label>
                            <input type="text" class="form-control" id="cbc_sgl" name="cbc_sgl" required maxlength="6"
                                   value="<?= htmlspecialchars($settings['cbc_sgl']) ?>">
                            <div class="form-text">Máximo 6 caracteres</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="cbc_cgccpf" class="form-label">CNPJ/CPF do Prestador</label>
                            <input type="text" class="form-control" id="cbc_cgccpf" name="cbc_cgccpf" required maxlength="14"
                                   value="<?= htmlspecialchars($settings['cbc_cgccpf']) ?>">
                            <div class="form-text">Apenas números, sem pontuação</div>
                        </div>
                        <div class="col-md-6">
                            <label for="cbc_dst" class="form-label">Nome do Órgão de Saúde Destino</label>
                            <input type="text" class="form-control" id="cbc_dst" name="cbc_dst" required maxlength="40"
                                   value="<?= htmlspecialchars($settings['cbc_dst']) ?>">
                            <div class="form-text">Máximo 40 caracteres</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="cbc_dst_in" class="form-label">Indicador do Órgão Destino</label>
                            <select class="form-select" id="cbc_dst_in" name="cbc_dst_in" required>
                                <option value="E" <?= $settings['cbc_dst_in'] === 'E' ? 'selected' : '' ?>>E - Estadual</option>
                                <option value="M" <?= $settings['cbc_dst_in'] === 'M' ? 'selected' : '' ?>>M - Municipal</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="cbc_versao" class="form-label">Versão do Sistema</label>
                            <input type="text" class="form-control" id="cbc_versao" name="cbc_versao" required maxlength="10"
                                   value="<?= htmlspecialchars($settings['cbc_versao']) ?>">
                            <div class="form-text">Máximo 10 caracteres</div>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i> Salvar Configurações
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Informações do Sistema</h6>
            </div>
            <div class="card-body">
                <p><strong>Versão do Sistema:</strong> 1.0.0</p>
                <p><strong>Data de Atualização:</strong> <?= date('d/m/Y') ?></p>
                
                <div class="alert alert-info mt-3">
                    <h5><i class="fas fa-info-circle me-2"></i>Sobre o Sistema</h5>
                    <p>Este sistema foi desenvolvido para gerenciar o transporte de pacientes e gerar arquivos BPA-I para o DATASUS.</p>
                    <p>Principais funcionalidades:</p>
                    <ul>
                        <li>Gerenciamento de viagens</li>
                        <li>Controle de pacientes e acompanhantes</li>
                        <li>Geração automática de BPA-I</li>
                        <li>Integração com ESUS PEC</li>
                    </ul>
                </div>
                
                <div class="alert alert-warning mt-3">
                    <h5><i class="fas fa-exclamation-triangle me-2"></i>Importante</h5>
                    <p>Certifique-se de configurar corretamente os dados do cabeçalho BPA para evitar problemas na importação pelo DATASUS.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
