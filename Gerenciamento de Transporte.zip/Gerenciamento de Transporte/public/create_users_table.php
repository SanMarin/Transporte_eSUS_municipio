<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

// Arquivo para criar a tabela de usuários
include '../config/database_transp.php';

echo "<h1>Criação da Tabela de Usuários</h1>";

try {
    $conn = connectMySQL();
    
    // Verificar se a tabela users já existe
    $result = $conn->query("SHOW TABLES LIKE 'users'");
    if ($result->num_rows > 0) {
        echo "<p style='color: orange;'>⚠️ A tabela 'users' já existe!</p>";
    } else {
        // Criar a tabela users
        $sql = "CREATE TABLE users (
            id INT(11) NOT NULL AUTO_INCREMENT,
            username VARCHAR(50) NOT NULL,
            password VARCHAR(255) NOT NULL,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            role_id INT(11) NOT NULL DEFAULT 1,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            last_login DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY username (username)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
        
        if ($conn->query($sql) === TRUE) {
            echo "<p style='color: green;'>✅ Tabela 'users' criada com sucesso!</p>";
        } else {
            echo "<p style='color: red;'>❌ Erro ao criar tabela 'users': " . $conn->error . "</p>";
        }
    }
    
    // Verificar se a tabela user_roles já existe
    $result = $conn->query("SHOW TABLES LIKE 'user_roles'");
    if ($result->num_rows > 0) {
        echo "<p style='color: orange;'>⚠️ A tabela 'user_roles' já existe!</p>";
    } else {
        // Criar a tabela user_roles
        $sql = "CREATE TABLE user_roles (
            id INT(11) NOT NULL AUTO_INCREMENT,
            role_name VARCHAR(50) NOT NULL,
            description TEXT NULL,
            PRIMARY KEY (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
        
        if ($conn->query($sql) === TRUE) {
            echo "<p style='color: green;'>✅ Tabela 'user_roles' criada com sucesso!</p>";
            
            // Inserir papéis padrão
            $sql = "INSERT INTO user_roles (id, role_name, description) VALUES
                (1, 'Usuário', 'Usuário comum com acesso básico'),
                (2, 'Gerente', 'Gerente com acesso intermediário'),
                (3, 'Administrador', 'Administrador com acesso completo');";
            
            if ($conn->query($sql) === TRUE) {
                echo "<p style='color: green;'>✅ Papéis padrão inseridos com sucesso!</p>";
            } else {
                echo "<p style='color: red;'>❌ Erro ao inserir papéis padrão: " . $conn->error . "</p>";
            }
        } else {
            echo "<p style='color: red;'>❌ Erro ao criar tabela 'user_roles': " . $conn->error . "</p>";
        }
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erro: " . $e->getMessage() . "</p>";
}
?>

<h2>Próximos Passos</h2>
<p>Acesse os links abaixo para continuar a resolução do problema:</p>
<ul>
    <li><a href="add_test_user.php">Adicionar usuário de teste</a></li>
    <li><a href="test_connection.php">Voltar para o teste de conexão</a></li>
    <li><a href="login.php">Voltar para a página de login</a></li>
</ul>
