<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
session_start();
include '../config/database_transp.php';
include 'includes/functions.php';

// Verifica se o usuário está logado
check_login();

// Inicializa a conexão com o banco de dados
$conn = connectMySQL();

// Verifica se o usuário tem permissão para gerenciar papéis
// Fallback para verificação baseada em role_id se hasPermission não funcionar
if (!hasPermission('manage_roles') && (!isset($_SESSION['role_id']) || $_SESSION['role_id'] < 3)) {
    header('Location: index.php?error=permission');
    exit;
}

// Mensagem de sucesso ou erro
$message = '';
$message_type = '';

// Verifica se a tabela user_roles existe
$check_table = $conn->query("SHOW TABLES LIKE 'user_roles'");
if ($check_table->num_rows == 0) {
    // Cria a tabela user_roles se não existir
    $create_table = "CREATE TABLE user_roles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        role_name VARCHAR(50) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    $conn->query($create_table);
    
    // Insere papéis padrão
    $insert_roles = "INSERT INTO user_roles (id, role_name, description) VALUES
        (1, 'Usuário', 'Acesso básico ao sistema'),
        (2, 'Gerente', 'Acesso a recursos administrativos limitados'),
        (3, 'Administrador', 'Acesso completo ao sistema')";
    $conn->query($insert_roles);
}

// Verifica se a tabela permissions existe
$check_permissions = $conn->query("SHOW TABLES LIKE 'permissions'");
if ($check_permissions->num_rows == 0) {
    // Cria a tabela permissions se não existir
    $create_permissions = "CREATE TABLE permissions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        permission_name VARCHAR(50) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->query($create_permissions);
    
    // Insere permissões padrão
    $insert_permissions = "INSERT INTO permissions (permission_name, description) VALUES
        ('manage_users', 'Gerenciar usuários'),
        ('manage_roles', 'Gerenciar papéis e permissões'),
        ('manage_trips', 'Gerenciar viagens'),
        ('manage_patients', 'Gerenciar pacientes'),
        ('manage_vehicles', 'Gerenciar veículos'),
        ('manage_drivers', 'Gerenciar motoristas'),
        ('manage_locations', 'Gerenciar locais'),
        ('view_reports', 'Visualizar relatórios'),
        ('manage_settings', 'Gerenciar configurações do sistema')";
    $conn->query($insert_permissions);
}

// Verifica se a tabela role_permissions existe
$check_role_permissions = $conn->query("SHOW TABLES LIKE 'role_permissions'");
if ($check_role_permissions->num_rows == 0) {
    // Cria a tabela role_permissions se não existir
    $create_role_permissions = "CREATE TABLE role_permissions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        role_id INT NOT NULL,
        permission_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (role_id) REFERENCES user_roles(id) ON DELETE CASCADE,
        FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE,
        UNIQUE KEY role_permission_unique (role_id, permission_id)
    )";
    $conn->query($create_role_permissions);
    
    // Insere permissões padrão para os papéis
    $insert_role_permissions = "INSERT INTO role_permissions (role_id, permission_id) VALUES
        (3, 1), (3, 2), (3, 3), (3, 4), (3, 5), (3, 6), (3, 7), (3, 8), (3, 9),
        (2, 1), (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8),
        (1, 3), (1, 4), (1, 8)";
    $conn->query($insert_role_permissions);
}

// Processa o formulário de adição/edição de papel
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add' || $_POST['action'] === 'edit') {
        $role_name = sanitize_input($_POST['role_name']);
        $description = sanitize_input($_POST['description']);
        
        if (empty($role_name)) {
            $message = 'O nome do papel é obrigatório.';
            $message_type = 'danger';
        } else {
            if ($_POST['action'] === 'add') {
                $query = "INSERT INTO user_roles (role_name, description) VALUES (?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("ss", $role_name, $description);
                
                if ($stmt->execute()) {
                    $role_id = $conn->insert_id;
                    $message = 'Papel adicionado com sucesso.';
                    $message_type = 'success';
                    
                    // Registra a atividade
                    log_activity($_SESSION['user_id'], 'add_role', 'Adicionou o papel: ' . $role_name);
                } else {
                    $message = 'Erro ao adicionar papel: ' . $conn->error;
                    $message_type = 'danger';
                }
            } else {
                $role_id = (int) $_POST['role_id'];
                $query = "UPDATE user_roles SET role_name = ?, description = ? WHERE id = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("ssi", $role_name, $description, $role_id);
                
                if ($stmt->execute()) {
                    $message = 'Papel atualizado com sucesso.';
                    $message_type = 'success';
                    
                    // Registra a atividade
                    log_activity($_SESSION['user_id'], 'edit_role', 'Editou o papel: ' . $role_name);
                } else {
                    $message = 'Erro ao atualizar papel: ' . $conn->error;
                    $message_type = 'danger';
                }
            }
        }
    } elseif ($_POST['action'] === 'delete' && isset($_POST['role_id'])) {
        $role_id = (int) $_POST['role_id'];
        
        // Verifica se o papel está sendo usado por algum usuário
        $check_query = "SELECT COUNT(*) as count FROM users WHERE role_id = ?";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->bind_param("i", $role_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $check_data = $check_result->fetch_assoc();
        
        if ($check_data['count'] > 0) {
            $message = 'Não é possível excluir este papel porque está sendo usado por usuários.';
            $message_type = 'danger';
        } else {
            // Obtém o nome do papel antes de excluí-lo
            $get_name_query = "SELECT role_name FROM user_roles WHERE id = ?";
            $get_name_stmt = $conn->prepare($get_name_query);
            $get_name_stmt->bind_param("i", $role_id);
            $get_name_stmt->execute();
            $get_name_result = $get_name_stmt->get_result();
            $role_data = $get_name_result->fetch_assoc();
            $role_name = $role_data['role_name'];
            
            // Exclui as permissões do papel
            $delete_permissions = "DELETE FROM role_permissions WHERE role_id = ?";
            $delete_permissions_stmt = $conn->prepare($delete_permissions);
            $delete_permissions_stmt->bind_param("i", $role_id);
            $delete_permissions_stmt->execute();
            
            // Exclui o papel
            $query = "DELETE FROM user_roles WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $role_id);
            
            if ($stmt->execute()) {
                $message = 'Papel excluído com sucesso.';
                $message_type = 'success';
                
                // Registra a atividade
                log_activity($_SESSION['user_id'], 'delete_role', 'Excluiu o papel: ' . $role_name);
            } else {
                $message = 'Erro ao excluir papel: ' . $conn->error;
                $message_type = 'danger';
            }
        }
    } elseif ($_POST['action'] === 'update_permissions' && isset($_POST['role_id'])) {
        $role_id = (int) $_POST['role_id'];
        
        // Obtém o nome do papel
        $get_name_query = "SELECT role_name FROM user_roles WHERE id = ?";
        $get_name_stmt = $conn->prepare($get_name_query);
        $get_name_stmt->bind_param("i", $role_id);
        $get_name_stmt->execute();
        $get_name_result = $get_name_stmt->get_result();
        $role_data = $get_name_result->fetch_assoc();
        $role_name = $role_data['role_name'];
        
        // Remove todas as permissões existentes para este papel
        $delete_query = "DELETE FROM role_permissions WHERE role_id = ?";
        $delete_stmt = $conn->prepare($delete_query);
        $delete_stmt->bind_param("i", $role_id);
        $delete_stmt->execute();
        
        // Adiciona as novas permissões selecionadas
        if (isset($_POST['permissions']) && is_array($_POST['permissions'])) {
            $insert_query = "INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)";
            $insert_stmt = $conn->prepare($insert_query);
            $insert_stmt->bind_param("ii", $role_id, $permission_id);
            
            foreach ($_POST['permissions'] as $permission_id) {
                $permission_id = (int) $permission_id;
                $insert_stmt->execute();
            }
            
            $message = 'Permissões atualizadas com sucesso.';
            $message_type = 'success';
            
            // Registra a atividade
            log_activity($_SESSION['user_id'], 'update_permissions', 'Atualizou as permissões do papel: ' . $role_name);
        } else {
            $message = 'Nenhuma permissão selecionada.';
            $message_type = 'warning';
        }
    }
}

// Obtém a lista de papéis
$roles_query = "SELECT * FROM user_roles ORDER BY id";
$roles_result = $conn->query($roles_query);
$roles = [];
while ($role = $roles_result->fetch_assoc()) {
    $roles[] = $role;
}

// Obtém a lista de permissões
$permissions_query = "SELECT * FROM permissions ORDER BY id";
$permissions_result = $conn->query($permissions_query);
$permissions = [];
while ($permission = $permissions_result->fetch_assoc()) {
    $permissions[] = $permission;
}

// Função para verificar se um papel tem uma permissão específica
function role_has_permission($role_id, $permission_id, $conn) {
    $query = "SELECT * FROM role_permissions WHERE role_id = ? AND permission_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $role_id, $permission_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->num_rows > 0;
}

// Inclui o cabeçalho
// Definir variável para controlar a exibição do cabeçalho
$skip_main_header = true;
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php //include 'includes/sidebar.php'; ?>
        
        <!-- Conteúdo principal -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Gerenciamento de Papéis</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#addRoleModal">
                        <i class="bi bi-plus-circle"></i> Novo Papel
                    </button>
                </div>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                </div>
            <?php endif; ?>
            
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Descrição</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($roles as $role): ?>
                            <tr>
                                <td><?php echo $role['id']; ?></td>
                                <td><?php echo htmlspecialchars($role['role_name']); ?></td>
                                <td><?php echo htmlspecialchars($role['description']); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editRoleModal<?php echo $role['id']; ?>">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#permissionsModal<?php echo $role['id']; ?>">
                                        <i class="bi bi-shield-lock"></i>
                                    </button>
                                    <?php if ($role['id'] > 3): ?>
                                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteRoleModal<?php echo $role['id']; ?>">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            
                            <!-- Modal de Edição -->
                            <div class="modal fade" id="editRoleModal<?php echo $role['id']; ?>" tabindex="-1" aria-labelledby="editRoleModalLabel<?php echo $role['id']; ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="editRoleModalLabel<?php echo $role['id']; ?>">Editar Papel</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                        </div>
                                        <form method="POST" action="">
                                            <div class="modal-body">
                                                <input type="hidden" name="action" value="edit">
                                                <input type="hidden" name="role_id" value="<?php echo $role['id']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label for="role_name<?php echo $role['id']; ?>" class="form-label">Nome do Papel</label>
                                                    <input type="text" class="form-control" id="role_name<?php echo $role['id']; ?>" name="role_name" value="<?php echo htmlspecialchars($role['role_name']); ?>" required>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label for="description<?php echo $role['id']; ?>" class="form-label">Descrição</label>
                                                    <textarea class="form-control" id="description<?php echo $role['id']; ?>" name="description" rows="3"><?php echo htmlspecialchars($role['description']); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                <button type="submit" class="btn btn-primary">Salvar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Modal de Permissões -->
                            <div class="modal fade" id="permissionsModal<?php echo $role['id']; ?>" tabindex="-1" aria-labelledby="permissionsModalLabel<?php echo $role['id']; ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="permissionsModalLabel<?php echo $role['id']; ?>">Permissões do Papel: <?php echo htmlspecialchars($role['role_name']); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                        </div>
                                        <form method="POST" action="">
                                            <div class="modal-body">
                                                <input type="hidden" name="action" value="update_permissions">
                                                <input type="hidden" name="role_id" value="<?php echo $role['id']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label class="form-label">Selecione as Permissões</label>
                                                    <?php foreach ($permissions as $permission): ?>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" name="permissions[]" value="<?php echo $permission['id']; ?>" id="permission<?php echo $role['id']; ?>_<?php echo $permission['id']; ?>" <?php echo role_has_permission($role['id'], $permission['id'], $conn) ? 'checked' : ''; ?>>
                                                            <label class="form-check-label" for="permission<?php echo $role['id']; ?>_<?php echo $permission['id']; ?>">
                                                                <?php echo htmlspecialchars($permission['permission_name']); ?> - <?php echo htmlspecialchars($permission['description']); ?>
                                                            </label>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                <button type="submit" class="btn btn-primary">Salvar Permissões</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Modal de Exclusão -->
                            <?php if ($role['id'] > 3): ?>
                                <div class="modal fade" id="deleteRoleModal<?php echo $role['id']; ?>" tabindex="-1" aria-labelledby="deleteRoleModalLabel<?php echo $role['id']; ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="deleteRoleModalLabel<?php echo $role['id']; ?>">Confirmar Exclusão</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Tem certeza de que deseja excluir o papel <strong><?php echo htmlspecialchars($role['role_name']); ?></strong>?</p>
                                                <p class="text-danger">Esta ação não pode ser desfeita.</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                <form method="POST" action="">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="role_id" value="<?php echo $role['id']; ?>">
                                                    <button type="submit" class="btn btn-danger">Excluir</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>

<!-- Modal de Adição -->
<div class="modal fade" id="addRoleModal" tabindex="-1" aria-labelledby="addRoleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addRoleModalLabel">Novo Papel</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="role_name" class="form-label">Nome do Papel</label>
                        <input type="text" class="form-control" id="role_name" name="role_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Descrição</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Adicionar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
