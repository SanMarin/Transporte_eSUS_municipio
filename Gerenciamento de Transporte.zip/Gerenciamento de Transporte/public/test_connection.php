<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Arquivo para testar a conexão com o banco de dados
include '../config/database_transp.php';

echo "<h1>Teste de Conexão com o Banco de Dados</h1>";

try {
    $conn = connectMySQL();
    echo "<p style='color: green;'>✅ Conexão com o MySQL estabelecida com sucesso!</p>";
    
    // Verificar se a tabela users existe
    $result = $conn->query("SHOW TABLES LIKE 'users'");
    if ($result->num_rows > 0) {
        echo "<p style='color: green;'>✅ Tabela 'users' encontrada!</p>";
        
        // Verificar se existem usuários
        $result = $conn->query("SELECT COUNT(*) as total FROM users");
        $row = $result->fetch_assoc();
        echo "<p>Total de usuários: " . $row['total'] . "</p>";
        
        if ($row['total'] > 0) {
            echo "<p style='color: green;'>✅ Existem usuários cadastrados.</p>";
            
            // Listar os usuários (apenas para debug)
            echo "<h2>Usuários cadastrados:</h2>";
            echo "<table border='1' cellpadding='5'>";
            echo "<tr><th>ID</th><th>Username</th><th>Nome</th><th>Email</th><th>Role ID</th></tr>";
            
            $result = $conn->query("SELECT id, username, name, email, role_id FROM users");
            while ($user = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $user['id'] . "</td>";
                echo "<td>" . $user['username'] . "</td>";
                echo "<td>" . $user['name'] . "</td>";
                echo "<td>" . $user['email'] . "</td>";
                echo "<td>" . $user['role_id'] . "</td>";
                echo "</tr>";
            }
            
            echo "</table>";
        } else {
            echo "<p style='color: red;'>❌ Não existem usuários cadastrados.</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ Tabela 'users' não encontrada!</p>";
    }
    
    // Verificar a estrutura da tabela users
    echo "<h2>Estrutura da tabela 'users':</h2>";
    $result = $conn->query("SHOW TABLES LIKE 'users'");
    if ($result->num_rows > 0) {
        $result = $conn->query("DESCRIBE users");
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Campo</th><th>Tipo</th><th>Nulo</th><th>Chave</th><th>Padrão</th><th>Extra</th></tr>";
        
        while ($field = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $field['Field'] . "</td>";
            echo "<td>" . $field['Type'] . "</td>";
            echo "<td>" . $field['Null'] . "</td>";
            echo "<td>" . $field['Key'] . "</td>";
            echo "<td>" . $field['Default'] . "</td>";
            echo "<td>" . $field['Extra'] . "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    } else {
        echo "<p>Tabela 'users' não existe.</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erro na conexão: " . $e->getMessage() . "</p>";
}

// Verificar se o banco de dados bpa_transport_system existe
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
    $result = $conn->query("SHOW DATABASES LIKE '" . DB_NAME . "'");
    if ($result->num_rows > 0) {
        echo "<p style='color: green;'>✅ Banco de dados '" . DB_NAME . "' encontrado!</p>";
    } else {
        echo "<p style='color: red;'>❌ Banco de dados '" . DB_NAME . "' não encontrado!</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erro ao verificar banco de dados: " . $e->getMessage() . "</p>";
}
?>

<h2>Próximos Passos</h2>
<p>Acesse os links abaixo para continuar a resolução do problema:</p>
<ul>
    <li><a href="create_users_table.php">Criar tabela de usuários (se não existir)</a></li>
    <li><a href="add_test_user.php">Adicionar usuário de teste</a></li>
    <li><a href="login.php">Voltar para a página de login</a></li>
</ul>
