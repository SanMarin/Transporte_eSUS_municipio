<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();

// Obter mês e ano atuais ou da requisição
$month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');

// Validar mês e ano
if ($month < 1 || $month > 12) $month = (int)date('m');
if ($year < 2020 || $year > 2030) $year = (int)date('Y');

// Calcular primeiro dia do mês
$first_day = mktime(0, 0, 0, $month, 1, $year);
$days_in_month = date('t', $first_day);
$day_of_week = date('w', $first_day); // 0 (Domingo) a 6 (Sábado)

// Ajustar para começar na segunda-feira (1 = Segunda, 0 = Domingo)
if ($day_of_week == 0) {
    $day_of_week = 6; // Domingo vira 6
} else {
    $day_of_week--; // Segunda (1) vira 0, Terça (2) vira 1, etc.
}

// Calcular mês anterior e próximo
$prev_month = $month - 1;
$prev_year = $year;
if ($prev_month < 1) {
    $prev_month = 12;
    $prev_year--;
}

$next_month = $month + 1;
$next_year = $year;
if ($next_month > 12) {
    $next_month = 1;
    $next_year++;
}

// Obter viagens do mês
$start_date = date('Y-m-01', $first_day);
$end_date = date('Y-m-t', $first_day);

$stmt = $conn->prepare("
    SELECT trip_date, COUNT(*) as trip_count 
    FROM trips 
    WHERE trip_date BETWEEN ? AND ?
    GROUP BY trip_date
");
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$result = $stmt->get_result();

$trips_by_day = [];
while ($row = $result->fetch_assoc()) {
    $trips_by_day[$row['trip_date']] = $row['trip_count'];
}

// Processar seleção de dias para PDF
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_pdf'])) {
    if (isset($_POST['selected_days']) && is_array($_POST['selected_days']) && count($_POST['selected_days']) > 0) {
        $selected_days = $_POST['selected_days'];
        
        // Debug: verificar dias selecionados
        error_log("Dias selecionados: " . implode(', ', $selected_days));
        
        // Redirecionar para página de geração de PDF
        $days_param = urlencode(implode(',', $selected_days));
        header("Location: generate_trips_pdf.php?days=$days_param");
        exit;
    } else {
        $error = "Selecione pelo menos um dia para gerar o PDF.";
    }
}

$conn->close();

// Nome do mês em português
$month_names = [
    1 => 'Janeiro', 2 => 'Fevereiro', 3 => 'Março', 4 => 'Abril',
    5 => 'Maio', 6 => 'Junho', 7 => 'Julho', 8 => 'Agosto',
    9 => 'Setembro', 10 => 'Outubro', 11 => 'Novembro', 12 => 'Dezembro'
];
$month_name_display = $month_names[$month] . ' de ' . $year;
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-calendar-alt me-2"></i>Calendário de Viagens</h1>
    
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <a href="calendar.php?month=<?= $prev_month ?>&year=<?= $prev_year ?>" class="btn btn-sm btn-outline-primary">
                <i class="fas fa-chevron-left me-1"></i> Mês Anterior
            </a>
            <a href="calendar.php?month=<?= $next_month ?>&year=<?= $next_year ?>" class="btn btn-sm btn-outline-primary">
                Próximo Mês <i class="fas fa-chevron-right ms-1"></i>
            </a>
            <a href="calendar.php" class="btn btn-sm btn-outline-secondary">
                <i class="fas fa-calendar-day me-1"></i> Mês Atual
            </a>
        </div>
        <a href="trips.php" class="btn btn-sm btn-success">
            <i class="fas fa-route me-1"></i> Ver Lista de Viagens
        </a>
    </div>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if (!empty($success)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $success ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-primary"><?= $month_name_display ?></h6>
        
        <div>
            <button type="button" class="btn btn-sm btn-outline-primary me-2" onclick="toggleAllDays(true)">
                <i class="fas fa-check me-1"></i> Selecionar Todos
            </button>
            <button type="button" class="btn btn-sm btn-outline-secondary me-2" onclick="toggleAllDays(false)">
                <i class="fas fa-times me-1"></i> Desmarcar Todos
            </button>
            <button type="button" class="btn btn-sm btn-danger" onclick="generatePDF()">
                <i class="fas fa-file-pdf me-1"></i> Gerar PDF
            </button>
        </div>
    </div>
    
    <div class="card-body">
        <form method="post" id="calendarForm">
            <input type="hidden" name="generate_pdf" value="1">
            <div class="calendar-container">
                <table class="table table-bordered calendar-table">
                    <thead>
                        <tr>
                            <th>Segunda</th>
                            <th>Terça</th>
                            <th>Quarta</th>
                            <th>Quinta</th>
                            <th>Sexta</th>
                            <th>Sábado</th>
                            <th>Domingo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $day = 1;
                        $today = date('Y-m-d');
                        
                        echo '<tr>';
                        
                        // Preencher os dias vazios no início do mês
                        for ($i = 0; $i < $day_of_week; $i++) {
                            echo '<td class="calendar-day empty"></td>';
                        }
                        
                        // Preencher os dias do mês
                        while ($day <= $days_in_month) {
                            $current_date = sprintf('%04d-%02d-%02d', $year, $month, $day);
                            $class = 'calendar-day';
                            $trip_count = 0;
                            
                            if (isset($trips_by_day[$current_date])) {
                                $trip_count = $trips_by_day[$current_date];
                                $class .= ' has-trips';
                            }
                            
                            if ($current_date == $today) {
                                $class .= ' today';
                            }
                            
                            echo '<td class="' . $class . '" data-date="' . $current_date . '">';
                            echo '<div class="day-header">';
                            echo '<div class="day-number">' . $day . '</div>';
                            echo '<div class="day-checkbox">';
                            echo '<input type="checkbox" name="selected_days[]" value="' . $current_date . '" id="day-' . $day . '" class="day-checkbox-input">';
                            echo '<label for="day-' . $day . '"></label>';
                            echo '</div>';
                            echo '</div>';
                            
                            if ($trip_count > 0) {
                                echo '<div class="trip-count" data-bs-toggle="modal" data-bs-target="#dayDetailsModal" onclick="loadDayDetails(\'' . $current_date . '\')">';
                                echo '<span class="badge bg-primary">' . $trip_count . ' viagem(ns)</span>';
                                echo '</div>';
                            } else {
                                echo '<div class="trip-count"></div>';
                            }
                            
                            echo '</td>';
                            
                            // Quebrar linha no final da semana
                            if (($day_of_week + $day) % 7 == 0 && $day < $days_in_month) {
                                echo '</tr><tr>';
                            }
                            
                            $day++;
                        }
                        
                        // Preencher os dias vazios no final do mês
                        $remaining_days = (7 - (($day_of_week + $days_in_month) % 7)) % 7;
                        if ($remaining_days > 0) {
                            for ($i = 0; $i < $remaining_days; $i++) {
                                echo '<td class="calendar-day empty"></td>';
                            }
                        }
                        
                        echo '</tr>';
                        ?>
                    </tbody>
                </table>
            </div>
        </form>
    </div>
</div>

<!-- Modal para detalhes do dia -->
<div class="modal fade" id="dayDetailsModal" tabindex="-1" aria-labelledby="dayDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="dayDetailsModalLabel">Detalhes das Viagens - <span id="modalDate"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body" id="dayDetailsContent">
                <div class="text-center">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Carregando...</span>
                    </div>
                    <p>Carregando detalhes das viagens...</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<style>
.calendar-table {
    table-layout: fixed;
    width: 100%;
}

.calendar-day {
    height: 120px;
    vertical-align: top;
    position: relative;
    cursor: pointer;
    padding: 8px;
}

.calendar-day.empty {
    background-color: #f8f9fa;
}

.calendar-day.today {
    background-color: #e3f2fd;
    border: 2px solid #0d6efd;
}

.calendar-day.has-trips {
    background-color: #f0f9ff;
}

.calendar-day:hover {
    background-color: #e9ecef;
}

.day-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 5px;
}

.day-number {
    font-weight: bold;
    font-size: 1.2em;
}

.day-checkbox {
    margin-left: 5px;
}

.day-checkbox-input {
    cursor: pointer;
}

.trip-count {
    text-align: center;
    margin-top: 10px;
    cursor: pointer;
    min-height: 20px;
}

.trip-count .badge {
    font-size: 0.8em;
    padding: 4px 8px;
}

.trip-details-list {
    max-height: 400px;
    overflow-y: auto;
}

.trip-item {
    border-left: 4px solid #0d6efd;
    padding: 10px 15px;
    margin-bottom: 15px;
    background-color: #f8f9fa;
    border-radius: 4px;
}

.trip-passengers {
    margin-top: 10px;
    padding-left: 15px;
    border-left: 2px solid #dee2e6;
}

.trip-passengers ul {
    margin-bottom: 0;
    padding-left: 15px;
}
</style>

<script>
function loadDayDetails(date) {
    console.log('Carregando detalhes para:', date);
    // Atualizar a data no modal
    document.getElementById('modalDate').textContent = formatDate(date);
    
    // Mostrar indicador de carregamento
    document.getElementById('dayDetailsContent').innerHTML = `
        <div class="text-center py-4">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Carregando...</span>
            </div>
            <p class="mt-2">Carregando detalhes das viagens...</p>
        </div>
    `;
    
    // Fazer requisição AJAX para obter os detalhes
    fetch('get_day_trips.php?date=' + date)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro na requisição: ' + response.status);
            }
            return response.text();
        })
        .then(data => {
            document.getElementById('dayDetailsContent').innerHTML = data;
        })
        .catch(error => {
            console.error('Erro:', error);
            document.getElementById('dayDetailsContent').innerHTML = 
                '<div class="alert alert-danger">Erro ao carregar os detalhes das viagens: ' + error.message + '</div>';
        });
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    };
    return date.toLocaleDateString('pt-BR', options);
}

function toggleAllDays(selectAll) {
    const checkboxes = document.querySelectorAll('input.day-checkbox-input');
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll;
    });
}

function generatePDF() {
    const selectedDays = document.querySelectorAll('input.day-checkbox-input:checked');
    
    if (selectedDays.length === 0) {
        alert('Selecione pelo menos um dia para gerar o PDF.');
        return false;
    }
    
    // Mostrar loading
    const originalText = document.querySelector('.btn-danger').innerHTML;
    document.querySelector('.btn-danger').innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Gerando...';
    document.querySelector('.btn-danger').disabled = true;
    
    // Enviar formulário
    document.getElementById('calendarForm').submit();
    
    // Restaurar botão após 3 segundos (caso algo dê errado)
    setTimeout(() => {
        document.querySelector('.btn-danger').innerHTML = originalText;
        document.querySelector('.btn-danger').disabled = false;
    }, 3000);
}

// Adicionar evento de clique nos dias para selecionar/deselecionar
document.addEventListener('DOMContentLoaded', function() {
    const calendarDays = document.querySelectorAll('.calendar-day:not(.empty)');
    
    calendarDays.forEach(day => {
        day.addEventListener('click', function(e) {
            // Não marcar/desmarcar se o clique foi no badge de viagens ou no checkbox
            if (!e.target.closest('.trip-count') && !e.target.closest('.day-checkbox')) {
                const checkbox = this.querySelector('input.day-checkbox-input');
                if (checkbox) {
                    checkbox.checked = !checkbox.checked;
                    console.log('Dia selecionado:', checkbox.value, checkbox.checked);
                }
            }
        });
    });
    
    // Debug: Verificar se os checkboxes estão funcionando
    const checkboxes = document.querySelectorAll('input.day-checkbox-input');
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            console.log('Checkbox alterado:', this.value, this.checked);
        });
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>