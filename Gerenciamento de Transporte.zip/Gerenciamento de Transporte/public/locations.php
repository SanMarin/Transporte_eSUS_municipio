<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Adicionar novo local
        if ($_POST['action'] === 'add') {
            $name = $_POST['name'];
            $city = $_POST['city'];
            $state = $_POST['state'];
            $distance = $_POST['distance'];
            $active = isset($_POST['active']) ? 1 : 0;
            
            $stmt = $conn->prepare("
                INSERT INTO locations (name, city, state, distance, active)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("sssii", $name, $city, $state, $distance, $active);
            
            if ($stmt->execute()) {
                $message = "Local adicionado com sucesso.";
            } else {
                $error = "Erro ao adicionar local: " . $conn->error;
            }
            $stmt->close();
        }
        // Editar local
        else if ($_POST['action'] === 'edit' && isset($_POST['id'])) {
            $id = $_POST['id'];
            $name = $_POST['name'];
            $city = $_POST['city'];
            $state = $_POST['state'];
            $distance = $_POST['distance'];
            $active = isset($_POST['active']) ? 1 : 0;
            
            $stmt = $conn->prepare("
                UPDATE locations 
                SET name = ?, city = ?, state = ?, distance = ?, active = ?
                WHERE id = ?
            ");
            $stmt->bind_param("sssiii", $name, $city, $state, $distance, $active, $id);
            
            if ($stmt->execute()) {
                $message = "Local atualizado com sucesso.";
            } else {
                $error = "Erro ao atualizar local: " . $conn->error;
            }
            $stmt->close();
        }
        // Excluir local
        else if ($_POST['action'] === 'delete' && isset($_POST['id'])) {
            $id = $_POST['id'];
            
            // Verificar se o local está em alguma viagem
            $check = $conn->prepare("SELECT COUNT(*) as count FROM trips WHERE location_id = ?");
            $check->bind_param("i", $id);
            $check->execute();
            $result = $check->get_result();
            $count = $result->fetch_assoc()['count'];
            
            if ($count > 0) {
                $error = "Não é possível excluir este local pois ele está associado a viagens.";
            } else {
                $stmt = $conn->prepare("DELETE FROM locations WHERE id = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $message = "Local excluído com sucesso.";
                } else {
                    $error = "Erro ao excluir local: " . $conn->error;
                }
                $stmt->close();
            }
        }
    }
}

// Definir ação
$action = $_GET['action'] ?? 'list';
$location_id = $_GET['id'] ?? null;

// Obter dados para formulários
if ($action === 'edit' && $location_id) {
    $stmt = $conn->prepare("SELECT * FROM locations WHERE id = ?");
    $stmt->bind_param("i", $location_id);
    $stmt->execute();
    $location = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$location) {
        $error = "Local não encontrado.";
        $action = 'list';
    }
}

// Listar locais
if ($action === 'list') {
    $result = $conn->query("SELECT * FROM locations ORDER BY name");
    $locations = $result->fetch_all(MYSQLI_ASSOC);
}

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <?php if ($action === 'add'): ?>
            <i class="fas fa-plus-circle me-2"></i>Novo Local
        <?php elseif ($action === 'edit'): ?>
            <i class="fas fa-edit me-2"></i>Editar Local
        <?php else: ?>
            <i class="fas fa-map-marker-alt me-2"></i>Gerenciamento de Locais
        <?php endif; ?>
    </h1>
    
    <?php if ($action === 'list'): ?>
        <a href="?action=add" class="btn btn-sm btn-success">
            <i class="fas fa-plus me-1"></i> Novo Local
        </a>
    <?php else: ?>
        <a href="locations.php" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    <?php endif; ?>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($action === 'add' || $action === 'edit'): ?>
    <!-- Formulário de Local -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <?= $action === 'add' ? 'Novo Local' : 'Editar Local' ?>
            </h6>
        </div>
        <div class="card-body">
            <form method="post" action="locations.php">
                <input type="hidden" name="action" value="<?= $action ?>">
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="id" value="<?= $location['id'] ?>">
                <?php endif; ?>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Nome do Local*</label>
                        <input type="text" class="form-control" id="name" name="name" required 
                               value="<?= $action === 'edit' ? $location['name'] : '' ?>" 
                               placeholder="Ex: Hospital Regional, Clínica Especializada, etc">
                    </div>
                    <div class="col-md-6">
                        <label for="city" class="form-label">Cidade*</label>
                        <input type="text" class="form-control" id="city" name="city" required 
                               value="<?= $action === 'edit' ? $location['city'] : '' ?>" 
                               placeholder="Nome da cidade">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="state" class="form-label">Estado*</label>
                        <select class="form-select" id="state" name="state" required>
                            <option value="">Selecione...</option>
                            <option value="AC" <?= ($action === 'edit' && $location['state'] === 'AC') ? 'selected' : '' ?>>Acre</option>
                            <option value="AL" <?= ($action === 'edit' && $location['state'] === 'AL') ? 'selected' : '' ?>>Alagoas</option>
                            <option value="AP" <?= ($action === 'edit' && $location['state'] === 'AP') ? 'selected' : '' ?>>Amapá</option>
                            <option value="AM" <?= ($action === 'edit' && $location['state'] === 'AM') ? 'selected' : '' ?>>Amazonas</option>
                            <option value="BA" <?= ($action === 'edit' && $location['state'] === 'BA') ? 'selected' : '' ?>>Bahia</option>
                            <option value="CE" <?= ($action === 'edit' && $location['state'] === 'CE') ? 'selected' : '' ?>>Ceará</option>
                            <option value="DF" <?= ($action === 'edit' && $location['state'] === 'DF') ? 'selected' : '' ?>>Distrito Federal</option>
                            <option value="ES" <?= ($action === 'edit' && $location['state'] === 'ES') ? 'selected' : '' ?>>Espírito Santo</option>
                            <option value="GO" <?= ($action === 'edit' && $location['state'] === 'GO') ? 'selected' : '' ?>>Goiás</option>
                            <option value="MA" <?= ($action === 'edit' && $location['state'] === 'MA') ? 'selected' : '' ?>>Maranhão</option>
                            <option value="MT" <?= ($action === 'edit' && $location['state'] === 'MT') ? 'selected' : '' ?>>Mato Grosso</option>
                            <option value="MS" <?= ($action === 'edit' && $location['state'] === 'MS') ? 'selected' : '' ?>>Mato Grosso do Sul</option>
                            <option value="MG" <?= ($action === 'edit' && $location['state'] === 'MG') ? 'selected' : '' ?>>Minas Gerais</option>
                            <option value="PA" <?= ($action === 'edit' && $location['state'] === 'PA') ? 'selected' : '' ?>>Pará</option>
                            <option value="PB" <?= ($action === 'edit' && $location['state'] === 'PB') ? 'selected' : '' ?>>Paraíba</option>
                            <option value="PR" <?= ($action === 'edit' && $location['state'] === 'PR') ? 'selected' : '' ?>>Paraná</option>
                            <option value="PE" <?= ($action === 'edit' && $location['state'] === 'PE') ? 'selected' : '' ?>>Pernambuco</option>
                            <option value="PI" <?= ($action === 'edit' && $location['state'] === 'PI') ? 'selected' : '' ?>>Piauí</option>
                            <option value="RJ" <?= ($action === 'edit' && $location['state'] === 'RJ') ? 'selected' : '' ?>>Rio de Janeiro</option>
                            <option value="RN" <?= ($action === 'edit' && $location['state'] === 'RN') ? 'selected' : '' ?>>Rio Grande do Norte</option>
                            <option value="RS" <?= ($action === 'edit' && $location['state'] === 'RS') ? 'selected' : '' ?>>Rio Grande do Sul</option>
                            <option value="RO" <?= ($action === 'edit' && $location['state'] === 'RO') ? 'selected' : '' ?>>Rondônia</option>
                            <option value="RR" <?= ($action === 'edit' && $location['state'] === 'RR') ? 'selected' : '' ?>>Roraima</option>
                            <option value="SC" <?= ($action === 'edit' && $location['state'] === 'SC') ? 'selected' : '' ?>>Santa Catarina</option>
                            <option value="SP" <?= ($action === 'edit' && $location['state'] === 'SP') ? 'selected' : '' ?>>São Paulo</option>
                            <option value="SE" <?= ($action === 'edit' && $location['state'] === 'SE') ? 'selected' : '' ?>>Sergipe</option>
                            <option value="TO" <?= ($action === 'edit' && $location['state'] === 'TO') ? 'selected' : '' ?>>Tocantins</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="distance" class="form-label">Distância (km)*</label>
                        <input type="number" class="form-control" id="distance" name="distance" required 
                               value="<?= $action === 'edit' ? $location['distance'] : '' ?>" 
                               min="1" step="1">
                        <div class="form-text text-info">
                            <?php
                            $distance = $action === 'edit' ? $location['distance'] : 0;
                            $procedures = ceil($distance / 50);
                            ?>
                            Esta distância gerará <strong><?= $procedures ?> procedimento(s)</strong> por paciente.
                        </div>
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <div class="form-check form-switch mt-4">
                            <input class="form-check-input" type="checkbox" id="active" name="active" 
                                   <?= ($action === 'edit' && $location['active'] == 1) || $action === 'add' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="active">Ativo</label>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Salvar
                    </button>
                    <a href="locations.php" class="btn btn-secondary ms-2">
                        <i class="fas fa-times me-1"></i> Cancelar
                    </a>
                </div>
            </form>
        </div>
    </div>
<?php else: ?>
    <!-- Lista de Locais -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Locais Cadastrados</h6>
        </div>
        <div class="card-body">
            <?php if (empty($locations)): ?>
                <div class="alert alert-info">
                    Nenhum local cadastrado. <a href="?action=add" class="alert-link">Cadastrar novo local</a>.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Cidade</th>
                                <th>Estado</th>
                                <th>Distância</th>
                                <th>Procedimentos</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($locations as $location): ?>
                                <tr>
                                    <td><?= $location['name'] ?></td>
                                    <td><?= $location['city'] ?></td>
                                    <td><?= $location['state'] ?></td>
                                    <td><?= $location['distance'] ?> km</td>
                                    <td><?= ceil($location['distance'] / 50) ?></td>
                                    <td>
                                        <?php if ($location['active'] == 1): ?>
                                            <span class="badge bg-success">Ativo</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Inativo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="?action=edit&id=<?= $location['id'] ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-danger" 
                                                data-bs-toggle="modal" data-bs-target="#deleteModal<?= $location['id'] ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        
                                        <!-- Modal de Confirmação de Exclusão -->
                                        <div class="modal fade" id="deleteModal<?= $location['id'] ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Confirmar Exclusão</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Tem certeza que deseja excluir o local <strong><?= $location['name'] ?> - <?= $location['city'] ?>/<?= $location['state'] ?></strong>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                        <form method="post" action="locations.php">
                                                            <input type="hidden" name="action" value="delete">
                                                            <input type="hidden" name="id" value="<?= $location['id'] ?>">
                                                            <button type="submit" class="btn btn-danger">Excluir</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Atualizar o número de procedimentos quando a distância mudar
    const distanceInput = document.getElementById('distance');
    if (distanceInput) {
        distanceInput.addEventListener('input', function() {
            const distance = parseInt(this.value) || 0;
            const procedures = Math.ceil(distance / 50);
            const infoText = this.parentNode.querySelector('.form-text');
            infoText.innerHTML = `Esta distância gerará <strong>${procedures} procedimento(s)</strong> por paciente.`;
        });
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
