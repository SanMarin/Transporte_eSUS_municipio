<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../config/database_transp.php';

if (!isset($_GET['date'])) {
    die('<div class="alert alert-danger">Data não especificada.</div>');
}

$date = $_GET['date'];
$conn = connectMySQL();

// Debug: Log da data recebida
error_log("get_day_trips.php - Data recebida: $date");

// Obter viagens do dia específico
$stmt = $conn->prepare("
    SELECT t.id, t.trip_date, t.departure_time, t.status,
           v.plate, v.model, v.brand,
           d.name as driver_name,
           t.city as destination,
           (SELECT COUNT(*) FROM trip_passengers WHERE trip_id = t.id) as passenger_count
    FROM trips t
    JOIN vehicles v ON t.vehicle_id = v.id
    JOIN drivers d ON t.driver_id = d.id
    WHERE t.trip_date = ?
    ORDER BY t.departure_time
");

if (!$stmt) {
    die('<div class="alert alert-danger">Erro na preparação da consulta: ' . $conn->error . '</div>');
}

$stmt->bind_param("s", $date);
$stmt->execute();
$result = $stmt->get_result();

error_log("Viagens encontradas: " . $result->num_rows);

if ($result->num_rows === 0) {
    echo '<div class="alert alert-info">Nenhuma viagem encontrada para ' . date('d/m/Y', strtotime($date)) . '.</div>';
    exit;
}

echo '<div class="trip-details-list">';

while ($trip = $result->fetch_assoc()) {
    echo '<div class="trip-item">';
    echo '<h6>Viagem #' . $trip['id'] . ' - ' . date('H:i', strtotime($trip['departure_time'])) . '</h6>';
    echo '<p><strong>Veículo:</strong> ' . htmlspecialchars($trip['plate']) . ' - ' . 
         htmlspecialchars($trip['model']) . ' ' . htmlspecialchars($trip['brand']) . '</p>';
    echo '<p><strong>Motorista:</strong> ' . htmlspecialchars($trip['driver_name']) . '</p>';
    echo '<p><strong>Destino:</strong> ' . htmlspecialchars($trip['destination']) . '</p>';
    echo '<p><strong>Passageiros:</strong> ' . $trip['passenger_count'] . '</p>';
    
    // Obter passageiros desta viagem
    $passenger_stmt = $conn->prepare("
        SELECT p.name, tp.appointment_time
        FROM trip_passengers tp
        JOIN patients p ON tp.patient_id = p.id
        WHERE tp.trip_id = ?
        ORDER BY tp.appointment_time, p.name
    ");
    
    if ($passenger_stmt) {
        $passenger_stmt->bind_param("i", $trip['id']);
        $passenger_stmt->execute();
        $passenger_result = $passenger_stmt->get_result();
        
        if ($passenger_result->num_rows > 0) {
            echo '<div class="trip-passengers">';
            echo '<strong>Lista de Passageiros:</strong>';
            echo '<ul>';
            while ($passenger = $passenger_result->fetch_assoc()) {
                echo '<li>' . htmlspecialchars($passenger['name']);
                if (!empty($passenger['appointment_time'])) {
                    echo ' - Consulta: ' . date('H:i', strtotime($passenger['appointment_time']));
                }
                echo '</li>';
            }
            echo '</ul>';
            echo '</div>';
        }
        $passenger_stmt->close();
    }
    
    echo '<a href="trips.php?action=view&id=' . $trip['id'] . '" class="btn btn-sm btn-outline-primary mt-2">Ver Detalhes Completos</a>';
    echo '</div>';
}

echo '</div>';

$conn->close();
?>