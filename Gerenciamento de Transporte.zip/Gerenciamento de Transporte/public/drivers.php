<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Adicionar novo motorista
        if ($_POST['action'] === 'add') {
            $name = $_POST['name'];
            $active = isset($_POST['active']) ? 1 : 0;
            
            $stmt = $conn->prepare("
                INSERT INTO drivers (name, active)
                VALUES (?, ?)
            ");
            $stmt->bind_param("si", $name, $active);
            
            if ($stmt->execute()) {
                $message = "Motorista adicionado com sucesso.";
            } else {
                $error = "Erro ao adicionar motorista: " . $conn->error;
            }
            $stmt->close();
        }
        // Editar motorista
        else if ($_POST['action'] === 'edit' && isset($_POST['id'])) {
            $id = $_POST['id'];
            $name = $_POST['name'];
            $active = isset($_POST['active']) ? 1 : 0;
            
            $stmt = $conn->prepare("
                UPDATE drivers 
                SET name = ?, active = ?
                WHERE id = ?
            ");
            $stmt->bind_param("sii", $name, $active, $id);
            
            if ($stmt->execute()) {
                $message = "Motorista atualizado com sucesso.";
            } else {
                $error = "Erro ao atualizar motorista: " . $conn->error;
            }
            $stmt->close();
        }
        // Excluir motorista
        else if ($_POST['action'] === 'delete' && isset($_POST['id'])) {
            $id = $_POST['id'];
            
            // Verificar se o motorista está em alguma viagem
            $check = $conn->prepare("SELECT COUNT(*) as count FROM trips WHERE driver_id = ?");
            $check->bind_param("i", $id);
            $check->execute();
            $result = $check->get_result();
            $count = $result->fetch_assoc()['count'];
            
            if ($count > 0) {
                $error = "Não é possível excluir este motorista pois ele está associado a viagens.";
            } else {
                $stmt = $conn->prepare("DELETE FROM drivers WHERE id = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $message = "Motorista excluído com sucesso.";
                } else {
                    $error = "Erro ao excluir motorista: " . $conn->error;
                }
                $stmt->close();
            }
        }
    }
}

// Definir ação
$action = $_GET['action'] ?? 'list';
$driver_id = $_GET['id'] ?? null;

// Obter dados para formulários
if ($action === 'edit' && $driver_id) {
    $stmt = $conn->prepare("SELECT * FROM drivers WHERE id = ?");
    $stmt->bind_param("i", $driver_id);
    $stmt->execute();
    $driver = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$driver) {
        $error = "Motorista não encontrado.";
        $action = 'list';
    }
}

// Listar motoristas
if ($action === 'list') {
    $result = $conn->query("SELECT * FROM drivers ORDER BY name");
    $drivers = $result->fetch_all(MYSQLI_ASSOC);
}

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <?php if ($action === 'add'): ?>
            <i class="fas fa-plus-circle me-2"></i>Novo Motorista
        <?php elseif ($action === 'edit'): ?>
            <i class="fas fa-edit me-2"></i>Editar Motorista
        <?php else: ?>
            <i class="fas fa-id-card me-2"></i>Gerenciamento de Motoristas
        <?php endif; ?>
    </h1>
    
    <?php if ($action === 'list'): ?>
        <a href="?action=add" class="btn btn-sm btn-success">
            <i class="fas fa-plus me-1"></i> Novo Motorista
        </a>
        <a href="access_codes.php" class="btn btn-primary btn-sm ms-2">
            <i class="fas fa-key"></i> Gerenciar Códigos de Acesso
        </a>
    <?php else: ?>
        <a href="drivers.php" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    <?php endif; ?>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($action === 'add' || $action === 'edit'): ?>
    <!-- Formulário de Motorista -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <?= $action === 'add' ? 'Novo Motorista' : 'Editar Motorista' ?>
            </h6>
        </div>
        <div class="card-body">
            <form method="post" action="drivers.php">
                <input type="hidden" name="action" value="<?= $action ?>">
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="id" value="<?= $driver['id'] ?>">
                <?php endif; ?>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Nome Completo*</label>
                        <input type="text" class="form-control" id="name" name="name" required 
                               value="<?= $action === 'edit' ? $driver['name'] : '' ?>" 
                               placeholder="Nome completo do motorista">
                    </div>
                    <div class="col-md-6 d-flex align-items-end">
                        <div class="form-check form-switch mt-4">
                            <input class="form-check-input" type="checkbox" id="active" name="active" 
                                   <?= ($action === 'edit' && $driver['active'] == 1) || $action === 'add' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="active">Ativo</label>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Salvar
                    </button>
                    <a href="drivers.php" class="btn btn-secondary ms-2">
                        <i class="fas fa-times me-1"></i> Cancelar
                    </a>
                </div>
            </form>
        </div>
    </div>
<?php else: ?>
    <!-- Lista de Motoristas -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Motoristas Cadastrados</h6>
        </div>
        <div class="card-body">
            <?php if (empty($drivers)): ?>
                <div class="alert alert-info">
                    Nenhum motorista cadastrado. <a href="?action=add" class="alert-link">Cadastrar novo motorista</a>.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($drivers as $driver): ?>
                                <tr>
                                    <td><?= $driver['name'] ?></td>
                                    <td>
                                        <?php if ($driver['active'] == 1): ?>
                                            <span class="badge bg-success">Ativo</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Inativo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="?action=edit&id=<?= $driver['id'] ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-danger" 
                                                data-bs-toggle="modal" data-bs-target="#deleteModal<?= $driver['id'] ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        
                                        <!-- Modal de Confirmação de Exclusão -->
                                        <div class="modal fade" id="deleteModal<?= $driver['id'] ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Confirmar Exclusão</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Tem certeza que deseja excluir o motorista <strong><?= $driver['name'] ?></strong>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                        <form method="post" action="drivers.php">
                                                            <input type="hidden" name="action" value="delete">
                                                            <input type="hidden" name="id" value="<?= $driver['id'] ?>">
                                                            <button type="submit" class="btn btn-danger">Excluir</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
