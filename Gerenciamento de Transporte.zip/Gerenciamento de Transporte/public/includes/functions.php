<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Função para verificar se o usuário está logado
function check_login() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

// Função para verificar permissões baseadas em role_id
function check_permission($required_role) {
    if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] < $required_role) {
        header('Location: index.php?error=permission');
        exit;
    }
}

// Função para verificar permissões específicas
// Verificar se a função já existe antes de declará-la
if (!function_exists('hasPermission')) {
    function hasPermission($permission_name, $user_id = null) {
        // Se não for fornecido um ID de usuário, usa o ID da sessão
        if ($user_id === null) {
            if (!isset($_SESSION['user_id'])) {
                return false;
            }
            $user_id = $_SESSION['user_id'];
        }
        
        // Se o usuário for admin (role_id = 3), concede todas as permissões
        if (isset($_SESSION['role_id']) && $_SESSION['role_id'] == 3) {
            return true;
        }
        
        // Verifica se a função connectMySQL existe
        if (!function_exists('connectMySQL')) {
            // Fallback para verificação baseada em role_id
            if ($permission_name == 'manage_users' && isset($_SESSION['role_id']) && $_SESSION['role_id'] >= 2) {
                return true;
            }
            if ($permission_name == 'manage_roles' && isset($_SESSION['role_id']) && $_SESSION['role_id'] >= 3) {
                return true;
            }
            return false;
        }
        
        $conn = connectMySQL();
        
        // Verifica se a tabela role_permissions existe
        $check_table = $conn->query("SHOW TABLES LIKE 'role_permissions'");
        if ($check_table->num_rows == 0) {
            // Se a tabela não existir, verifica apenas pelo role_id
            if ($permission_name == 'manage_users' && isset($_SESSION['role_id']) && $_SESSION['role_id'] >= 2) {
                return true;
            }
            if ($permission_name == 'manage_roles' && isset($_SESSION['role_id']) && $_SESSION['role_id'] >= 3) {
                return true;
            }
            return false;
        }
        
        // Verifica se o usuário tem a permissão específica
        $query = "SELECT rp.* FROM role_permissions rp
                JOIN permissions p ON rp.permission_id = p.id
                JOIN users u ON u.role_id = rp.role_id
                WHERE u.id = ? AND p.permission_name = ? AND u.active = 1";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("is", $user_id, $permission_name);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $has_permission = $result->num_rows > 0;
        
        $conn->close();
        
        return $has_permission;
    }
}

// Função para formatar data
function format_date($date) {
    if (empty($date) || $date == '0000-00-00') {
        return '';
    }
    $timestamp = strtotime($date);
    return date('d/m/Y', $timestamp);
}

// Função para formatar data e hora
function format_datetime($datetime) {
    if (empty($datetime)) {
        return '';
    }
    $timestamp = strtotime($datetime);
    return date('d/m/Y H:i', $timestamp);
}

// Função para converter data do formato brasileiro para o formato do MySQL
function date_to_mysql($date) {
    if (empty($date)) {
        return null;
    }
    $parts = explode('/', $date);
    if (count($parts) != 3) {
        return null;
    }
    return $parts[2] . '-' . $parts[1] . '-' . $parts[0];
}

// Função para gerar um token aleatório
function generate_token($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

// Função para sanitizar input
function sanitize_input($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Função para verificar se uma string é uma data válida no formato brasileiro
function is_valid_date($date) {
    if (empty($date)) {
        return false;
    }
    
    $pattern = '/^[0-9]{2}\/[0-9]{2}\/[0-9]{4}$/';
    if (!preg_match($pattern, $date)) {
        return false;
    }
    
    $parts = explode('/', $date);
    return checkdate($parts[1], $parts[0], $parts[2]);
}

// Função para calcular a idade a partir da data de nascimento
function calculate_age($birthdate) {
    if (empty($birthdate) || $birthdate == '0000-00-00') {
        return '';
    }
    
    $birth_date = new DateTime($birthdate);
    $today = new DateTime('today');
    $age = $birth_date->diff($today)->y;
    
    return $age;
}

// Função para formatar CPF
function format_cpf($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    
    if (strlen($cpf) != 11) {
        return $cpf;
    }
    
    return substr($cpf, 0, 3) . '.' . substr($cpf, 3, 3) . '.' . substr($cpf, 6, 3) . '-' . substr($cpf, 9, 2);
}

// Função para formatar telefone
function format_phone($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    if (strlen($phone) == 11) {
        return '(' . substr($phone, 0, 2) . ') ' . substr($phone, 2, 5) . '-' . substr($phone, 7, 4);
    } elseif (strlen($phone) == 10) {
        return '(' . substr($phone, 0, 2) . ') ' . substr($phone, 2, 4) . '-' . substr($phone, 6, 4);
    }
    
    return $phone;
}

// Função para formatar valor monetário
function format_money($value) {
    return 'R$ ' . number_format($value, 2, ',', '.');
}

// Função para converter valor monetário para o formato do MySQL
function money_to_mysql($value) {
    $value = str_replace('R$ ', '', $value);
    $value = str_replace('.', '', $value);
    $value = str_replace(',', '.', $value);
    
    return (float) $value;
}

// Função para verificar se um CPF é válido
function is_valid_cpf($cpf) {
    // Remove caracteres não numéricos
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    
    // Verifica se o CPF tem 11 dígitos
    if (strlen($cpf) != 11) {
        return false;
    }
    
    // Verifica se todos os dígitos são iguais
    if (preg_match('/^(\d)\1+$/', $cpf)) {
        return false;
    }
    
    // Calcula o primeiro dígito verificador
    $sum = 0;
    for ($i = 0; $i < 9; $i++) {
        $sum += (int) $cpf[$i] * (10 - $i);
    }
    $remainder = $sum % 11;
    $digit1 = ($remainder < 2) ? 0 : 11 - $remainder;
    
    // Verifica o primeiro dígito verificador
    if ($digit1 != (int) $cpf[9]) {
        return false;
    }
    
    // Calcula o segundo dígito verificador
    $sum = 0;
    for ($i = 0; $i < 10; $i++) {
        $sum += (int) $cpf[$i] * (11 - $i);
    }
    $remainder = $sum % 11;
    $digit2 = ($remainder < 2) ? 0 : 11 - $remainder;
    
    // Verifica o segundo dígito verificador
    return $digit2 == (int) $cpf[10];
}

// Função para gerar log de atividade
function log_activity($user_id, $action, $details = '') {
    $conn = connectMySQL();
    
    // Verificar se a tabela user_logs existe
    $check_table = $conn->query("SHOW TABLES LIKE 'user_logs'");
    if ($check_table->num_rows == 0) {
        // Criar a tabela se não existir
        $create_table = "CREATE TABLE user_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            action VARCHAR(50) NOT NULL,
            details TEXT,
            action_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $conn->query($create_table);
    }
    
    $query = "INSERT INTO user_logs (user_id, action, details, action_time) VALUES (?, ?, ?, NOW())";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iss", $user_id, $action, $details);
    $stmt->execute();
}

// Função para obter o nome do usuário pelo ID
function get_user_name($user_id) {
    $conn = connectMySQL();
    
    $query = "SELECT name FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        return $user['name'];
    }
    
    return 'Usuário Desconhecido';
}

// Função para obter o nome do papel (role) pelo ID
function get_role_name($role_id) {
    $conn = connectMySQL();
    
    // Verifica se a tabela user_roles existe
    $check_table = $conn->query("SHOW TABLES LIKE 'user_roles'");
    if ($check_table->num_rows == 0) {
        // Se a tabela não existir, retorna nomes padrão
        $roles = [
            1 => 'Usuário',
            2 => 'Gerente',
            3 => 'Administrador'
        ];
        
        return isset($roles[$role_id]) ? $roles[$role_id] : 'Desconhecido';
    }
    
    $query = "SELECT role_name FROM user_roles WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $role_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $role = $result->fetch_assoc();
        return $role['role_name'];
    }
    
    return 'Desconhecido';
}

/**
 * Obtém o nome do motorista pelo ID
 * 
 * @param int $driver_id ID do motorista
 * @return string Nome do motorista ou 'Motorista Desconhecido' se não encontrado
 */
function get_driver_name($driver_id) {
    $conn = connectMySQL();
    
    $query = "SELECT name FROM drivers WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $driver_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $driver = $result->fetch_assoc();
        return $driver['name'];
    }
    
    return 'Motorista Desconhecido';
}

/**
 * Obtém as viagens de um motorista específico
 * 
 * @param int $driver_id ID do motorista
 * @param string $status Status das viagens (opcional)
 * @param string $date_filter Filtro de data (opcional)
 * @return array Array com as viagens do motorista
 */
function get_driver_trips($driver_id, $status = null, $date_filter = null) {
    $conn = connectMySQL();
    
    $query = "SELECT t.*, 
              l1.name as origin_name, 
              l2.name as destination_name,
              v.plate as vehicle_plate,
              v.model as vehicle_model
              FROM trips t
              LEFT JOIN locations l1 ON t.origin_id = l1.id
              LEFT JOIN locations l2 ON t.destination_id = l2.id
              LEFT JOIN vehicles v ON t.vehicle_id = v.id
              WHERE t.driver_id = ?";
    
    $params = [$driver_id];
    $types = "i";
    
    if ($status) {
        $query .= " AND t.status = ?";
        $params[] = $status;
        $types .= "s";
    }
    
    if ($date_filter) {
        if ($date_filter == 'today') {
            $query .= " AND DATE(t.departure_time) = CURDATE()";
        } elseif ($date_filter == 'tomorrow') {
            $query .= " AND DATE(t.departure_time) = DATE_ADD(CURDATE(), INTERVAL 1 DAY)";
        } elseif ($date_filter == 'week') {
            $query .= " AND YEARWEEK(t.departure_time, 1) = YEARWEEK(CURDATE(), 1)";
        }
    }
    
    $query .= " ORDER BY t.departure_time ASC";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $trips = [];
    while ($row = $result->fetch_assoc()) {
        $trips[] = $row;
    }
    
    return $trips;
}

/**
 * Obtém o total de viagens de um motorista por status
 * 
 * @param int $driver_id ID do motorista
 * @return array Array com contagem de viagens por status
 */
function get_driver_trips_count($driver_id) {
    $conn = connectMySQL();
    
    $counts = [
        'scheduled' => 0,
        'in_progress' => 0,
        'completed' => 0,
        'cancelled' => 0,
        'total' => 0
    ];
    
    $query = "SELECT status, COUNT(*) as count FROM trips WHERE driver_id = ? GROUP BY status";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $driver_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        if (isset($counts[$row['status']])) {
            $counts[$row['status']] = $row['count'];
            $counts['total'] += $row['count'];
        }
    }
    
    return $counts;
}
?>
