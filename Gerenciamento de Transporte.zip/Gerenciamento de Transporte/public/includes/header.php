<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Iniciar sessão se ainda não estiver iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verificar se o usuário está logado (implementação básica)
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}
// Obter o nível de permissão do usuário
$user_role = $_SESSION['user_role'] ?? 2; // Padrão: usuário comum
// Redirecionar se não estiver logado
function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
}

// Função para obter as configurações do sistema
function getSettings() {
    $conn = connectMySQL();
    $result = $conn->query("SELECT * FROM settings LIMIT 1");
    $settings = $result->fetch_assoc();
    $conn->close();
    return $settings;
}

// Obter configurações
$settings = getSettings();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Transporte e BPA-I - <?= $settings['city_name'] ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <!-- Custom CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
            --dark-bg: #343a40;
        }
        
        body {
            font-family: 'Nunito', sans-serif;
            background-color: #f5f7fa;
        }
        
        .sidebar {
            min-height: calc(100vh - 56px);
            background-color: var(--secondary-color);
            padding-top: 20px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 10px 20px;
            margin-bottom: 5px;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover {
            background-color: rgba(255,255,255,0.1);
            color: #fff;
            transform: translateX(5px);
        }
        
        .sidebar .nav-link.active {
            background-color: var(--primary-color);
            color: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .content {
            padding: 20px;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            border: none;
            margin-bottom: 20px;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .card-header {
            background-color: #fff;
            border-bottom: 1px solid rgba(0,0,0,0.1);
            font-weight: 600;
            border-radius: 10px 10px 0 0 !important;
        }
        
        .navbar {
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }
        
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 1px;
        }
        
        .logo-img {
            max-height: 40px;
            border-radius: 5px;
        }
        
        .btn {
            border-radius: 5px;
            font-weight: 600;
            padding: 8px 16px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #2980b9;
            border-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .table {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
        
        .table thead th {
            background-color: var(--light-bg);
            border-bottom: 2px solid var(--primary-color);
            color: var(--secondary-color);
            font-weight: 600;
        }
        
        .badge {
            padding: 5px 10px;
            border-radius: 30px;
            font-weight: 600;
        }
        
        .form-control, .form-select {
            border-radius: 5px;
            border: 1px solid #ddd;
            padding: 10px 15px;
            transition: all 0.3s;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        .dropdown-menu {
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border: none;
            padding: 10px;
        }
        
        .dropdown-item {
            border-radius: 3px;
            padding: 8px 15px;
            transition: all 0.2s;
        }
        
        .dropdown-item:hover {
            background-color: var(--light-bg);
            transform: translateX(5px);
        }
        
        /* Mobile responsiveness */
        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                top: 56px;
                left: -100%;
                width: 80%;
                z-index: 1000;
                transition: all 0.3s;
            }
            
            .sidebar.show {
                left: 0;
            }
            
            .content {
                padding: 15px;
            }
            
            .card {
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <?php if (!isset($skip_main_header) || $skip_main_header !== true): ?>
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <?php if (!empty($settings['city_logo'])): ?>
                    <a class="navbar-brand" href="index.php">
                        <img src="data:<?= $settings['logo_mime_type'] ?>;base64,<?= base64_encode($settings['city_logo']) ?>" alt="Logo" class="logo-img">
                        <span class="ms-2"><?= $settings['city_name'] ?></span>
                    </a>
                <?php else: ?>
                    <a class="navbar-brand" href="index.php">
                        <i class="fas fa-ambulance me-2"></i>
                        <?= $settings['city_name'] ?>
                    </a>
                <?php endif; ?>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <?php if (isLoggedIn()): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-user-circle"></i> <?= $_SESSION['user_name'] ?? 'Usuário' ?>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i> Perfil</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a></li>
                                </ul>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="login.php"><i class="fas fa-sign-in-alt me-1"></i> Entrar</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    <?php else: ?>
        <!-- Cabeçalho simplificado para páginas administrativas -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                    <i class="fas fa-cogs me-2"></i> Administração
                </a>
                <div class="ms-auto">
                    <a href="logout.php" class="btn btn-outline-light btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Sair
                    </a>
                </div>
            </div>
        </nav>
    <?php endif; ?>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <?php if (isLoggedIn()): ?>
            <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <div class="position-sticky">
                    <ul class="nav flex-column">
                    <?php if ($user_role >= 1): ?>                         
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>" href="index.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>                         
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'trips.php?status=scheduled' ? 'active' : '' ?>" href="trips.php?status=scheduled">
                                <i class="fas fa-route"></i> Viagens
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>                         
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'calendar.php' ? 'active' : '' ?>" href="calendar.php">
                                <i class="fas fa-calendar-alt"></i> Calendário
                            </a>
                        </li>
                    <?php endif; ?>                    
                    <?php if ($user_role >= 1): ?>                         
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'patients.php' ? 'active' : '' ?>" href="patients.php">
                                <i class="fas fa-users"></i> Pacientes
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>                         
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'vehicles.php' ? 'active' : '' ?>" href="vehicles.php">
                                <i class="fas fa-car"></i> Veículos
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>                         
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'drivers.php' ? 'active' : '' ?>" href="drivers.php">
                                <i class="fas fa-id-card"></i> Motoristas
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>                         
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'access_codes.php' ? 'active' : '' ?>" href="access_codes.php">
                            <i class="fas fa-key"></i> Códigos de Acesso
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 3): ?>                         
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'professionals.php' ? 'active' : '' ?>" href="professionals.php">
                                <i class="fas fa-user-md"></i> Profissionais
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>                         
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'locations.php' ? 'active' : '' ?>" href="locations.php">
                                <i class="fas fa-map-marker-alt"></i> Locais
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>                       
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'cid10.php' ? 'active' : '' ?>" href="cid10.php">
                                <i class="fas fa-notes-medical"></i> CID-10
                            </a>
                        </li>
                    <?php endif; ?>                        
                    <?php if ($user_role >= 1): ?>                         
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'bpa_header.php' ? 'active' : '' ?>" href="bpa_header.php">
                                <i class="fas fa-file-medical"></i> Cabeçalho BPA
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>                         
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'bpa_generate.php' ? 'active' : '' ?>" href="bpa_generate.php">
                                <i class="fas fa-file-export"></i> Gerar BPA-I
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>                    
                        <!-- Diárias Menu -->
                        <li class="nav-item">
                            <a class="nav-link <?= in_array(basename($_SERVER['PHP_SELF']), ['per_diem_settings.php', 'per_diem_reports.php']) ? 'active' : '' ?>" 
                               data-bs-toggle="collapse" href="#collapseDiarias" role="button" 
                               aria-expanded="false" aria-controls="collapseDiarias">
                                <i class="fas fa-money-bill-wave"></i> Diárias <i class="fas fa-chevron-down float-end"></i>
                            </a>
                            <div class="collapse <?= in_array(basename($_SERVER['PHP_SELF']), ['per_diem_settings.php', 'per_diem_reports.php']) ? 'show' : '' ?>" id="collapseDiarias">
                                <ul class="nav flex-column ms-3">
                                    <?php if ($user_role >= 1): ?>
                                    <li class="nav-item">
                                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'per_diem_settings.php' ? 'active' : '' ?>" href="per_diem_settings.php">
                                            <i class="fas fa-cog"></i> Configurações
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if ($user_role >= 1): ?>
                                    <li class="nav-item">
                                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'per_diem_reports.php' ? 'active' : '' ?>" href="per_diem_reports.php">
                                            <i class="fas fa-chart-bar"></i> Relatórios
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>                        
                        <!-- Usuários Menu -->
                        <li class="nav-item">
                            <a class="nav-link <?= in_array(basename($_SERVER['PHP_SELF']), ['users.php', 'user_roles.php']) ? 'active' : '' ?>" 
                               data-bs-toggle="collapse" href="#collapseUsuarios" role="button" 
                               aria-expanded="false" aria-controls="collapseUsuarios">
                                <i class="fas fa-users-cog"></i> Usuários <i class="fas fa-chevron-down float-end"></i>
                            </a>
                            <div class="collapse <?= in_array(basename($_SERVER['PHP_SELF']), ['users.php', 'user_roles.php']) ? 'show' : '' ?>" id="collapseUsuarios">
                                <ul class="nav flex-column ms-3">
                                <?php if ($user_role >= 1): ?>                                    
                                    <li class="nav-item">
                                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : '' ?>" href="users.php">
                                            <i class="fas fa-user-plus"></i> Gerenciar Usuários
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if ($user_role >= 1): ?>                                        
                                    <li class="nav-item">
                                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'user_roles.php' ? 'active' : '' ?>" href="user_roles.php">
                                            <i class="fas fa-user-shield"></i> Perfis e Permissões
                                        </a>
                                    </li>
                                <?php endif; ?>                                    
                                </ul>
                            </div>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : '' ?>" href="reports.php">
                                <i class="fas fa-chart-bar"></i> Relatórios
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($user_role >= 1): ?>                        
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : '' ?>" href="settings.php">
                                <i class="fas fa-cog"></i> Configurações
                            </a>
                        </li>
                    <?php endif; ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Main content -->
            <main class="<?= isLoggedIn() ? 'col-md-9 col-lg-10 ms-sm-auto' : 'col-12' ?> px-md-4">
                <div class="content">
