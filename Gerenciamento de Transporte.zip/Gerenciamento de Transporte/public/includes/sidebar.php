<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Obter o nível de permissão do usuário
$user_role = $_SESSION['user_role'] ?? 1; // Padrão: usuário comum
?>

<div class="sidebar">
    <div class="sidebar-header">
        <h3>BPA-I Transport</h3>
    </div>
    <ul class="sidebar-menu">
        <li><a href="index.php"><i class="fas fa-home"></i> Início</a></li>
        
        <!-- Menu de Pacientes - Todos os usuários podem ver -->
        <li><a href="patients.php"><i class="fas fa-user-injured"></i> Pacientes</a></li>
        
        <!-- Menu de Viagens - Todos os usuários podem ver -->
        <li><a href="trips.php?status=scheduled"><i class="fas fa-route"></i> Viagens</a></li>
        
        <!-- Menu de Motoristas - Apenas administradores e coordenadores -->
        <?php if ($user_role >= 1): ?>
        <li>
            <a href="#" class="dropdown-toggle"><i class="fas fa-id-card"></i> Motoristas</a>
            <ul class="submenu">
                <li><a href="drivers.php"><i class="fas fa-users"></i> Gerenciar Motoristas</a></li>
                <li><a href="access_codes.php"><i class="fas fa-key"></i> Códigos de Acesso</a></li>
            </ul>
        </li>
        <?php endif; ?>
        
        <!-- Menu de Veículos - Apenas administradores e coordenadores -->
        <?php if ($user_role >= 2): ?>
        <li><a href="vehicles.php"><i class="fas fa-car"></i> Veículos</a></li>
        <?php endif; ?>
        
        <!-- Menu de Locais - Apenas administradores e coordenadores -->
        <?php if ($user_role >= 2): ?>
        <li><a href="locations.php"><i class="fas fa-map-marker-alt"></i> Locais</a></li>
        <?php endif; ?>
        
        <!-- Menu de Profissionais - Apenas administradores e coordenadores -->
        <?php if ($user_role >= 2): ?>
        <li><a href="professionals.php"><i class="fas fa-user-md"></i> Profissionais</a></li>
        <?php endif; ?>
        
        <!-- Menu de CID-10 - Apenas administradores e coordenadores -->
        <?php if ($user_role >= 2): ?>
        <li><a href="cid10.php"><i class="fas fa-book-medical"></i> CID-10</a></li>
        <?php endif; ?>
        
        <!-- Menu de Diárias - Apenas administradores e coordenadores -->
        <?php if ($user_role >= 2): ?>
        <li>
            <a href="#" class="dropdown-toggle"><i class="fas fa-money-bill-wave"></i> Diárias</a>
            <ul class="submenu">
                <li><a href="per_diem_settings.php"><i class="fas fa-cog"></i> Configurações</a></li>
                <li><a href="per_diem_reports.php"><i class="fas fa-chart-bar"></i> Relatórios</a></li>
            </ul>
        </li>
        <?php endif; ?>
        
        <!-- Menu de BPA - Apenas administradores e coordenadores -->
        <?php if ($user_role >= 2): ?>
        <li>
            <a href="#" class="dropdown-toggle"><i class="fas fa-file-medical"></i> BPA</a>
            <ul class="submenu">
                <li><a href="bpa_records.php"><i class="fas fa-list"></i> Registros</a></li>
                <li><a href="bpa_generate.php"><i class="fas fa-file-export"></i> Gerar BPA</a></li>
            </ul>
        </li>
        <?php endif; ?>
        
        <!-- Menu de Relatórios - Apenas administradores e coordenadores -->
        <?php if ($user_role >= 2): ?>
        <li><a href="reports.php"><i class="fas fa-chart-line"></i> Relatórios</a></li>
        <?php endif; ?>
        
        <!-- Menu de Usuários - Apenas administradores -->
        <?php if ($user_role >= 3): ?>
        <li>
            <a href="#" class="dropdown-toggle"><i class="fas fa-users-cog"></i> Usuários</a>
            <ul class="submenu">
                <li><a href="users.php"><i class="fas fa-users"></i> Gerenciar Usuários</a></li>
                <li><a href="user_roles.php"><i class="fas fa-user-tag"></i> Perfis e Permissões</a></li>
            </ul>
        </li>
        <?php endif; ?>
        
        <!-- Menu de Configurações - Apenas administradores -->
        <?php if ($user_role >= 3): ?>
        <li><a href="settings.php"><i class="fas fa-cogs"></i> Configurações</a></li>
        <?php endif; ?>
        
        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
    </ul>
</div>

<script>
// Script para controlar o dropdown do menu
document.addEventListener('DOMContentLoaded', function() {
    const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
    
    dropdownToggles.forEach(function(toggle) {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            const submenu = this.nextElementSibling;
            
            // Fecha todos os outros submenus
            document.querySelectorAll('.submenu').forEach(function(menu) {
                if (menu !== submenu) {
                    menu.classList.remove('active');
                }
            });
            
            // Alterna o estado do submenu atual
            submenu.classList.toggle('active');
        });
    });
});
</script>
