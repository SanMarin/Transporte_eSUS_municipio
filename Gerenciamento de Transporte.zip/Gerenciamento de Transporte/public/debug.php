<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

// Iniciar sessão
session_start();

// Incluir arquivos necessários
require_once "../config/database_transp.php";
require_once "includes/functions.php";

// Verificar se o usuário está logado e é administrador
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role_id']) || $_SESSION['role_id'] < 2) {
    header("Location: login.php?error=permission");
    exit();
}

// Criar conexão com o banco de dados
$conn = connectMySQL();

// Função para verificar se uma tabela existe
function table_exists($table_name, $conn) {
    $result = $conn->query("SHOW TABLES LIKE '$table_name'");
    return $result->num_rows > 0;
}

// Função para verificar se uma função existe
function function_exists_custom($function_name) {
    return function_exists($function_name);
}

// Obter informações do sistema
$php_version = phpversion();
$mysql_version = $conn->server_info;
$server_software = $_SERVER['SERVER_SOFTWARE'];
$session_data = print_r($_SESSION, true);

// Verificar tabelas importantes
$tables_to_check = [
    'users', 'roles', 'permissions', 'user_permissions',
    'patients', 'drivers', 'vehicles', 'trips',
    'locations', 'appointments', 'activity_log'
];

$tables_status = [];
foreach ($tables_to_check as $table) {
    $tables_status[$table] = table_exists($table, $conn);
}

// Verificar funções importantes
$functions_to_check = [
    'hasPermission', 'check_user_permission', 'connectMySQL',
    'log_activity', 'get_user_name', 'get_driver_name'
];

$functions_status = [];
foreach ($functions_to_check as $function) {
    $functions_status[$function] = function_exists_custom($function);
}

// Verificar permissões do usuário atual
$permissions_to_check = [
    'manage_users', 'manage_roles', 'manage_patients',
    'manage_drivers', 'manage_vehicles', 'manage_trips'
];

$permissions_status = [];
foreach ($permissions_to_check as $permission) {
    $permissions_status[$permission] = hasPermission($permission);
}

// Fechar conexão
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diagnóstico do Sistema - BPA-I Transport</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .status-ok {
            color: #28a745;
        }
        .status-error {
            color: #dc3545;
        }
        pre {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            overflow: auto;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1>Diagnóstico do Sistema</h1>
        <p>Esta página exibe informações de diagnóstico do sistema BPA-I Transport.</p>
        
        <div class="card mb-4">
            <div class="card-header">
                <h2 class="h5 mb-0">Informações do Sistema</h2>
            </div>
            <div class="card-body">
                <table class="table">
                    <tr>
                        <th>Versão do PHP:</th>
                        <td><?php echo $php_version; ?></td>
                    </tr>
                    <tr>
                        <th>Versão do MySQL:</th>
                        <td><?php echo $mysql_version; ?></td>
                    </tr>
                    <tr>
                        <th>Software do Servidor:</th>
                        <td><?php echo $server_software; ?></td>
                    </tr>
                    <tr>
                        <th>Data e Hora Atual:</th>
                        <td><?php echo date('d/m/Y H:i:s'); ?></td>
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="card mb-4">
            <div class="card-header">
                <h2 class="h5 mb-0">Tabelas do Banco de Dados</h2>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Tabela</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tables_status as $table => $exists): ?>
                        <tr>
                            <td><?php echo $table; ?></td>
                            <td>
                                <?php if ($exists): ?>
                                <span class="status-ok"><i class="fas fa-check-circle"></i> Existe</span>
                                <?php else: ?>
                                <span class="status-error"><i class="fas fa-times-circle"></i> Não existe</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="card mb-4">
            <div class="card-header">
                <h2 class="h5 mb-0">Funções PHP</h2>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Função</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($functions_status as $function => $exists): ?>
                        <tr>
                            <td><?php echo $function; ?></td>
                            <td>
                                <?php if ($exists): ?>
                                <span class="status-ok"><i class="fas fa-check-circle"></i> Definida</span>
                                <?php else: ?>
                                <span class="status-error"><i class="fas fa-times-circle"></i> Não definida</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="card mb-4">
            <div class="card-header">
                <h2 class="h5 mb-0">Permissões do Usuário</h2>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Permissão</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($permissions_status as $permission => $has_permission): ?>
                        <tr>
                            <td><?php echo $permission; ?></td>
                            <td>
                                <?php if ($has_permission): ?>
                                <span class="status-ok"><i class="fas fa-check-circle"></i> Permitido</span>
                                <?php else: ?>
                                <span class="status-error"><i class="fas fa-times-circle"></i> Não permitido</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="card mb-4">
            <div class="card-header">
                <h2 class="h5 mb-0">Dados da Sessão</h2>
            </div>
            <div class="card-body">
                <pre><?php echo htmlspecialchars($session_data); ?></pre>
            </div>
        </div>
        
        <div class="text-center mb-4">
            <a href="index.php" class="btn btn-primary">Voltar para o Dashboard</a>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
