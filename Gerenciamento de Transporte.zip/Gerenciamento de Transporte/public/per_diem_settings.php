<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'update_settings') {
        $full_day_amount = $_POST['full_day_amount'];
        $half_day_amount = $_POST['half_day_amount'];
        $use_distance_based = isset($_POST['use_distance_based']) ? 1 : 0;
        $short_trip_amount = $_POST['short_trip_amount'];
        $long_trip_amount = $_POST['long_trip_amount'];
        $distance_threshold = $_POST['distance_threshold'];
        
        $stmt = $conn->prepare("
            UPDATE driver_per_diem_settings 
            SET full_day_amount = ?, 
                half_day_amount = ?, 
                use_distance_based = ?, 
                short_trip_amount = ?, 
                long_trip_amount = ?, 
                distance_threshold = ?
            WHERE id = 1
        ");
        $stmt->bind_param("ddiddi", $full_day_amount, $half_day_amount, $use_distance_based, 
                         $short_trip_amount, $long_trip_amount, $distance_threshold);
        
        if ($stmt->execute()) {
            $message = "Configurações de diárias atualizadas com sucesso.";
        } else {
            $error = "Erro ao atualizar configurações: " . $conn->error;
        }
        $stmt->close();
    }
}

// Obter configurações atuais
$result = $conn->query("SELECT * FROM driver_per_diem_settings WHERE id = 1");
$settings = $result->fetch_assoc();

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <i class="fas fa-money-bill-wave me-2"></i>Configurações de Diárias
    </h1>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Configurações de Diárias para Motoristas</h6>
    </div>
    <div class="card-body">
        <form method="post">
            <input type="hidden" name="action" value="update_settings">
            
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">Diárias por Período</h6>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="full_day_amount" class="form-label">Valor da Diária Inteira (R$)</label>
                                <div class="input-group">
                                    <span class="input-group-text">R$</span>
                                    <input type="number" class="form-control" id="full_day_amount" name="full_day_amount" 
                                           step="0.01" min="0" required 
                                           value="<?= $settings['full_day_amount'] ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="half_day_amount" class="form-label">Valor da Meia Diária (R$)</label>
                                <div class="input-group">
                                    <span class="input-group-text">R$</span>
                                    <input type="number" class="form-control" id="half_day_amount" name="half_day_amount" 
                                           step="0.01" min="0" required 
                                           value="<?= $settings['half_day_amount'] ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h6 class="mb-0">Diárias por Distância</h6>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="use_distance_based" name="use_distance_based" 
                                       <?= $settings['use_distance_based'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="use_distance_based">Usar diárias por distância</label>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="short_trip_amount" class="form-label">Valor para Viagens Próximas (R$)</label>
                                <div class="input-group">
                                    <span class="input-group-text">R$</span>
                                    <input type="number" class="form-control" id="short_trip_amount" name="short_trip_amount" 
                                           step="0.01" min="0" required 
                                           value="<?= $settings['short_trip_amount'] ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="long_trip_amount" class="form-label">Valor para Viagens Distantes (R$)</label>
                                <div class="input-group">
                                    <span class="input-group-text">R$</span>
                                    <input type="number" class="form-control" id="long_trip_amount" name="long_trip_amount" 
                                           step="0.01" min="0" required 
                                           value="<?= $settings['long_trip_amount'] ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="distance_threshold" class="form-label">Limite de Distância (KM)</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="distance_threshold" name="distance_threshold" 
                                           min="1" required 
                                           value="<?= $settings['distance_threshold'] ?>">
                                    <span class="input-group-text">KM</span>
                                </div>
                                <div class="form-text">Viagens com distância maior que este valor são consideradas distantes.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Salvar Configurações
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    // Atualizar estado dos campos baseado na opção selecionada
    document.getElementById('use_distance_based').addEventListener('change', function() {
        const distanceFields = document.querySelectorAll('#short_trip_amount, #long_trip_amount, #distance_threshold');
        const periodFields = document.querySelectorAll('#full_day_amount, #half_day_amount');
        
        if (this.checked) {
            distanceFields.forEach(field => field.parentElement.parentElement.classList.remove('text-muted'));
            periodFields.forEach(field => field.parentElement.parentElement.classList.add('text-muted'));
        } else {
            distanceFields.forEach(field => field.parentElement.parentElement.classList.add('text-muted'));
            periodFields.forEach(field => field.parentElement.parentElement.classList.remove('text-muted'));
        }
    });
    
    // Executar ao carregar a página
    document.addEventListener('DOMContentLoaded', function() {
        const useDistanceCheckbox = document.getElementById('use_distance_based');
        if (useDistanceCheckbox) {
            useDistanceCheckbox.dispatchEvent(new Event('change'));
        }
    });
</script>

<?php require_once 'includes/footer.php'; ?>
