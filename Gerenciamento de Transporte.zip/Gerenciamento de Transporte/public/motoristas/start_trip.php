<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Iniciar a sessão
session_start();

// Verificar se há um motorista logado
if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit;
}

// Incluir arquivo de conexão
require_once '../../config/database_transp.php';
$conn = connectMySQL();

$error = '';
$success = '';

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $trip_id = $_POST['trip_id'] ?? 0;
    
    if (empty($trip_id)) {
        $error = "ID da viagem não informado.";
    } else {
        // Verificar se a viagem pertence ao motorista logado
        $driver_id = $_SESSION['driver_id'];
        $stmt = $conn->prepare("SELECT * FROM trips WHERE id = ? AND driver_id = ?");
        
        if ($stmt === false) {
            $error = "Erro na preparação da consulta: " . $conn->error;
        } else {
            $stmt->bind_param("ii", $trip_id, $driver_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                $error = "Viagem não encontrada ou não pertence a este motorista.";
            } else {
                $trip = $result->fetch_assoc();
                
                // Verificar se a viagem já está em andamento
                if ($trip['status'] === 'in_progress') {
                    $error = "Esta viagem já está em andamento.";
                } else if ($trip['status'] === 'completed') {
                    $error = "Esta viagem já foi concluída.";
                } else if ($trip['status'] === 'cancelled') {
                    $error = "Esta viagem foi cancelada.";
                } else {
                    // Atualizar o status da viagem para "em andamento"
                    $current_time = date('H:i:s');
                    $update_stmt = $conn->prepare("
                        UPDATE trips 
                        SET status = 'in_progress', actual_start_time = ? 
                        WHERE id = ?
                    ");
                    
                    if ($update_stmt === false) {
                        $error = "Erro na preparação da consulta de atualização: " . $conn->error;
                    } else {
                        $update_stmt->bind_param("si", $current_time, $trip_id);
                        
                        if ($update_stmt->execute()) {
                            $success = "Viagem iniciada com sucesso!";
                        } else {
                            $error = "Erro ao iniciar a viagem: " . $conn->error;
                        }
                        
                        $update_stmt->close();
                    }
                }
            }
            
            $stmt->close();
        }
    }
}

// Redirecionar de volta para a página principal
header("Location: index.php" . ($error ? "?error=" . urlencode($error) : "") . ($success ? "?success=" . urlencode($success) : ""));
exit;
