<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Iniciar a sessão
session_start();

// Verificar se há um motorista logado
if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit;
}

// Incluir arquivo de conexão
require_once '../../config/database_transp.php';
$conn = connectMySQL();

// Buscar informações do motorista
$driver_id = $_SESSION['driver_id'];

// Definir o mês atual e permitir seleção de outros meses
$selected_month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$month_start = $selected_month . '-01';
$month_end = date('Y-m-t', strtotime($month_start));

// Definir a página atual e o número de itens por página
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$items_per_page = 10;
$offset = ($page - 1) * $items_per_page;

// Buscar viagens do mês selecionado
$stmt = $conn->prepare("
    SELECT t.*, l.name as location_name, l.city as location_city, 
           (SELECT COUNT(*) FROM trip_passengers WHERE trip_id = t.id) as passenger_count
    FROM trips t
    JOIN locations l ON t.location_id = l.id
    WHERE t.driver_id = ? AND t.trip_date BETWEEN ? AND ?
    ORDER BY t.trip_date DESC, t.departure_time DESC
    LIMIT ? OFFSET ?
");
$stmt->bind_param("issii", $driver_id, $month_start, $month_end, $items_per_page, $offset);
$stmt->execute();
$trips = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Contar o total de viagens para paginação
$stmt = $conn->prepare("
    SELECT COUNT(*) as total 
    FROM trips 
    WHERE driver_id = ? AND trip_date BETWEEN ? AND ?
");
$stmt->bind_param("iss", $driver_id, $month_start, $month_end);
$stmt->execute();
$total_trips = $stmt->get_result()->fetch_assoc()['total'];
$stmt->close();

// Calcular o número total de páginas
$total_pages = ceil($total_trips / $items_per_page);

// Obter estatísticas do mês
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_trips,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_trips,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_trips
    FROM trips 
    WHERE driver_id = ? AND trip_date BETWEEN ? AND ?
");
$stmt->bind_param("iss", $driver_id, $month_start, $month_end);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico de Viagens - Portal do Motorista</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
            padding-bottom: 70px; /* Espaço para o menu fixo inferior */
            font-family: 'Poppins', sans-serif;
        }
        .navbar-brand {
            font-weight: 600;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
            overflow: hidden;
        }
        .card-header {
            background-color: #3a4a5d;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px;
            font-weight: 600;
        }
        .trip-card {
            transition: all 0.3s ease;
            border-left: 4px solid #6c757d;
        }
        .trip-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .trip-card.completed {
            border-left-color: #28a745;
        }
        .trip-card.cancelled {
            border-left-color: #dc3545;
        }
        .bottom-nav {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: #2c3e50;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        .nav-link {
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            padding: 10px 0;
        }
        .nav-link.active {
            color: #ffffff;
        }
        .nav-link i {
            font-size: 1.5rem;
            display: block;
            margin-bottom: 2px;
        }
        .logout-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            color: white;
            font-size: 1.2rem;
        }
        .pagination {
            justify-content: center;
        }
        .stats-card {
            border-radius: 10px;
            padding: 15px;
            color: white;
            text-align: center;
            height: 100%;
        }
        .stats-card i {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .stats-card h3 {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        .stats-card p {
            font-size: 0.9rem;
            margin-bottom: 0;
            opacity: 0.8;
        }
        .month-selector {
            background-color: #fff;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        .badge {
            padding: 6px 10px;
            font-weight: 500;
            border-radius: 6px;
        }
        .trip-details {
            display: none;
            background-color: #f8f9fa;
            border-radius: 0 0 10px 10px;
            padding: 15px;
            border-top: 1px solid #e9ecef;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark" style="background-color: #2c3e50;">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-history me-2"></i>Histórico de Viagens
            </a>
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </nav>
    
    <div class="container mt-4">
        <!-- Seletor de mês -->
        <div class="month-selector">
            <form method="get" class="d-flex align-items-center justify-content-between">
                <div>
                    <label for="month" class="form-label mb-0">Selecione o mês:</label>
                </div>
                <div class="d-flex">
                    <input type="month" id="month" name="month" class="form-control me-2" value="<?= $selected_month ?>">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i>
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Estatísticas -->
        <div class="row mb-4">
            <div class="col-4">
                <div class="stats-card bg-primary">
                    <i class="fas fa-route"></i>
                    <h3><?= $stats['total_trips'] ?></h3>
                    <p>Total de Viagens</p>
                </div>
            </div>
            <div class="col-4">
                <div class="stats-card bg-success">
                    <i class="fas fa-check-circle"></i>
                    <h3><?= $stats['completed_trips'] ?></h3>
                    <p>Concluídas</p>
                </div>
            </div>
            <div class="col-4">
                <div class="stats-card bg-danger">
                    <i class="fas fa-times-circle"></i>
                    <h3><?= $stats['cancelled_trips'] ?></h3>
                    <p>Canceladas</p>
                </div>
            </div>
        </div>
        
        <?php if (empty($trips)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>Você não tem histórico de viagens para o mês selecionado.
            </div>
        <?php else: ?>
            <!-- Lista de viagens anteriores -->
            <?php foreach ($trips as $trip): ?>
                <div class="card trip-card mb-3 <?= $trip['status'] ?>">
                    <div class="card-body trip-header" data-trip-id="<?= $trip['id'] ?>">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h5 class="card-title mb-0"><?= htmlspecialchars($trip['location_city']) ?></h5>
                            <span class="badge <?= $trip['status'] == 'completed' ? 'bg-success' : ($trip['status'] == 'cancelled' ? 'bg-danger' : 'bg-secondary') ?>">
                                <?= $trip['status'] == 'completed' ? 'Concluída' : ($trip['status'] == 'cancelled' ? 'Cancelada' : 'Em andamento') ?>
                            </span>
                        </div>
                        <p class="card-text">
                            <i class="fas fa-calendar-alt me-2"></i><?= date('d/m/Y', strtotime($trip['trip_date'])) ?>
                            <i class="fas fa-clock me-2"></i><?= date('H:i', strtotime($trip['departure_time'])) ?>
                        </p>
                        <p class="card-text">
                            <i class="fas fa-map-marker-alt me-2"></i><?= htmlspecialchars($trip['location_city']) ?>
                        </p>
                        <p class="card-text">
                            <i class="fas fa-users me-2"></i><?= $trip['passenger_count'] ?> passageiro(s)
                            <button class="btn btn-sm btn-outline-primary float-end show-details-btn">
                                <i class="fas fa-chevron-down"></i> Detalhes
                            </button>
                        </p>
                        <?php if (!empty($trip['notes'])): ?>
                            <p class="card-text">
                                <i class="fas fa-sticky-note me-2"></i><?= htmlspecialchars($trip['notes']) ?>
                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="trip-details" id="trip-details-<?= $trip['id'] ?>">
                        <h6 class="mb-3"><i class="fas fa-users me-2"></i>Passageiros</h6>
                        <div class="passenger-list" id="passenger-list-<?= $trip['id'] ?>">
                            <div class="text-center">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Carregando...</span>
                                </div>
                                <p class="mt-2">Carregando passageiros...</p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <!-- Paginação -->
            <?php if ($total_pages > 1): ?>
                <nav aria-label="Navegação de páginas">
                    <ul class="pagination">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?month=<?= $selected_month ?>&page=<?= $page - 1 ?>" aria-label="Anterior">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?month=<?= $selected_month ?>&page=<?= $i ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                        
                        <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?month=<?= $selected_month ?>&page=<?= $page + 1 ?>" aria-label="Próximo">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    
    <!-- Menu inferior -->
    <div class="bottom-nav">
        <div class="container">
            <div class="row">
                <div class="col-3">
                    <a href="index.php" class="nav-link active">
                        <i class="fas fa-route"></i>
                        <span class="d-block small">Hoje</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="history.php" class="nav-link">
                        <i class="fas fa-history"></i>
                        <span class="d-block small">Histórico</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="scheduled.php" class="nav-link">
                        <i class="fas fa-calendar-alt"></i>
                        <span class="d-block small">Agendadas</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="per_diem.php" class="nav-link active">
                        <i class="fas fa-money-bill-wave"></i>
                        <span class="d-block small">Diárias</span>
                    </a>
                </div>               
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script>
        $(document).ready(function() {
            // Mostrar/ocultar detalhes da viagem
            $('.show-details-btn').click(function() {
                const tripBody = $(this).closest('.trip-header');
                const tripId = tripBody.data('trip-id');
                const detailsDiv = $('#trip-details-' + tripId);
                
                if (detailsDiv.is(':visible')) {
                    detailsDiv.slideUp();
                    $(this).html('<i class="fas fa-chevron-down"></i> Detalhes');
                } else {
                    // Carregar passageiros via AJAX
                    $.ajax({
                        url: 'get_passengers.php',
                        type: 'GET',
                        data: { trip_id: tripId },
                        success: function(response) {
                            $('#passenger-list-' + tripId).html(response);
                            detailsDiv.slideDown();
                            tripBody.find('.show-details-btn').html('<i class="fas fa-chevron-up"></i> Ocultar');
                        },
                        error: function() {
                            $('#passenger-list-' + tripId).html('<div class="alert alert-danger">Erro ao carregar passageiros.</div>');
                            detailsDiv.slideDown();
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
