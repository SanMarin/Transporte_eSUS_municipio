<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Iniciar a sessão
session_start();

// Verificar se há um motorista logado
if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit;
}

// Incluir arquivo de conexão
require_once '../../config/database_transp.php';
$conn = connectMySQL();

// Verificar se a coluna actual_end_time existe na tabela trip_passengers
$check_column = $conn->query("SHOW COLUMNS FROM trip_passengers LIKE 'actual_end_time'");
if ($check_column->num_rows == 0) {
    // A coluna não existe, vamos criá-la
    $conn->query("ALTER TABLE trip_passengers ADD COLUMN actual_end_time TIME NULL");
}

// Verificar se a coluna status existe na tabela trip_passengers
$check_column = $conn->query("SHOW COLUMNS FROM trip_passengers LIKE 'status'");
if ($check_column->num_rows == 0) {
    // A coluna não existe, vamos criá-la
    $conn->query("ALTER TABLE trip_passengers ADD COLUMN status VARCHAR(20) DEFAULT 'pending' AFTER actual_end_time");
}

$error = '';
$success = '';

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $passenger_id = $_POST['passenger_id'] ?? 0;
    $actual_end_time = $_POST['actual_end_time'] ?? '';
    
    if (empty($passenger_id)) {
        $error = "ID do passageiro não informado.";
    } else if (empty($actual_end_time)) {
        $error = "Horário de término não informado.";
    } else {
        // Converter o formato de hora
        $time_obj = DateTime::createFromFormat('H:i', $actual_end_time);
        if (!$time_obj) {
            $error = "Formato de hora inválido.";
        } else {
            $formatted_time = $time_obj->format('H:i:s');
            
            // Atualizar o horário de término no banco de dados
            $query = "
                UPDATE trip_passengers 
                SET actual_end_time = ?, status = 'ready_to_return' 
                WHERE id = ?
            ";
            
            $stmt = $conn->prepare($query);
            
            if ($stmt === false) {
                $error = "Erro na preparação da consulta: " . $conn->error;
            } else {
                $stmt->bind_param("si", $formatted_time, $passenger_id);
                
                if ($stmt->execute()) {
                    $success = "Horário de término atualizado com sucesso!";
                    
                    // Verificar se todos os passageiros da viagem foram atendidos
                    // Primeiro, obter o trip_id deste passageiro
                    $get_trip = $conn->prepare("SELECT trip_id FROM trip_passengers WHERE id = ?");
                    $get_trip->bind_param("i", $passenger_id);
                    $get_trip->execute();
                    $trip_result = $get_trip->get_result();
                    
                    if ($trip_result->num_rows > 0) {
                        $trip_data = $trip_result->fetch_assoc();
                        $trip_id = $trip_data['trip_id'];
                        
                        // Verificar se todos os passageiros têm actual_end_time
                        $check_all = $conn->prepare("
                            SELECT COUNT(*) as total, 
                                   SUM(CASE WHEN actual_end_time IS NOT NULL THEN 1 ELSE 0 END) as completed
                            FROM trip_passengers 
                            WHERE trip_id = ?
                        ");
                        $check_all->bind_param("i", $trip_id);
                        $check_all->execute();
                        $count_result = $check_all->get_result()->fetch_assoc();
                        
                        // Se todos os passageiros foram atendidos, atualizar o status da viagem
                        if ($count_result['total'] == $count_result['completed'] && $count_result['total'] > 0) {
                            $update_trip = $conn->prepare("
                                UPDATE trips 
                                SET status = 'completed', actual_end_time = NOW()
                                WHERE id = ?
                            ");
                            $update_trip->bind_param("i", $trip_id);
                            $update_trip->execute();
                            $update_trip->close();
                            
                            $success .= " Todos os passageiros foram atendidos. A viagem foi concluída automaticamente.";
                        }
                        
                        $check_all->close();
                    }
                    $get_trip->close();
                } else {
                    $error = "Erro ao atualizar o horário de término: " . $conn->error;
                }
                
                $stmt->close();
            }
        }
    }
}

// Redirecionar de volta para a página principal
header("Location: index.php" . ($error ? "?error=" . urlencode($error) : "") . ($success ? "?success=" . urlencode($success) : ""));
exit;
