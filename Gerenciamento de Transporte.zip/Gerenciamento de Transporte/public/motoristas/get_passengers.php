<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Iniciar a sessão
session_start();

// Verificar se há um motorista logado
if (!isset($_SESSION['driver_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Não autorizado']);
    exit;
}

// Verificar se o ID da viagem foi fornecido
if (!isset($_GET['trip_id']) || empty($_GET['trip_id'])) {
    echo '<div class="alert alert-danger">ID da viagem não fornecido.</div>';
    exit;
}

// Incluir arquivo de conexão
require_once '../../config/database_transp.php';
$conn = connectMySQL();

// Verificar se a coluna whatsapp existe na tabela patients
$check_column = $conn->query("SHOW COLUMNS FROM patients LIKE 'whatsapp'");
if ($check_column->num_rows == 0) {
    // A coluna não existe, vamos criá-la
    $conn->query("ALTER TABLE patients ADD COLUMN whatsapp VARCHAR(20) NULL AFTER phone");
}

// Buscar informações do motorista
$driver_id = $_SESSION['driver_id'];
$trip_id = intval($_GET['trip_id']);

// Verificar se a viagem pertence ao motorista logado
$stmt = $conn->prepare("SELECT id FROM trips WHERE id = ? AND driver_id = ?");
$stmt->bind_param("ii", $trip_id, $driver_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo '<div class="alert alert-danger">Viagem não encontrada ou não pertence a este motorista.</div>';
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

// Buscar passageiros da viagem
$query = "
    SELECT tp.*, p.name, p.phone, p.address, p.address_number, p.neighborhood, p.cns,
           c.code as cid_code, c.description as cid_description,
           l.name as location_name, l.city as location_city,
           tp.appointment_time
    FROM trip_passengers tp
    JOIN patients p ON tp.patient_id = p.id
    LEFT JOIN cid10 c ON tp.cid_id = c.id
    LEFT JOIN locations l ON tp.location_id = l.id
    WHERE tp.trip_id = ?
    ORDER BY tp.appointment_time, tp.is_companion, tp.id ASC
";

$stmt = $conn->prepare($query);
if ($stmt === false) {
    echo '<div class="alert alert-danger">Erro na preparação da consulta: ' . $conn->error . '</div>';
    exit;
}

$stmt->bind_param("i", $trip_id);
$stmt->execute();
$passengers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->close();

// Se não houver passageiros
if (empty($passengers)) {
    echo '<div class="alert alert-info">Nenhum passageiro registrado para esta viagem.</div>';
    exit;
}
?>

<!-- Lista de passageiros -->
<?php foreach ($passengers as $passenger): ?>
    <div class="card mb-3">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <h6 class="card-title mb-0">
                    <?= htmlspecialchars($passenger['name']) ?>
                    <?php if ($passenger['is_companion']): ?>
                        <span class="badge bg-info ms-2">Acompanhante</span>
                    <?php endif; ?>
                </h6>
                <?php if (!empty($passenger['cid_code'])): ?>
                    <span class="badge bg-secondary">CID: <?= $passenger['cid_code'] ?></span>
                <?php endif; ?>
            </div>
            
            <p class="card-text mb-1">
                <i class="fas fa-id-card me-2"></i>CNS: <?= $passenger['cns'] ?>
            </p>
            
            <!-- Local de destino e horário -->
            <?php if (!empty($passenger['location_name'])): ?>
            <div class="bg-light p-2 rounded mb-2">
                <p class="mb-1">
                    <i class="fas fa-hospital me-2"></i><strong>Destino:</strong> 
                    <?= htmlspecialchars($passenger['location_name']) ?> 
                    <?php if (!empty($passenger['location_city'])): ?>
                        - <?= htmlspecialchars($passenger['location_city']) ?>
                    <?php endif; ?>
                </p>
                <?php if (!empty($passenger['appointment_time'])): ?>
                <p class="mb-0">
                    <i class="fas fa-clock me-2"></i><strong>Horário:</strong> 
                    <span class="badge bg-info">
                        <?= date('H:i', strtotime($passenger['appointment_time'])) ?>
                    </span>
                </p>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
            <p class="card-text mb-1">
                <i class="fas fa-map-marker-alt me-2"></i>
                <?= htmlspecialchars($passenger['address']) ?>, 
                <?= htmlspecialchars($passenger['address_number']) ?>, 
                <?= htmlspecialchars($passenger['neighborhood']) ?>
            </p>
            
            <div class="d-flex mt-3">
                <?php if (!empty($passenger['phone'])): ?>
                    <!-- Botão do WhatsApp -->
                    <a href="https://wa.me/55<?= preg_replace('/[^0-9]/', '', $passenger['phone']) ?>" 
                       class="btn btn-success btn-sm me-2" target="_blank">
                        <i class="fab fa-whatsapp me-1"></i> WhatsApp
                    </a>
                    
                    <!-- Botão de ligação -->
                    <a href="tel:<?= preg_replace('/[^0-9]/', '', $passenger['phone']) ?>" 
                       class="btn btn-primary btn-sm">
                        <i class="fas fa-phone-alt me-1"></i> Ligar
                    </a>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($passenger['notes'])): ?>
                <div class="mt-3 p-2 bg-light rounded">
                    <small><i class="fas fa-sticky-note me-1"></i> <?= nl2br(htmlspecialchars($passenger['notes'])) ?></small>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; ?>
