<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Iniciar a sessão
session_start();

// Verificar se há um motorista logado
if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit;
}

// Incluir arquivo de conexão
require_once '../../config/database_transp.php';
$conn = connectMySQL();

// Buscar informações do motorista
$driver_id = $_SESSION['driver_id'];

// Definir a página atual e o número de itens por página
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$items_per_page = 10;
$offset = ($page - 1) * $items_per_page;

// Definir o período (mês atual por padrão)
$month = isset($_GET['month']) ? intval($_GET['month']) : date('m');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Primeiro dia do mês
$first_day = sprintf("%04d-%02d-01", $year, $month);
// Último dia do mês
$last_day = date('Y-m-t', strtotime($first_day));

// Buscar diárias do período
$stmt = $conn->prepare("
    SELECT pd.*, l.name as location_name, t.trip_date
    FROM driver_per_diems pd
    JOIN trips t ON pd.trip_id = t.id
    JOIN locations l ON t.location_id = l.id
    WHERE pd.driver_id = ? AND t.trip_date BETWEEN ? AND ?
    ORDER BY t.trip_date DESC
    LIMIT ? OFFSET ?
");
$stmt->bind_param("issii", $driver_id, $first_day, $last_day, $items_per_page, $offset);
$stmt->execute();
$per_diems = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Contar o total de diárias para paginação
$stmt = $conn->prepare("
    SELECT COUNT(*) as total 
    FROM driver_per_diems pd
    JOIN trips t ON pd.trip_id = t.id
    WHERE pd.driver_id = ? AND t.trip_date BETWEEN ? AND ?
");
$stmt->bind_param("iss", $driver_id, $first_day, $last_day);
$stmt->execute();
$total_per_diems = $stmt->get_result()->fetch_assoc()['total'];
$stmt->close();

// Calcular o total de diárias do período
$stmt = $conn->prepare("
    SELECT SUM(pd.amount) as total_amount
    FROM driver_per_diems pd
    JOIN trips t ON pd.trip_id = t.id
    WHERE pd.driver_id = ? AND t.trip_date BETWEEN ? AND ?
");
$stmt->bind_param("iss", $driver_id, $first_day, $last_day);
$stmt->execute();
$total_amount = $stmt->get_result()->fetch_assoc()['total_amount'] ?? 0;
$stmt->close();

// Calcular o número total de páginas
$total_pages = ceil($total_per_diems / $items_per_page);

$conn->close();

// Função para formatar valores monetários
function formatCurrency($value) {
    return 'R$ ' . number_format($value, 2, ',', '.');
}

// Função para obter o nome do mês
function getMonthName($month) {
    $months = [
        1 => 'Janeiro',
        2 => 'Fevereiro',
        3 => 'Março',
        4 => 'Abril',
        5 => 'Maio',
        6 => 'Junho',
        7 => 'Julho',
        8 => 'Agosto',
        9 => 'Setembro',
        10 => 'Outubro',
        11 => 'Novembro',
        12 => 'Dezembro'
    ];
    return $months[$month] ?? '';
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diárias - Portal do Motorista</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding-bottom: 70px; /* Espaço para o menu fixo inferior */
        }
        .navbar-brand {
            font-weight: 600;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        .card-header {
            background-color: #0d6efd;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px;
            font-weight: 600;
        }
        .summary-card {
            background-color: #0d6efd;
            color: white;
        }
        .per-diem-card {
            transition: all 0.3s ease;
            border-left: 4px solid #28a745;
        }
        .per-diem-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .bottom-nav {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: white;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        .nav-link {
            text-align: center;
            color: #6c757d;
            padding: 10px 0;
        }
        .nav-link.active {
            color: #0d6efd;
        }
        .nav-link i {
            font-size: 1.5rem;
            display: block;
            margin-bottom: 2px;
        }
        .logout-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            color: white;
            font-size: 1.2rem;
        }
        .pagination {
            justify-content: center;
        }
        .month-selector {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        .month-selector .btn {
            padding: 6px 12px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-money-bill-wave me-2"></i>Diárias
            </a>
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </nav>
    
    <div class="container mt-4">
        <!-- Seletor de mês -->
        <div class="month-selector">
            <div class="btn-group">
                <a href="?month=<?= $month == 1 ? 12 : $month - 1 ?>&year=<?= $month == 1 ? $year - 1 : $year ?>" class="btn btn-outline-primary">
                    <i class="fas fa-chevron-left"></i>
                </a>
                <button type="button" class="btn btn-primary" disabled>
                    <?= getMonthName($month) ?> de <?= $year ?>
                </button>
                <a href="?month=<?= $month == 12 ? 1 : $month + 1 ?>&year=<?= $month == 12 ? $year + 1 : $year ?>" class="btn btn-outline-primary">
                    <i class="fas fa-chevron-right"></i>
                </a>
            </div>
        </div>
        
        <!-- Resumo de diárias -->
        <div class="card summary-card mb-4">
            <div class="card-body text-center">
                <h5 class="card-title">Total de Diárias</h5>
                <h2 class="display-6"><?= formatCurrency($total_amount) ?></h2>
                <p class="card-text">
                    <small>Período: <?= getMonthName($month) ?>/<?= $year ?></small>
                </p>
            </div>
        </div>
        
        <?php if (empty($per_diems)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>Não há diárias registradas para este período.
            </div>
        <?php else: ?>
            <!-- Lista de diárias -->
            <?php foreach ($per_diems as $per_diem): ?>
                <div class="card per-diem-card mb-3">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h5 class="card-title mb-0"><?= htmlspecialchars($per_diem['location_name']) ?></h5>
                            <span class="badge bg-success">
                                <?= formatCurrency($per_diem['amount']) ?>
                            </span>
                        </div>
                        <p class="card-text">
                            <i class="fas fa-calendar-alt me-2"></i><?= date('d/m/Y', strtotime($per_diem['trip_date'])) ?>
                        </p>
                        <?php if (!empty($per_diem['notes'])): ?>
                            <p class="card-text">
                                <i class="fas fa-sticky-note me-2"></i><?= htmlspecialchars($per_diem['notes']) ?>
                            </p>
                        <?php endif; ?>
                        <p class="card-text">
                            <small class="text-muted">
                                <i class="fas fa-clock me-1"></i>Registrado em <?= date('d/m/Y', strtotime($per_diem['created_at'])) ?>
                            </small>
                        </p>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <!-- Paginação -->
            <?php if ($total_pages > 1): ?>
                <nav aria-label="Navegação de páginas">
                    <ul class="pagination">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page - 1 ?>&month=<?= $month ?>&year=<?= $year ?>" aria-label="Anterior">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>&month=<?= $month ?>&year=<?= $year ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                        
                        <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page + 1 ?>&month=<?= $month ?>&year=<?= $year ?>" aria-label="Próximo">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    
    <!-- Menu inferior -->
    <div class="bottom-nav">
        <div class="container">
            <div class="row">
                <div class="col-3">
                    <a href="index.php" class="nav-link active">
                        <i class="fas fa-route"></i>
                        <span class="d-block small">Hoje</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="history.php" class="nav-link">
                        <i class="fas fa-history"></i>
                        <span class="d-block small">Histórico</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="scheduled.php" class="nav-link">
                        <i class="fas fa-calendar-alt"></i>
                        <span class="d-block small">Agendadas</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="per_diem.php" class="nav-link active">
                        <i class="fas fa-money-bill-wave"></i>
                        <span class="d-block small">Diárias</span>
                    </a>
                </div>               
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>
</html>
