<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Iniciar a sessão
session_start();

// Verificar se há um motorista logado
if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit;
}

// Incluir arquivo de conexão
require_once '../../config/database_transp.php';
$conn = connectMySQL();

// Buscar informações do motorista
$driver_id = $_SESSION['driver_id'];

// Buscar viagens agendadas (futuras)
$today = date('Y-m-d');
$stmt = $conn->prepare("
    SELECT t.*, l.name as location_name, l.city as location_city, v.plate, v.model,
           (SELECT COUNT(*) FROM trip_passengers WHERE trip_id = t.id) as passenger_count
    FROM trips t
    JOIN locations l ON t.location_id = l.id
    JOIN vehicles v ON t.vehicle_id = v.id
    WHERE t.driver_id = ? AND (t.trip_date > ? OR (t.trip_date = ? AND t.status = 'scheduled'))
    ORDER BY t.trip_date ASC, t.departure_time ASC
");
$stmt->bind_param("iss", $driver_id, $today, $today);
$stmt->execute();
$trips = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Viagens Agendadas - Portal do Motorista</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
            padding-bottom: 70px; /* Espaço para o menu fixo inferior */
            font-family: 'Poppins', sans-serif;
        }
        .navbar-brand {
            font-weight: 600;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
            overflow: hidden;
        }
        .card-header {
            background-color: #3a4a5d;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px;
            font-weight: 600;
        }
        .trip-card {
            transition: all 0.3s ease;
            border-left: 4px solid #6c757d;
        }
        .trip-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .bottom-nav {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: #2c3e50;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        .nav-link {
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            padding: 10px 0;
        }
        .nav-link.active {
            color: #ffffff;
        }
        .nav-link i {
            font-size: 1.5rem;
            display: block;
            margin-bottom: 2px;
        }
        .logout-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            color: white;
            font-size: 1.2rem;
        }
        .badge {
            padding: 6px 10px;
            font-weight: 500;
            border-radius: 6px;
        }
        .trip-details {
            display: none;
            background-color: #f8f9fa;
            border-radius: 0 0 10px 10px;
            padding: 15px;
            border-top: 1px solid #e9ecef;
        }
        .date-header {
            background-color: #e9ecef;
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark" style="background-color: #2c3e50;">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-calendar-alt me-2"></i>Viagens Agendadas
            </a>
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </nav>
    
    <div class="container mt-4">
        <?php if (empty($trips)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>Você não tem viagens agendadas.
            </div>
        <?php else: ?>
            <?php 
            $current_date = null;
            foreach ($trips as $trip): 
                $trip_date = date('Y-m-d', strtotime($trip['trip_date']));
                
                // Mostrar cabeçalho da data se for uma nova data
                if ($trip_date != $current_date):
                    $current_date = $trip_date;
                    $date_display = date('d/m/Y', strtotime($trip_date));
                    $is_today = ($trip_date == date('Y-m-d'));
            ?>
                <div class="date-header">
                    <i class="fas fa-calendar-day me-2"></i>
                    <?= $date_display ?>
                    <?php if ($is_today): ?>
                        <span class="badge bg-primary ms-2">Hoje</span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <div class="card trip-card mb-3">
                <div class="card-body trip-header" data-trip-id="<?= $trip['id'] ?>">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h5 class="card-title mb-0"><?= htmlspecialchars($trip['location_city']) ?></h5>
                        <span class="badge bg-info">
                            <i class="fas fa-clock me-1"></i><?= date('H:i', strtotime($trip['departure_time'])) ?>
                        </span>
                    </div>
                    <p class="card-text">
                        <i class="fas fa-map-marker-alt me-2"></i><?= htmlspecialchars($trip['location_city']) ?> - <?= htmlspecialchars($trip['location_city']) ?>
                    </p>
                    <p class="card-text">
                        <i class="fas fa-car me-2"></i><?= htmlspecialchars($trip['plate']) ?> - <?= htmlspecialchars($trip['model']) ?>
                    </p>
                    <p class="card-text">
                        <i class="fas fa-users me-2"></i><?= $trip['passenger_count'] ?> passageiro(s)
                        <button class="btn btn-sm btn-outline-primary float-end show-details-btn">
                            <i class="fas fa-chevron-down"></i> Detalhes
                        </button>
                    </p>
                    <?php if (!empty($trip['notes'])): ?>
                        <p class="card-text">
                            <i class="fas fa-sticky-note me-2"></i><?= htmlspecialchars($trip['notes']) ?>
                        </p>
                    <?php endif; ?>
                </div>
                <div class="trip-details" id="trip-details-<?= $trip['id'] ?>">
                    <h6 class="mb-3"><i class="fas fa-users me-2"></i>Passageiros</h6>
                    <div class="passenger-list" id="passenger-list-<?= $trip['id'] ?>">
                        <div class="text-center">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Carregando...</span>
                            </div>
                            <p class="mt-2">Carregando passageiros...</p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <!-- Menu inferior -->
    <div class="bottom-nav">
        <div class="container">
            <div class="row">
                <div class="col-3">
                    <a href="index.php" class="nav-link active">
                        <i class="fas fa-route"></i>
                        <span class="d-block small">Hoje</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="history.php" class="nav-link">
                        <i class="fas fa-history"></i>
                        <span class="d-block small">Histórico</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="scheduled.php" class="nav-link">
                        <i class="fas fa-calendar-alt"></i>
                        <span class="d-block small">Agendadas</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="per_diem.php" class="nav-link active">
                        <i class="fas fa-money-bill-wave"></i>
                        <span class="d-block small">Diárias</span>
                    </a>
                </div>               
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script>
        $(document).ready(function() {
            // Mostrar/ocultar detalhes da viagem
            $('.show-details-btn').click(function() {
                const tripBody = $(this).closest('.trip-header');
                const tripId = tripBody.data('trip-id');
                const detailsDiv = $('#trip-details-' + tripId);
                
                if (detailsDiv.is(':visible')) {
                    detailsDiv.slideUp();
                    $(this).html('<i class="fas fa-chevron-down"></i> Detalhes');
                } else {
                    // Carregar passageiros via AJAX
                    $.ajax({
                        url: 'get_passengers.php',
                        type: 'GET',
                        data: { trip_id: tripId },
                        success: function(response) {
                            $('#passenger-list-' + tripId).html(response);
                            detailsDiv.slideDown();
                            tripBody.find('.show-details-btn').html('<i class="fas fa-chevron-up"></i> Ocultar');
                        },
                        error: function() {
                            $('#passenger-list-' + tripId).html('<div class="alert alert-danger">Erro ao carregar passageiros.</div>');
                            detailsDiv.slideDown();
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
