<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Iniciar a sessão
session_start();

// Verificar se há um motorista logado
if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit;
}

// Incluir arquivo de conexão
require_once '../../config/database_transp.php';
$conn = connectMySQL();

// Verificar se a coluna whatsapp existe na tabela patients
$check_column = $conn->query("SHOW COLUMNS FROM patients LIKE 'whatsapp'");
if ($check_column->num_rows == 0) {
    // A coluna não existe, vamos criá-la
    $conn->query("ALTER TABLE patients ADD COLUMN whatsapp VARCHAR(20) NULL AFTER phone");
}

// Verificar se a coluna actual_start_time existe na tabela trips
$check_column = $conn->query("SHOW COLUMNS FROM trips LIKE 'actual_start_time'");
if ($check_column->num_rows == 0) {
    // A coluna não existe, vamos criá-la
    $conn->query("ALTER TABLE trips ADD COLUMN actual_start_time TIME NULL AFTER departure_time");
}

// Verificar se a coluna actual_end_time existe na tabela trip_passengers
$check_column = $conn->query("SHOW COLUMNS FROM trip_passengers LIKE 'actual_end_time'");
if ($check_column->num_rows == 0) {
    // A coluna não existe, vamos criá-la
    $conn->query("ALTER TABLE trip_passengers ADD COLUMN actual_end_time TIME NULL");
}

// Verificar se a coluna status existe na tabela trip_passengers
$check_column = $conn->query("SHOW COLUMNS FROM trip_passengers LIKE 'status'");
if ($check_column->num_rows == 0) {
    // A coluna não existe, vamos criá-la
    $conn->query("ALTER TABLE trip_passengers ADD COLUMN status VARCHAR(20) DEFAULT 'pending' AFTER actual_end_time");
}

// Buscar informações do motorista
$driver_id = $_SESSION['driver_id'];
$stmt = $conn->prepare("SELECT * FROM drivers WHERE id = ?");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$driver = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Buscar viagens do dia atual
$today = date('Y-m-d');
$stmt = $conn->prepare("
    SELECT t.*, l.name as location_name, l.city as location_city, v.plate, v.model
    FROM trips t
    JOIN locations l ON t.location_id = l.id
    JOIN vehicles v ON t.vehicle_id = v.id
    WHERE t.driver_id = ? AND t.trip_date = ? AND t.status != 'cancelled'
    ORDER BY t.departure_time ASC
");
$stmt->bind_param("is", $driver_id, $today);
$stmt->execute();
$trips_today = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Preparar a viagem atual (a primeira viagem do dia que não esteja completa)
$current_trip = null;
foreach ($trips_today as $trip) {
    if ($trip['status'] != 'completed') {
        $current_trip = $trip;
        break;
    }
}

// Verificar se há mensagens de erro ou sucesso
$error = $_GET['error'] ?? '';
$success = $_GET['success'] ?? '';
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal do Motorista</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
            padding-bottom: 70px; /* Espaço para o menu fixo inferior */
            font-family: 'Poppins', sans-serif;
        }
        .navbar-brand {
            font-weight: 600;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
            overflow: hidden;
        }
        .card-header {
            background-color: #3a4a5d;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px;
            font-weight: 600;
        }
        .passenger-card {
            border-left: 4px solid #3a4a5d;
            transition: all 0.3s ease;
            margin-bottom: 15px;
            border-radius: 8px;
            overflow: hidden;
        }
        .passenger-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        .contact-buttons {
            display: flex;
            gap: 10px;
        }
        .contact-buttons a {
            flex: 1;
            padding: 8px;
            text-align: center;
            border-radius: 5px;
            text-decoration: none;
            color: white;
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .whatsapp-btn {
            background-color: #25D366;
        }
        .call-btn {
            background-color: #007bff;
        }
        .bottom-nav {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: #2c3e50;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        .nav-link {
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            padding: 10px 0;
        }
        .nav-link.active {
            color: #ffffff;
        }
        .nav-link i {
            font-size: 1.5rem;
            display: block;
            margin-bottom: 2px;
        }
        .logout-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            color: white;
            font-size: 1.2rem;
        }
        .welcome-card {
            background: linear-gradient(135deg, #3a4a5d 0%, #2c3e50 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .welcome-card h4 {
            font-weight: 600;
            margin-bottom: 5px;
        }
        .welcome-card p {
            opacity: 0.9;
            margin-bottom: 0;
        }
        .trip-info {
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 10px;
            margin-top: 15px;
        }
        .trip-info p {
            margin-bottom: 5px;
        }
        .no-trips {
            text-align: center;
            padding: 30px 20px;
        }
        .no-trips i {
            font-size: 3rem;
            color: #6c757d;
            margin-bottom: 15px;
        }
        .no-trips h5 {
            font-weight: 600;
            margin-bottom: 10px;
        }
        .passenger-status {
            display: flex;
            align-items: center;
            margin-top: 10px;
            padding: 8px;
            background-color: #f8f9fa;
            border-radius: 6px;
        }
        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .status-pending {
            background-color: #ffc107;
        }
        .status-completed {
            background-color: #28a745;
        }
        .appointment-time {
            display: inline-block;
            background-color: #e9f5ff;
            color: #0056b3;
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: 500;
            margin-top: 5px;
        }
        .location-info {
            background-color: #f8f9fa;
            padding: 8px;
            border-radius: 6px;
            margin-top: 10px;
        }
        .location-info p {
            margin-bottom: 3px;
            font-size: 0.9rem;
        }
        .whatsapp-icon {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: #25D366;
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }
        .whatsapp-icon:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        }
        .start-trip-btn {
            background-color: #28a745;
            color: white;
            font-weight: 600;
            padding: 12px 20px;
            border-radius: 8px;
            margin-top: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            border: none;
        }
        .start-trip-btn:hover {
            background-color: #218838;
            transform: translateY(-2px);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        }
        .start-trip-btn i {
            margin-right: 8px;
        }
        .trip-status {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 500;
            margin-top: 10px;
        }
        .status-scheduled {
            background-color: #e9ecef;
            color: #495057;
        }
        .status-in-progress {
            background-color: #cff4fc;
            color: #055160;
        }
        .alert-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 350px;
        }
        .custom-alert {
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            margin-bottom: 10px;
            padding: 15px;
            animation: slideIn 0.3s ease-out forwards;
        }
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark" style="background-color: #2c3e50;">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-user-circle me-2"></i>Portal do Motorista
            </a>
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </nav>
    
    <!-- Alertas -->
    <?php if (!empty($error) || !empty($success)): ?>
    <div class="alert-container">
        <?php if (!empty($error)): ?>
        <div class="custom-alert alert alert-danger">
            <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
        <div class="custom-alert alert alert-success">
            <i class="fas fa-check-circle me-2"></i><?= htmlspecialchars($success) ?>
        </div>
        <?php endif; ?>
    </div>
    
    <script>
        // Auto-esconder alertas após 5 segundos
        setTimeout(function() {
            var alerts = document.querySelectorAll('.custom-alert');
            alerts.forEach(function(alert) {
                alert.style.opacity = '0';
                alert.style.transform = 'translateX(100%)';
                alert.style.transition = 'opacity 0.3s ease-out, transform 0.3s ease-out';
                setTimeout(function() {
                    alert.remove();
                }, 300);
            });
        }, 5000);
    </script>
    <?php endif; ?>
    
    <div class="container mt-4">
        <!-- Card de boas-vindas -->
        <div class="welcome-card">
            <h4>Olá, <?= htmlspecialchars($driver['name']) ?>!</h4>
            <p><?= date('d/m/Y') ?></p>
            
            <?php if ($current_trip): ?>
                <div class="trip-info">
                    <p><i class="fas fa-route me-2"></i><strong>Próxima viagem:</strong> <?= htmlspecialchars($current_trip['location_name']) ?></p>
                    <p><i class="fas fa-clock me-2"></i><strong>Horário de saída:</strong> <?= date('H:i', strtotime($current_trip['departure_time'])) ?></p>
                    <p><i class="fas fa-car me-2"></i><strong>Veículo:</strong> <?= htmlspecialchars($current_trip['plate']) ?> - <?= htmlspecialchars($current_trip['model']) ?></p>
                    
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="trip-status <?= $current_trip['status'] == 'scheduled' ? 'status-scheduled' : 'status-in-progress' ?>">
                            <i class="fas <?= $current_trip['status'] == 'scheduled' ? 'fa-clock' : 'fa-car-side' ?> me-1"></i>
                            <?= $current_trip['status'] == 'scheduled' ? 'Agendada' : 'Em andamento' ?>
                        </span>
                        
                        <?php if ($current_trip['status'] == 'scheduled'): ?>
                        <form method="post" action="start_trip.php">
                            <input type="hidden" name="trip_id" value="<?= $current_trip['id'] ?>">
                            <button type="submit" class="btn start-trip-btn">
                                <i class="fas fa-play"></i>Iniciar Viagem
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="trip-info">
                    <p><i class="fas fa-check-circle me-2"></i>Você não tem mais viagens programadas para hoje.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Viagem Atual -->
        <?php if ($current_trip): ?>
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-route me-2"></i>Viagem Atual</span>
                    <span class="badge bg-primary"><?= date('d/m/Y', strtotime($current_trip['trip_date'])) ?></span>
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($current_trip['location_name']) ?> - <?= htmlspecialchars($current_trip['location_city']) ?></h5>
                    
                    <?php if ($current_trip['status'] == 'scheduled'): ?>
                    <div class="alert alert-warning mt-3">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Atenção:</strong> Você precisa iniciar a viagem para registrar os atendimentos.
                    </div>
                    <?php endif; ?>
                    
                    <!-- Passageiros desta viagem -->
                    <h6 class="mt-4 mb-3"><i class="fas fa-users me-2"></i>Passageiros:</h6>
                    
                    <?php
                    // Buscar passageiros da viagem atual
                    $trip_id = $current_trip['id'];
                    $query = "
                        SELECT tp.*, p.name, p.phone, p.address, p.address_number, p.neighborhood, p.cns,
                               c.code as cid_code, c.description as cid_description,
                               l.name as location_name, l.city as location_city,
                               p2.name as companion_of_name
                        FROM trip_passengers tp
                        JOIN patients p ON tp.patient_id = p.id
                        LEFT JOIN cid10 c ON tp.cid_id = c.id
                        LEFT JOIN locations l ON tp.location_id = l.id
                        LEFT JOIN patients p2 ON tp.companion_of = p2.id
                        WHERE tp.trip_id = ?
                        ORDER BY tp.appointment_time, tp.is_companion, tp.id ASC
                    ";
                    
                    $stmt = $conn->prepare($query);
                    if ($stmt === false) {
                        echo "Erro na preparação da consulta: " . $conn->error;
                    } else {
                        $stmt->bind_param("i", $trip_id);
                        $stmt->execute();
                        $passengers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                        $stmt->close();
                        
                        if (count($passengers) > 0):
                            foreach ($passengers as $passenger):
                                // Verificar se o passageiro tem um horário de término registrado
                                $has_end_time = isset($passenger['actual_end_time']) && !empty($passenger['actual_end_time']);
                    ?>
                    <div class="card passenger-card">
                        <div class="card-body position-relative">
                            <!-- Ícone do WhatsApp flutuante -->
                            <?php if (!empty($passenger['phone'])): ?>
                            <a href="https://wa.me/55<?= preg_replace('/[^0-9]/', '', $passenger['phone']) ?>" 
                               class="whatsapp-icon" target="_blank">
                                <i class="fab fa-whatsapp"></i>
                            </a>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h6 class="card-title">
                                        <?= htmlspecialchars($passenger['name']) ?>
                                        <?php if ($passenger['is_companion']): ?>
                                            <span class="badge bg-info ms-2">Acompanhante</span>
                                        <?php endif; ?>
                                    </h6>
                                    <p class="mb-1"><i class="fas fa-id-card me-2"></i>CNS: <?= $passenger['cns'] ?></p>
                                    <?php if (!empty($passenger['cid_code'])): ?>
                                        <p class="mb-1"><i class="fas fa-file-medical me-2"></i>CID: <?= $passenger['cid_code'] ?> - <?= $passenger['cid_description'] ?></p>
                                    <?php endif; ?>
                                </div>
                                <?php if ($has_end_time): ?>
                                    <span class="badge bg-success">Concluído</span>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Local de destino e horário -->
                            <?php if (!empty($passenger['location_name'])): ?>
                            <div class="location-info">
                                <p><i class="fas fa-hospital me-2"></i><strong>Destino:</strong> <?= htmlspecialchars($passenger['location_name']) ?> 
                                <?php if (!empty($passenger['location_city'])): ?>
                                    - <?= htmlspecialchars($passenger['location_city']) ?>
                                <?php endif; ?>
                                </p>
                                <?php if (!empty($passenger['appointment_time'])): ?>
                                <p><i class="fas fa-clock me-2"></i><strong>Horário:</strong> 
                                    <span class="appointment-time">
                                        <?= date('H:i', strtotime($passenger['appointment_time'])) ?>
                                    </span>
                                </p>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            
                            <p class="mb-1 mt-3"><i class="fas fa-map-marker-alt me-2"></i>
                                <?= htmlspecialchars($passenger['address']) ?>, 
                                <?= htmlspecialchars($passenger['address_number']) ?>, 
                                <?= htmlspecialchars($passenger['neighborhood']) ?>
                            </p>
                            
                            <div class="contact-buttons mt-3">
                                <?php if (!empty($passenger['phone'])): ?>
                                <a href="https://wa.me/55<?= preg_replace('/[^0-9]/', '', $passenger['phone']) ?>" 
                                   class="whatsapp-btn" target="_blank">
                                    <i class="fab fa-whatsapp me-1"></i> WhatsApp
                                </a>
                                
                                <a href="tel:<?= preg_replace('/[^0-9]/', '', $passenger['phone']) ?>" 
                                   class="call-btn">
                                    <i class="fas fa-phone-alt me-1"></i> Ligar
                                </a>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Atualizar horário de término -->
                            <div class="passenger-status">
                                <div class="status-indicator <?= $has_end_time ? 'status-completed' : 'status-pending' ?>"></div>
                                <?php if (!$has_end_time): ?>
                                    <?php if ($current_trip['status'] == 'in_progress'): ?>
                                    <form method="post" action="update_end_time.php" class="row g-2 w-100">
                                        <input type="hidden" name="passenger_id" value="<?= $passenger['id'] ?>">
                                        <div class="col-8">
                                            <input type="time" class="form-control form-control-sm" name="actual_end_time" 
                                                placeholder="Horário de término">
                                        </div>
                                        <div class="col-4">
                                            <button type="submit" class="btn btn-primary btn-sm w-100">Concluir</button>
                                        </div>
                                    </form>
                                    <?php else: ?>
                                    <div class="text-muted">
                                        <i class="fas fa-info-circle me-1"></i>
                                        Inicie a viagem para registrar o atendimento
                                    </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div>Concluído às <?= date('H:i', strtotime($passenger['actual_end_time'])) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php
                            endforeach;
                        else:
                    ?>
                    <div class="alert alert-info">
                        Nenhum passageiro registrado para esta viagem.
                    </div>
                    <?php 
                        endif;
                    }
                    ?>
                </div>
            </div>
        <?php elseif (empty($trips_today)): ?>
            <div class="card">
                <div class="card-body no-trips">
                    <i class="fas fa-calendar-day"></i>
                    <h5>Sem viagens hoje</h5>
                    <p class="text-muted">Você não tem viagens programadas para hoje.</p>
                    <a href="scheduled.php" class="btn btn-outline-primary mt-3">
                        <i class="fas fa-calendar-alt me-1"></i> Ver viagens agendadas
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-check-circle me-2"></i>Viagens de Hoje
                </div>
                <div class="card-body">
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i>Todas as viagens de hoje foram concluídas.
                    </div>
                    
                    <h6 class="mt-3 mb-3"><i class="fas fa-history me-2"></i>Viagens concluídas:</h6>
                    
                    <div class="list-group">
                        <?php foreach ($trips_today as $trip): ?>
                            <div class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?= htmlspecialchars($trip['location_name']) ?></h6>
                                    <small><?= date('H:i', strtotime($trip['departure_time'])) ?></small>
                                </div>
                                <p class="mb-1"><?= htmlspecialchars($trip['location_city']) ?></p>
                                <small class="text-muted">
                                    <i class="fas fa-car me-1"></i><?= htmlspecialchars($trip['plate']) ?>
                                </small>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Menu inferior -->
    <div class="bottom-nav">
        <div class="container">
            <div class="row">
                <div class="col-3">
                    <a href="index.php" class="nav-link active">
                        <i class="fas fa-route"></i>
                        <span class="d-block small">Hoje</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="history.php" class="nav-link">
                        <i class="fas fa-history"></i>
                        <span class="d-block small">Histórico</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="scheduled.php" class="nav-link">
                        <i class="fas fa-calendar-alt"></i>
                        <span class="d-block small">Agendadas</span>
                    </a>
                </div>
                <div class="col-3">
                    <a href="per_diem.php" class="nav-link active">
                        <i class="fas fa-money-bill-wave"></i>
                        <span class="d-block small">Diárias</span>
                    </a>
                </div>               
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>
</html>
