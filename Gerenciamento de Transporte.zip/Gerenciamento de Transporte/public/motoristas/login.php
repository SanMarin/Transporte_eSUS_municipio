<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Iniciar a sessão
session_start();

// Se já estiver logado, redireciona para a página inicial
if (isset($_SESSION['driver_id'])) {
    header("Location: index.php");
    exit;
}

// Incluir arquivo de conexão
require_once '../../config/database_transp.php';
$conn = connectMySQL();

$error = '';
$success = '';

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar qual formulário foi enviado
    if (isset($_POST['verification_code'])) {
        // Verificar o código de acesso
        $code = trim($_POST['verification_code']);
        
        if (empty($code)) {
            $error = "Por favor, informe o código de acesso.";
        } else {
            // Verificar se a tabela drivers existe
            $tableCheck = $conn->query("SHOW TABLES LIKE 'drivers'");
            if ($tableCheck->num_rows == 0) {
                $error = "Erro de configuração: Tabela de motoristas não encontrada.";
            } else {
                // Verificar se as colunas necessárias existem
                $columnCheck = $conn->query("SHOW COLUMNS FROM drivers LIKE 'access_code'");
                if ($columnCheck->num_rows == 0) {
                    $error = "Erro de configuração: Coluna de código de acesso não encontrada.";
                } else {
                    // Verificar se o código existe no banco de dados
                    $stmt = $conn->prepare("SELECT id, name FROM drivers WHERE access_code = ? AND access_code_status = 'active' AND active = 1");
                    
                    // Verificar se a preparação da consulta foi bem-sucedida
                    if ($stmt === false) {
                        $error = "Erro na consulta SQL: " . $conn->error;
                    } else {
                        $stmt->bind_param("s", $code);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result->num_rows === 1) {
                            $driver = $result->fetch_assoc();
                            
                            // Armazena o ID do motorista na sessão
                            $_SESSION['driver_id'] = $driver['id'];
                            $_SESSION['driver_name'] = $driver['name'];
                            
                            // Registrar o login do motorista
                            $logStmt = $conn->prepare("INSERT INTO driver_login_log (driver_id, login_time, ip_address) VALUES (?, NOW(), ?)");
                            if ($logStmt) {
                                $ipAddress = $_SERVER['REMOTE_ADDR'];
                                $logStmt->bind_param("is", $driver['id'], $ipAddress);
                                $logStmt->execute();
                                $logStmt->close();
                            }
                            
                            // Redirecionar para a página inicial
                            header("Location: index.php");
                            exit;
                        } else {
                            $error = "Código de acesso inválido ou motorista inativo.";
                        }
                        
                        $stmt->close();
                    }
                }
            }
        }
    }
}

// Obter configurações
$settingsQuery = $conn->query("SELECT city_name, city_logo, logo_mime_type FROM settings LIMIT 1");
if ($settingsQuery) {
    $settings = $settingsQuery->fetch_assoc();
} else {
    $settings = [
        'city_name' => 'Sistema de Transporte',
        'city_logo' => null,
        'logo_mime_type' => null
    ];
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Portal do Motorista</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            background-color: #f8f9fa;
            font-family: 'Poppins', sans-serif;
        }
        .form-signin {
            width: 100%;
            max-width: 400px;
            padding: 15px;
            margin: auto;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border: none;
            overflow: hidden;
        }
        .card-header {
            background-color: #4361ee;
            color: white;
            text-align: center;
            padding: 25px;
            border-bottom: none;
        }
        .logo-img {
            max-height: 90px;
            margin-bottom: 15px;
            filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1));
        }
        .card-body {
            padding: 30px;
        }
        .form-floating .form-control {
            border-radius: 10px;
            height: 60px;
            font-size: 16px;
            border: 1px solid #e0e0e0;
        }
        .form-floating .form-control:focus {
            border-color: #4361ee;
            box-shadow: 0 0 0 0.25rem rgba(67, 97, 238, 0.25);
        }
        .form-floating label {
            padding: 1rem 1rem;
        }
        .btn-primary {
            background-color: #4361ee;
            border-color: #4361ee;
            border-radius: 10px;
            padding: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #3a56d4;
            border-color: #3a56d4;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }
        .alert {
            border-radius: 10px;
        }
        .text-muted {
            color: #6c757d !important;
        }
        .footer-text {
            font-size: 14px;
            color: #6c757d;
        }
        .card-header h1 {
            font-weight: 700;
            margin-bottom: 5px;
        }
        .card-header p {
            opacity: 0.9;
            font-weight: 300;
        }
        .input-icon {
            position: absolute;
            top: 50%;
            right: 15px;
            transform: translateY(-50%);
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="form-signin">
        <div class="card">
            <div class="card-header">
                <?php if (!empty($settings['city_logo'])): ?>
                    <img src="data:<?= $settings['logo_mime_type'] ?>;base64,<?= base64_encode($settings['city_logo']) ?>" alt="Logo" class="logo-img">
                <?php else: ?>
                    <i class="fas fa-car-side fa-4x mb-3"></i>
                <?php endif; ?>
                <h1 class="h4">Portal do Motorista</h1>
                <p class="mb-0"><?= htmlspecialchars($settings['city_name'] ?? 'Sistema de Transporte') ?></p>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i><?= $success ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                    </div>
                <?php endif; ?>
                
                <form method="post">
                    <div class="form-floating mb-4 position-relative">
                        <input type="text" class="form-control" id="verification_code" name="verification_code" placeholder="Código de Acesso" required autofocus>
                        <label for="verification_code">Código de Acesso</label>
                        <i class="fas fa-key input-icon"></i>
                    </div>
                    
                    <button class="w-100 btn btn-lg btn-primary d-flex align-items-center justify-content-center" type="submit">
                        <i class="fas fa-sign-in-alt me-2"></i>Entrar
                    </button>
                    
                    <div class="text-center mt-4">
                        <small class="text-muted">
                            Entre com o código fornecido pelo seu coordenador
                        </small>
                    </div>
                </form>
            </div>
        </div>
        <p class="mt-4 mb-3 text-center footer-text">&copy; <?= date('Y') ?> <?= htmlspecialchars($settings['city_name'] ?? 'Sistema de Transporte') ?></p>
    </div>
    
    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Auto-dismiss alerts after 5 seconds -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(function(alert) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                });
            }, 5000);
        });
    </script>
</body>
</html>
