<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

// Arquivo para adicionar um usuário de teste
include '../config/database_transp.php';

echo "<h1>Adicionar Usuário de Teste</h1>";

try {
    $conn = connectMySQL();
    
    // Verificar se a tabela users existe
    $result = $conn->query("SHOW TABLES LIKE 'users'");
    if ($result->num_rows == 0) {
        echo "<p style='color: red;'>❌ A tabela 'users' não existe! <a href='create_users_table.php'>Criar tabela</a></p>";
        exit;
    }
    
    // Verificar se já existe um usuário admin
    $result = $conn->query("SELECT * FROM users WHERE username = 'admin'");
    if ($result->num_rows > 0) {
        echo "<p style='color: orange;'>⚠️ Já existe um usuário 'admin'!</p>";
        
        // Mostrar detalhes do usuário admin
        $admin = $result->fetch_assoc();
        echo "<h2>Detalhes do usuário admin:</h2>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Username</th><th>Nome</th><th>Email</th><th>Role ID</th><th>Senha</th></tr>";
        echo "<tr>";
        echo "<td>" . $admin['id'] . "</td>";
        echo "<td>" . $admin['username'] . "</td>";
        echo "<td>" . $admin['name'] . "</td>";
        echo "<td>" . $admin['email'] . "</td>";
        echo "<td>" . $admin['role_id'] . "</td>";
        echo "<td>" . (strlen($admin['password']) > 20 ? "Com hash (segura)" : "Sem hash (texto plano)") . "</td>";
        echo "</tr>";
        echo "</table>";
        
        // Opção para redefinir a senha do admin
        echo "<h3>Redefinir senha do admin</h3>";
        echo "<form method='post'>";
        echo "<input type='hidden' name='action' value='reset_password'>";
        echo "<p>Escolha uma opção:</p>";
        echo "<label><input type='radio' name='password_type' value='plain' checked> Senha em texto plano (admin123)</label><br>";
        echo "<label><input type='radio' name='password_type' value='hash'> Senha com hash (admin123)</label><br><br>";
        echo "<button type='submit'>Redefinir Senha</button>";
        echo "</form>";
        
        // Processar redefinição de senha
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reset_password') {
            $password_type = $_POST['password_type'] ?? 'plain';
            
            if ($password_type === 'plain') {
                // Senha em texto plano
                $password = 'admin123';
                $sql = "UPDATE users SET password = ? WHERE username = 'admin'";
            } else {
                // Senha com hash
                $password = password_hash('admin123', PASSWORD_DEFAULT);
                $sql = "UPDATE users SET password = ? WHERE username = 'admin'";
            }
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $password);
            
            if ($stmt->execute()) {
                echo "<p style='color: green;'>✅ Senha do usuário admin redefinida com sucesso!</p>";
                echo "<p>Nova senha: <strong>admin123</strong></p>";
            } else {
                echo "<p style='color: red;'>❌ Erro ao redefinir senha: " . $stmt->error . "</p>";
            }
        }
    } else {
        // Formulário para adicionar usuário admin
        echo "<h2>Adicionar novo usuário admin</h2>";
        echo "<form method='post'>";
        echo "<input type='hidden' name='action' value='add_user'>";
        echo "<p>Escolha uma opção:</p>";
        echo "<label><input type='radio' name='password_type' value='plain' checked> Senha em texto plano (admin123)</label><br>";
        echo "<label><input type='radio' name='password_type' value='hash'> Senha com hash (admin123)</label><br><br>";
        echo "<button type='submit'>Adicionar Usuário Admin</button>";
        echo "</form>";
        
        // Processar adição de usuário
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_user') {
            $password_type = $_POST['password_type'] ?? 'plain';
            
            if ($password_type === 'plain') {
                // Senha em texto plano
                $password = 'admin123';
            } else {
                // Senha com hash
                $password = password_hash('admin123', PASSWORD_DEFAULT);
            }
            
            $username = 'admin';
            $name = 'Administrador';
            $email = 'admin@exemplo.com';
            $role_id = 3; // Admin
            $active = 1;
            $created_at = date('Y-m-d H:i:s');
            
            $sql = "INSERT INTO users (username, password, name, email, role_id, active, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssiis", $username, $password, $name, $email, $role_id, $active, $created_at);
            
            if ($stmt->execute()) {
                echo "<p style='color: green;'>✅ Usuário admin adicionado com sucesso!</p>";
                echo "<p>Username: <strong>admin</strong></p>";
                echo "<p>Senha: <strong>admin123</strong></p>";
            } else {
                echo "<p style='color: red;'>❌ Erro ao adicionar usuário: " . $stmt->error . "</p>";
            }
        }
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Erro: " . $e->getMessage() . "</p>";
}
?>

<h2>Próximos Passos</h2>
<p>Acesse os links abaixo para continuar a resolução do problema:</p>
<ul>
    <li><a href="test_connection.php">Voltar para o teste de conexão</a></li>
    <li><a href="login.php">Voltar para a página de login</a></li>
</ul>
