<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Adicionar novo paciente
        if ($_POST['action'] === 'add') {
            $cns = $_POST['cns'];
            $name = $_POST['name'];
            $birth_date = $_POST['birth_date'];
            $sex = $_POST['sex'];
            $race = $_POST['race'] ?? null;
            $ethnicity = $_POST['ethnicity'] ?? null;
            $nationality = $_POST['nationality'] ?? null;
            $ibge_code = $_POST['ibge_code'] ?? null;
            $cep = $_POST['cep'] ?? null;
            $address_type = $_POST['address_type'] ?? null;
            $address = $_POST['address'] ?? null;
            $address_number = $_POST['address_number'] ?? null;
            $address_complement = $_POST['address_complement'] ?? null;
            $neighborhood = $_POST['neighborhood'] ?? null;
            $phone = $_POST['phone'] ?? null;
            $email = $_POST['email'] ?? null;
            
            // Verificar se já existe um paciente com este CNS
            $check = $conn->prepare("SELECT id FROM patients WHERE cns = ?");
            $check->bind_param("s", $cns);
            $check->execute();
            $result = $check->get_result();
            
            if ($result->num_rows > 0) {
                $error = "Já existe um paciente com o CNS $cns.";
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO patients (
                        cns, name, birth_date, sex, race, ethnicity, nationality, 
                        ibge_code, cep, address_type, address, address_number, 
                        address_complement, neighborhood, phone, email
                    ) VALUES (
                        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                    )
                ");
                $stmt->bind_param(
                    "ssssssssssssssss",
                    $cns, $name, $birth_date, $sex, $race, $ethnicity, $nationality,
                    $ibge_code, $cep, $address_type, $address, $address_number,
                    $address_complement, $neighborhood, $phone, $email
                );
                
                if ($stmt->execute()) {
                    $message = "Paciente adicionado com sucesso.";
                } else {
                    $error = "Erro ao adicionar paciente: " . $conn->error;
                }
                $stmt->close();
            }
        }
        // Editar paciente
        else if ($_POST['action'] === 'edit' && isset($_POST['id'])) {
            $id = $_POST['id'];
            $cns = $_POST['cns'];
            $name = $_POST['name'];
            $birth_date = $_POST['birth_date'];
            $sex = $_POST['sex'];
            $race = $_POST['race'] ?? null;
            $ethnicity = $_POST['ethnicity'] ?? null;
            $nationality = $_POST['nationality'] ?? null;
            $ibge_code = $_POST['ibge_code'] ?? null;
            $cep = $_POST['cep'] ?? null;
            $address_type = $_POST['address_type'] ?? null;
            $address = $_POST['address'] ?? null;
            $address_number = $_POST['address_number'] ?? null;
            $address_complement = $_POST['address_complement'] ?? null;
            $neighborhood = $_POST['neighborhood'] ?? null;
            $phone = $_POST['phone'] ?? null;
            $email = $_POST['email'] ?? null;
            
            // Verificar se já existe outro paciente com este CNS
            $check = $conn->prepare("SELECT id FROM patients WHERE cns = ? AND id != ?");
            $check->bind_param("si", $cns, $id);
            $check->execute();
            $result = $check->get_result();
            
            if ($result->num_rows > 0) {
                $error = "Já existe outro paciente com o CNS $cns.";
            } else {
                $stmt = $conn->prepare("
                    UPDATE patients 
                    SET cns = ?, name = ?, birth_date = ?, sex = ?, race = ?, 
                        ethnicity = ?, nationality = ?, ibge_code = ?, cep = ?, 
                        address_type = ?, address = ?, address_number = ?, 
                        address_complement = ?, neighborhood = ?, phone = ?, email = ?
                    WHERE id = ?
                ");
                $stmt->bind_param(
                    "ssssssssssssssssi",
                    $cns, $name, $birth_date, $sex, $race, $ethnicity, $nationality,
                    $ibge_code, $cep, $address_type, $address, $address_number,
                    $address_complement, $neighborhood, $phone, $email, $id
                );
                
                if ($stmt->execute()) {
                    $message = "Paciente atualizado com sucesso.";
                } else {
                    $error = "Erro ao atualizar paciente: " . $conn->error;
                }
                $stmt->close();
            }
        }
        // Excluir paciente
        else if ($_POST['action'] === 'delete' && isset($_POST['id'])) {
            $id = $_POST['id'];
            
            // Verificar se o paciente está em alguma viagem
            $check = $conn->prepare("SELECT COUNT(*) as count FROM trip_passengers WHERE patient_id = ?");
            $check->bind_param("i", $id);
            $check->execute();
            $result = $check->get_result();
            $count = $result->fetch_assoc()['count'];
            
            if ($count > 0) {
                $error = "Não é possível excluir este paciente pois ele está associado a viagens.";
            } else {
                $stmt = $conn->prepare("DELETE FROM patients WHERE id = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $message = "Paciente excluído com sucesso.";
                } else {
                    $error = "Erro ao excluir paciente: " . $conn->error;
                }
                $stmt->close();
            }
        }
        // Importar do ESUS
        else if ($_POST['action'] === 'import_esus' && isset($_POST['cns'])) {
            $cns = $_POST['cns'];
            
            // Verificar se já existe um paciente com este CNS
            $check = $conn->prepare("SELECT id FROM patients WHERE cns = ?");
            $check->bind_param("s", $cns);
            $check->execute();
            $result = $check->get_result();
            
            if ($result->num_rows > 0) {
                $error = "Já existe um paciente com o CNS $cns.";
            } else {
                // Buscar paciente no ESUS
                $patient_data = fetchPatientFromESUS($cns);
                
                if ($patient_data) {
                    $stmt = $conn->prepare("
                        INSERT INTO patients (
                            cns, name, birth_date, sex, race, ethnicity, nationality, 
                            ibge_code, cep, address_type, address, address_number, 
                            address_complement, neighborhood, phone, email
                        ) VALUES (
                            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                        )
                    ");
                    $stmt->bind_param(
                        "ssssssssssssssss",
                        $cns, $patient_data['name'], $patient_data['birth_date'], $patient_data['sex'], 
                        $patient_data['race'], $patient_data['ethnicity'], $patient_data['nationality'],
                        $patient_data['ibge_code'], $patient_data['cep'], $patient_data['address_type'], 
                        $patient_data['address'], $patient_data['address_number'],
                        $patient_data['address_complement'], $patient_data['neighborhood'], 
                        $patient_data['phone'], $patient_data['email']
                    );
                    
                    if ($stmt->execute()) {
                        $message = "Paciente importado do ESUS com sucesso.";
                    } else {
                        $error = "Erro ao importar paciente: " . $conn->error;
                    }
                    $stmt->close();
                } else {
                    $error = "Paciente não encontrado no ESUS PEC.";
                }
            }
        }
    }
}

// Definir ação
$action = $_GET['action'] ?? 'list';
$patient_id = $_GET['id'] ?? null;

// Obter dados para formulários
if ($action === 'edit' && $patient_id) {
    $stmt = $conn->prepare("SELECT * FROM patients WHERE id = ?");
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
    $patient = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$patient) {
        $error = "Paciente não encontrado.";
        $action = 'list';
    }
}

// Listar pacientes
if ($action === 'list') {
    $result = $conn->query("SELECT * FROM patients ORDER BY name");
    $patients = $result->fetch_all(MYSQLI_ASSOC);
}

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <?php if ($action === 'add'): ?>
            <i class="fas fa-user-plus me-2"></i>Novo Paciente
        <?php elseif ($action === 'edit'): ?>
            <i class="fas fa-user-edit me-2"></i>Editar Paciente
        <?php else: ?>
            <i class="fas fa-users me-2"></i>Gerenciamento de Pacientes
        <?php endif; ?>
    </h1>
    
    <?php if ($action === 'list'): ?>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="?action=add" class="btn btn-sm btn-success">
                    <i class="fas fa-plus me-1"></i> Novo Paciente
                </a>
                <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#importEsusModal">
                    <i class="fas fa-download me-1"></i> Importar do ESUS
                </button>
            </div>
        </div>
    <?php else: ?>
        <a href="patients.php" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    <?php endif; ?>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($action === 'add' || $action === 'edit'): ?>
    <!-- Formulário de Paciente -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <?= $action === 'add' ? 'Novo Paciente' : 'Editar Paciente' ?>
            </h6>
        </div>
        <div class="card-body">
            <form method="post">
                <input type="hidden" name="action" value="<?= $action ?>">
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="id" value="<?= $patient_id ?>">
                <?php endif; ?>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Nome Completo</label>
                        <input type="text" class="form-control" id="name" name="name" required
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['name']) : '' ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="cns" class="form-label">CNS (Cartão Nacional de Saúde)</label>
                        <input type="text" class="form-control" id="cns" name="cns" required
                               pattern="[0-9]{15}" maxlength="15" placeholder="15 dígitos"
                               value="<?= $action === 'edit' ? $patient['cns'] : '' ?>">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="birth_date" class="form-label">Data de Nascimento</label>
                        <input type="date" class="form-control" id="birth_date" name="birth_date" required
                               value="<?= $action === 'edit' ? $patient['birth_date'] : '' ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="sex" class="form-label">Sexo</label>
                        <select class="form-select" id="sex" name="sex" required>
                            <option value="">Selecione...</option>
                            <option value="M" <?= ($action === 'edit' && $patient['sex'] === 'M') ? 'selected' : '' ?>>Masculino</option>
                            <option value="F" <?= ($action === 'edit' && $patient['sex'] === 'F') ? 'selected' : '' ?>>Feminino</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="race" class="form-label">Raça/Cor</label>
                        <select class="form-select" id="race" name="race">
                            <option value="">Selecione...</option>
                            <option value="01" <?= ($action === 'edit' && $patient['race'] === '01') ? 'selected' : '' ?>>Branca</option>
                            <option value="02" <?= ($action === 'edit' && $patient['race'] === '02') ? 'selected' : '' ?>>Preta</option>
                            <option value="03" <?= ($action === 'edit' && $patient['race'] === '03') ? 'selected' : '' ?>>Parda</option>
                            <option value="04" <?= ($action === 'edit' && $patient['race'] === '04') ? 'selected' : '' ?>>Amarela</option>
                            <option value="05" <?= ($action === 'edit' && $patient['race'] === '05') ? 'selected' : '' ?>>Indígena</option>
                            <option value="99" <?= ($action === 'edit' && $patient['race'] === '99') ? 'selected' : '' ?>>Sem informação</option>
                        </select>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="ethnicity" class="form-label">Etnia</label>
                        <input type="text" class="form-control" id="ethnicity" name="ethnicity" maxlength="4"
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['ethnicity'] ?? '') : '' ?>">
                        <div class="form-text">Preencher apenas se raça/cor for Indígena</div>
                    </div>
                    <div class="col-md-4">
                        <label for="nationality" class="form-label">Nacionalidade</label>
                        <input type="text" class="form-control" id="nationality" name="nationality" maxlength="3"
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['nationality'] ?? '') : '' ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="ibge_code" class="form-label">Código IBGE do Município</label>
                        <input type="text" class="form-control" id="ibge_code" name="ibge_code" maxlength="6"
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['ibge_code'] ?? '') : '' ?>">
                    </div>
                </div>
                
                <h5 class="mt-4 mb-3">Endereço</h5>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="cep" class="form-label">CEP</label>
                        <input type="text" class="form-control" id="cep" name="cep" maxlength="8"
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['cep'] ?? '') : '' ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="address_type" class="form-label">Tipo de Logradouro</label>
                        <input type="text" class="form-control" id="address_type" name="address_type" maxlength="3"
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['address_type'] ?? '') : '' ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="address" class="form-label">Logradouro</label>
                        <input type="text" class="form-control" id="address" name="address" maxlength="30"
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['address'] ?? '') : '' ?>">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="address_number" class="form-label">Número</label>
                        <input type="text" class="form-control" id="address_number" name="address_number" maxlength="5"
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['address_number'] ?? '') : '' ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="address_complement" class="form-label">Complemento</label>
                        <input type="text" class="form-control" id="address_complement" name="address_complement" maxlength="10"
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['address_complement'] ?? '') : '' ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="neighborhood" class="form-label">Bairro</label>
                        <input type="text" class="form-control" id="neighborhood" name="neighborhood" maxlength="30"
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['neighborhood'] ?? '') : '' ?>">
                    </div>
                </div>
                
                <h5 class="mt-4 mb-3">Contato</h5>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="phone" class="form-label">Telefone</label>
                        <input type="text" class="form-control" id="phone" name="phone" maxlength="11"
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['phone'] ?? '') : '' ?>">
                        <div class="form-text">Apenas números, com DDD</div>
                    </div>
                    <div class="col-md-6">
                        <label for="email" class="form-label">E-mail</label>
                        <input type="email" class="form-control" id="email" name="email" maxlength="40"
                               value="<?= $action === 'edit' ? htmlspecialchars($patient['email'] ?? '') : '' ?>">
                    </div>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <a href="patients.php" class="btn btn-secondary me-md-2">Cancelar</a>
                    <button type="submit" class="btn btn-primary">
                        <?= $action === 'add' ? 'Adicionar Paciente' : 'Salvar Alterações' ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php else: ?>
    <!-- Lista de Pacientes -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Pacientes</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered datatable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>CNS</th>
                            <th>Data de Nascimento</th>
                            <th>Sexo</th>
                            <th>Telefone</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($patients as $patient): ?>
                            <tr>
                                <td><?= $patient['id'] ?></td>
                                <td><?= htmlspecialchars($patient['name']) ?></td>
                                <td><?= $patient['cns'] ?></td>
                                <td><?= date('d/m/Y', strtotime($patient['birth_date'])) ?></td>
                                <td><?= $patient['sex'] === 'M' ? 'Masculino' : 'Feminino' ?></td>
                                <td><?= htmlspecialchars($patient['phone'] ?? '-') ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="?action=edit&id=<?= $patient['id'] ?>" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="Editar">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        
                                        <form method="post" class="d-inline">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?= $patient['id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger btn-delete" data-bs-toggle="tooltip" title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Modal para importar do ESUS -->
    <div class="modal fade" id="importEsusModal" tabindex="-1" aria-labelledby="importEsusModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post">
                    <input type="hidden" name="action" value="import_esus">
                    
                    <div class="modal-header">
                        <h5 class="modal-title" id="importEsusModalLabel">Importar Paciente do ESUS</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="cns" class="form-label">CNS do Paciente</label>
                            <input type="text" class="form-control" id="cns" name="cns" required
                                   pattern="[0-9]{15}" maxlength="15" placeholder="15 dígitos">
                            <div class="form-text">Digite o CNS do paciente para buscar no ESUS PEC</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Importar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
