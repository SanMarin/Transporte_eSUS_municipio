<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Adicionar novo cabeçalho
        if ($_POST['action'] === 'add') {
            $cbc_mvm = $_POST['cbc_mvm'];
            
            // Verificar se já existe um cabeçalho para esta competência
            $check = $conn->prepare("SELECT id FROM bpa_headers WHERE cbc_mvm = ?");
            $check->bind_param("s", $cbc_mvm);
            $check->execute();
            $result = $check->get_result();
            
            if ($result->num_rows > 0) {
                $error = "Já existe um cabeçalho para a competência $cbc_mvm.";
            } else {
                $stmt = $conn->prepare("INSERT INTO bpa_headers (cbc_mvm, status) VALUES (?, 'draft')");
                $stmt->bind_param("s", $cbc_mvm);
                
                if ($stmt->execute()) {
                    $message = "Cabeçalho para competência $cbc_mvm adicionado com sucesso.";
                } else {
                    $error = "Erro ao adicionar cabeçalho: " . $conn->error;
                }
                $stmt->close();
            }
        }
        // Excluir cabeçalho
        else if ($_POST['action'] === 'delete' && isset($_POST['id'])) {
            $id = $_POST['id'];
            
            // Verificar se existem registros BPA vinculados
            $check = $conn->prepare("SELECT COUNT(*) as count FROM bpa_records WHERE header_id = ?");
            $check->bind_param("i", $id);
            $check->execute();
            $result = $check->get_result();
            $count = $result->fetch_assoc()['count'];
            
            if ($count > 0) {
                $error = "Não é possível excluir este cabeçalho pois existem registros BPA vinculados a ele.";
            } else {
                $stmt = $conn->prepare("DELETE FROM bpa_headers WHERE id = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $message = "Cabeçalho excluído com sucesso.";
                } else {
                    $error = "Erro ao excluir cabeçalho: " . $conn->error;
                }
                $stmt->close();
            }
        }
        // Finalizar cabeçalho
        else if ($_POST['action'] === 'finalize' && isset($_POST['id'])) {
            $id = $_POST['id'];
            
            // Atualizar contadores
            $stmt = $conn->prepare("
                UPDATE bpa_headers 
                SET 
                    cbc_lin = (SELECT COUNT(*) FROM bpa_records WHERE header_id = ?),
                    cbc_flh = CEILING((SELECT COUNT(*) FROM bpa_records WHERE header_id = ?) / 20),
                    status = 'finalized'
                WHERE id = ?
            ");
            $stmt->bind_param("iii", $id, $id, $id);
            
            if ($stmt->execute()) {
                $message = "Cabeçalho finalizado com sucesso.";
            } else {
                $error = "Erro ao finalizar cabeçalho: " . $conn->error;
            }
            $stmt->close();
        }
    }
}

// Obter lista de cabeçalhos
$result = $conn->query("
    SELECT h.*, 
           (SELECT COUNT(*) FROM bpa_records WHERE header_id = h.id) as record_count
    FROM bpa_headers h
    ORDER BY h.cbc_mvm DESC
");
$headers = $result->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-file-medical me-2"></i>Gerenciamento de Cabeçalho BPA</h1>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addHeaderModal">
        <i class="fas fa-plus me-1"></i> Novo Cabeçalho
    </button>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Cabeçalhos BPA</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered datatable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Competência</th>
                        <th>Registros</th>
                        <th>Folhas</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($headers as $header): ?>
                        <tr>
                            <td><?= $header['id'] ?></td>
                            <td>
                                <?= substr($header['cbc_mvm'], 0, 4) ?>/<?= substr($header['cbc_mvm'], 4, 2) ?>
                            </td>
                            <td><?= $header['record_count'] ?></td>
                            <td><?= $header['cbc_flh'] ?></td>
                            <td>
                                <?php if ($header['status'] === 'draft'): ?>
                                    <span class="badge bg-warning">Rascunho</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Finalizado</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="bpa_records.php?header_id=<?= $header['id'] ?>" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Ver Registros">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    
                                    <?php if ($header['status'] === 'draft'): ?>
                                        <form method="post" class="d-inline">
                                            <input type="hidden" name="action" value="finalize">
                                            <input type="hidden" name="id" value="<?= $header['id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-success" data-bs-toggle="tooltip" title="Finalizar">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        </form>
                                        
                                        <form method="post" class="d-inline">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?= $header['id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger btn-delete" data-bs-toggle="tooltip" title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <a href="bpa_generate.php?download=<?= $header['id'] ?>" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="Baixar Arquivo BPA">
                                            <i class="fas fa-download"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal para adicionar cabeçalho -->
<div class="modal fade" id="addHeaderModal" tabindex="-1" aria-labelledby="addHeaderModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <input type="hidden" name="action" value="add">
                <div class="modal-header">
                    <h5 class="modal-title" id="addHeaderModalLabel">Novo Cabeçalho BPA</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="cbc_mvm" class="form-label">Competência (AAAAMM)</label>
                        <input type="text" class="form-control" id="cbc_mvm" name="cbc_mvm" required 
                               pattern="[0-9]{6}" placeholder="AAAAMM" maxlength="6">
                        <div class="form-text">Exemplo: 202305 para Maio de 2023</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Adicionar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
