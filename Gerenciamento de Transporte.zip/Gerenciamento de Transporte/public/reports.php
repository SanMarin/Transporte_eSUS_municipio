<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';
?>

<!-- Print-specific styles -->
<style media="print">
    /* Hide navigation, buttons, and other UI elements when printing */
    .navbar, .sidebar, .card-header button, .btn, form, .pagination,
    .no-print, footer, .nav, .nav-tabs, .tab-content > .tab-pane:not(.active) {
        display: none !important;
    }
    
    /* Make sure the content takes full width */
    main, .col-md-9, .col-lg-10, .card, .card-body, .table-responsive {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }
    
    /* Remove shadows and borders for cleaner print */
    .card, .shadow {
        box-shadow: none !important;
        border: none !important;
    }
    
    /* Ensure tables print properly */
    table {
        width: 100% !important;
        page-break-inside: auto !important;
    }
    
    tr {
        page-break-inside: avoid !important;
        page-break-after: auto !important;
    }
    
    /* Add a header with the report title on each printed page */
    @page {
        margin: 1cm;
    }
    
    /* Make text smaller to fit more on a page */
    body {
        font-size: 10pt !important;
    }
    
    /* Ensure background colors print */
    .bg-primary, .bg-success, .bg-info, .bg-warning {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }
    
    /* Make sure badges are visible */
    .badge {
        border: 1px solid #000 !important;
        color: #000 !important;
    }
}
</style>

<?php

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Definir filtros padrão
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');
$location_id = $_GET['location_id'] ?? '';
$driver_id = $_GET['driver_id'] ?? '';
$status = $_GET['status'] ?? '';

// Obter dados para filtros
$locations = $conn->query("SELECT id, name, city, state FROM locations WHERE active = 1 ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$drivers = $conn->query("SELECT id, name FROM drivers WHERE active = 1 ORDER BY name")->fetch_all(MYSQLI_ASSOC);

// Definir relatório
$report_type = $_GET['report'] ?? 'trips';

// Gerar relatório de viagens
if ($report_type === 'trips') {
    $query = "
    SELECT 
        t.id, 
        t.trip_date, 
        t.status,
        l.name AS location_name, 
        l.city AS location_city, 
        l.state AS location_state,
        d.name AS driver_name,
        v.plate AS vehicle_plate,
        v.model AS vehicle_model,
        p.name AS professional_name,
        (SELECT COUNT(*) FROM trip_passengers WHERE trip_id = t.id) AS passenger_count,
        (SELECT COUNT(*) FROM bpa_records WHERE trip_passenger_id IN (SELECT id FROM trip_passengers WHERE trip_id = t.id)) AS bpa_records_count
    FROM 
        trips t
        LEFT JOIN locations l ON t.location_id = l.id
        LEFT JOIN drivers d ON t.driver_id = d.id
        LEFT JOIN vehicles v ON t.vehicle_id = v.id
        LEFT JOIN professionals p ON t.professional_id = p.id
    WHERE 
        t.trip_date BETWEEN ? AND ?
";
    
    $params = [$start_date, $end_date];
    $types = "ss";
    
    if (!empty($location_id)) {
        $query .= " AND t.location_id = ?";
        $params[] = $location_id;
        $types .= "i";
    }
    
    if (!empty($driver_id)) {
        $query .= " AND t.driver_id = ?";
        $params[] = $driver_id;
        $types .= "i";
    }
    
    if (!empty($status)) {
        $query .= " AND t.status = ?";
        $params[] = $status;
        $types .= "s";
    }
    
    $query .= " ORDER BY t.trip_date DESC, t.id DESC";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $trips = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    // Calcular totais
    $total_trips = count($trips);
    $total_passengers = array_sum(array_column($trips, 'passenger_count'));
    $total_bpa_records = array_sum(array_column($trips, 'bpa_records_count'));
    
    // Agrupar por status
    $status_counts = [];
    foreach ($trips as $trip) {
        $status_counts[$trip['status']] = ($status_counts[$trip['status']] ?? 0) + 1;
    }
}

// Gerar relatório de BPA
else if ($report_type === 'bpa') {
    $competence = $_GET['competence'] ?? date('Y-m');
    
    $query = "
    SELECT 
        b.id,
        b.prd_pa as procedure_code,
        p.description as procedure_description,
        b.prd_cnspac as patient_cns,
        b.prd_nmpac as patient_name,
        b.prd_dtnasc as patient_birth_date,
        b.prd_sexo as patient_gender,
        b.prd_dtaten as service_date,
        t.trip_date,
        l.name AS location_name,
        l.city AS location_city,
        l.state AS location_state
    FROM 
        bpa_records b
        LEFT JOIN trip_passengers tp ON b.trip_passenger_id = tp.id
        LEFT JOIN trips t ON tp.trip_id = t.id
        LEFT JOIN locations l ON t.location_id = l.id
        LEFT JOIN procedures p ON b.prd_pa = p.code
    WHERE 
        DATE_FORMAT(b.prd_dtaten, '%Y-%m') = ?
    ORDER BY 
        b.prd_dtaten DESC, b.id DESC
";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $competence);
    $stmt->execute();
    $bpa_records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    // Calcular totais
    $total_bpa_records = count($bpa_records);
    
    // Agrupar por procedimento
    $procedure_counts = [];
    foreach ($bpa_records as $record) {
        $procedure_counts[$record['procedure_code']] = ($procedure_counts[$record['procedure_code']] ?? 0) + 1;
    }
}

// Gerar relatório de pacientes
else if ($report_type === 'patients') {
    $query = "
    SELECT 
        p.id,
        p.name,
        p.cns,
        p.birth_date,
        p.sex,
        IFNULL(p.address, 'N/A') as city,
        IFNULL(p.neighborhood, 'N/A') as state,
        (SELECT COUNT(*) FROM trip_passengers tp WHERE tp.patient_id = p.id) AS trip_count,
        (SELECT COUNT(*) FROM bpa_records b WHERE b.prd_cnspac = p.cns) AS bpa_records_count
    FROM 
        patients p
    ORDER BY 
        p.name
";
    
    $result = $conn->query($query);
    $patients = $result->fetch_all(MYSQLI_ASSOC);
    
    // Calcular totais
    $total_patients = count($patients);
    $total_trips = array_sum(array_column($patients, 'trip_count'));
    $total_bpa_records = array_sum(array_column($patients, 'bpa_records_count'));
}

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <i class="fas fa-chart-bar me-2"></i>Relatórios
    </h1>
</div>

<!-- Seleção de Relatório -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Selecione o Relatório</h6>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="card h-100 <?= $report_type === 'trips' ? 'border-primary' : '' ?>">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="fas fa-route me-2"></i>Relatório de Viagens
                        </h5>
                        <p class="card-text">Visualize todas as viagens realizadas em um período, com filtros por local, motorista e status.</p>
                        <a href="?report=trips" class="btn btn-sm <?= $report_type === 'trips' ? 'btn-primary' : 'btn-outline-primary' ?>">Selecionar</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card h-100 <?= $report_type === 'bpa' ? 'border-primary' : '' ?>">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="fas fa-file-medical me-2"></i>Relatório de BPA
                        </h5>
                        <p class="card-text">Visualize todos os registros BPA gerados por competência, agrupados por procedimento.</p>
                        <a href="?report=bpa" class="btn btn-sm <?= $report_type === 'bpa' ? 'btn-primary' : 'btn-outline-primary' ?>">Selecionar</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card h-100 <?= $report_type === 'patients' ? 'border-primary' : '' ?>">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="fas fa-users me-2"></i>Relatório de Pacientes
                        </h5>
                        <p class="card-text">Visualize todos os pacientes cadastrados e suas estatísticas de viagens e procedimentos.</p>
                        <a href="?report=patients" class="btn btn-sm <?= $report_type === 'patients' ? 'btn-primary' : 'btn-outline-primary' ?>">Selecionar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if ($report_type === 'trips'): ?>
<!-- Relatório de Viagens -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-primary">Relatório de Viagens</h6>
        <button class="btn btn-sm btn-outline-primary" onclick="window.print()">
            <i class="fas fa-print me-1"></i> Imprimir
        </button>
    </div>
    <div class="card-body">
        <!-- Filtros -->
        <form method="get" class="mb-4">
            <input type="hidden" name="report" value="trips">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="start_date" class="form-label">Data Inicial</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" value="<?= $start_date ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label">Data Final</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" value="<?= $end_date ?>">
                </div>
                <div class="col-md-3">
                    <label for="location_id" class="form-label">Local</label>
                    <select class="form-select" id="location_id" name="location_id">
                        <option value="">Todos</option>
                        <?php foreach ($locations as $loc): ?>
                            <option value="<?= $loc['id'] ?>" <?= $location_id == $loc['id'] ? 'selected' : '' ?>>
                                <?= $loc['name'] ?> - <?= $loc['city'] ?>/<?= $loc['state'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="driver_id" class="form-label">Motorista</label>
                    <select class="form-select" id="driver_id" name="driver_id">
                        <option value="">Todos</option>
                        <?php foreach ($drivers as $drv): ?>
                            <option value="<?= $drv['id'] ?>" <?= $driver_id == $drv['id'] ? 'selected' : '' ?>>
                                <?= $drv['name'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status">
                        <option value="">Todos</option>
                        <option value="scheduled" <?= $status === 'scheduled' ? 'selected' : '' ?>>Agendada</option>
                        <option value="in_progress" <?= $status === 'in_progress' ? 'selected' : '' ?>>Em Andamento</option>
                        <option value="completed" <?= $status === 'completed' ? 'selected' : '' ?>>Concluída</option>
                        <option value="canceled" <?= $status === 'canceled' ? 'selected' : '' ?>>Cancelada</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-1"></i> Filtrar
                    </button>
                    <a href="?report=trips" class="btn btn-outline-secondary ms-2">
                        <i class="fas fa-undo me-1"></i> Limpar
                    </a>
                </div>
            </div>
        </form>
        
        <!-- Resumo -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card bg-primary text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white">Total de Viagens</h6>
                                <h2 class="mb-0"><?= $total_trips ?></h2>
                            </div>
                            <i class="fas fa-route fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card bg-success text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white">Total de Passageiros</h6>
                                <h2 class="mb-0"><?= $total_passengers ?></h2>
                            </div>
                            <i class="fas fa-users fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card bg-info text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white">Registros BPA</h6>
                                <h2 class="mb-0"><?= $total_bpa_records ?></h2>
                            </div>
                            <i class="fas fa-file-medical fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card bg-warning text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white">Média de Passageiros</h6>
                                <h2 class="mb-0"><?= $total_trips > 0 ? number_format($total_passengers / $total_trips, 1) : '0.0' ?></h2>
                            </div>
                            <i class="fas fa-calculator fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Status das Viagens -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Status das Viagens</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Agendadas</h5>
                                        <h3 class="text-primary"><?= $status_counts['scheduled'] ?? 0 ?></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Em Andamento</h5>
                                        <h3 class="text-warning"><?= $status_counts['in_progress'] ?? 0 ?></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Concluídas</h5>
                                        <h3 class="text-success"><?= $status_counts['completed'] ?? 0 ?></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Canceladas</h5>
                                        <h3 class="text-danger"><?= $status_counts['canceled'] ?? 0 ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tabela de Viagens -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Data</th>
                        <th>Destino</th>
                        <th>Motorista</th>
                        <th>Veículo</th>
                        <th>Profissional</th>
                        <th>Passageiros</th>
                        <th>Registros BPA</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($trips)): ?>
                        <tr>
                            <td colspan="9" class="text-center">Nenhuma viagem encontrada com os filtros selecionados.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($trips as $trip): ?>
                            <tr>
                                <td><?= $trip['id'] ?></td>
                                <td><?= date('d/m/Y', strtotime($trip['trip_date'])) ?></td>
                                <td><?= $trip['location_name'] ?> - <?= $trip['location_city'] ?>/<?= $trip['location_state'] ?></td>
                                <td><?= $trip['driver_name'] ?></td>
                                <td><?= $trip['vehicle_plate'] ?> - <?= $trip['vehicle_model'] ?></td>
                                <td><?= $trip['professional_name'] ?></td>
                                <td><?= $trip['passenger_count'] ?></td>
                                <td><?= $trip['bpa_records_count'] ?></td>
                                <td>
                                    <?php if ($trip['status'] === 'scheduled'): ?>
                                        <span class="badge bg-primary">Agendada</span>
                                    <?php elseif ($trip['status'] === 'in_progress'): ?>
                                        <span class="badge bg-warning">Em Andamento</span>
                                    <?php elseif ($trip['status'] === 'completed'): ?>
                                        <span class="badge bg-success">Concluída</span>
                                    <?php elseif ($trip['status'] === 'canceled'): ?>
                                        <span class="badge bg-danger">Cancelada</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php elseif ($report_type === 'bpa'): ?>
<!-- Relatório de BPA -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-primary">Relatório de BPA</h6>
        <button class="btn btn-sm btn-outline-primary" onclick="window.print()">
            <i class="fas fa-print me-1"></i> Imprimir
        </button>
    </div>
    <div class="card-body">
        <!-- Filtros -->
        <form method="get" class="mb-4">
            <input type="hidden" name="report" value="bpa">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="competence" class="form-label">Competência</label>
                    <input type="month" class="form-control" id="competence" name="competence" value="<?= $competence ?>">
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-1"></i> Filtrar
                    </button>
                    <a href="?report=bpa" class="btn btn-outline-secondary ms-2">
                        <i class="fas fa-undo me-1"></i> Limpar
                    </a>
                </div>
            </div>
        </form>
        
        <!-- Resumo -->
        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <div class="card bg-primary text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white">Total de Registros BPA</h6>
                                <h2 class="mb-0"><?= $total_bpa_records ?></h2>
                            </div>
                            <i class="fas fa-file-medical fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card bg-success text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white">Transporte (0803010125)</h6>
                                <h2 class="mb-0"><?= $procedure_counts['0803010125'] ?? 0 ?></h2>
                            </div>
                            <i class="fas fa-bus fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card bg-info text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white">Alimentação (0803010028)</h6>
                                <h2 class="mb-0"><?= $procedure_counts['0803010028'] ?? 0 ?></h2>
                            </div>
                            <i class="fas fa-utensils fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tabela de Registros BPA -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Data Atendimento</th>
                        <th>Procedimento</th>
                        <th>CNS Paciente</th>
                        <th>Nome Paciente</th>
                        <th>Data Nascimento</th>
                        <th>Sexo</th>
                        <th>Destino</th>
                        <th>Data Viagem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($bpa_records)): ?>
                        <tr>
                            <td colspan="9" class="text-center">Nenhum registro BPA encontrado para a competência selecionada.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($bpa_records as $record): ?>
                            <tr>
                                <td><?= $record['id'] ?></td>
                                <td><?= date('d/m/Y', strtotime($record['service_date'])) ?></td>
                                <td>
                                    <?= $record['procedure_code'] ?> - 
                                    <?= $record['procedure_description'] ?>
                                </td>
                                <td><?= $record['patient_cns'] ?></td>
                                <td><?= $record['patient_name'] ?></td>
                                <td><?= date('d/m/Y', strtotime($record['patient_birth_date'])) ?></td>
                                <td><?= $record['patient_gender'] === 'M' ? 'Masculino' : 'Feminino' ?></td>
                                <td><?= $record['location_name'] ?> - <?= $record['location_city'] ?>/<?= $record['location_state'] ?></td>
                                <td><?= date('d/m/Y', strtotime($record['trip_date'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php elseif ($report_type === 'patients'): ?>
<!-- Relatório de Pacientes -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-primary">Relatório de Pacientes</h6>
        <button class="btn btn-sm btn-outline-primary" onclick="window.print()">
            <i class="fas fa-print me-1"></i> Imprimir
        </button>
    </div>
    <div class="card-body">
        <!-- Resumo -->
        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <div class="card bg-primary text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white">Total de Pacientes</h6>
                                <h2 class="mb-0"><?= $total_patients ?></h2>
                            </div>
                            <i class="fas fa-users fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card bg-success text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white">Total de Viagens</h6>
                                <h2 class="mb-0"><?= $total_trips ?></h2>
                            </div>
                            <i class="fas fa-route fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card bg-info text-white h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white">Total de Registros BPA</h6>
                                <h2 class="mb-0"><?= $total_bpa_records ?></h2>
                            </div>
                            <i class="fas fa-file-medical fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tabela de Pacientes -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>CNS</th>
                        <th>Data Nascimento</th>
                        <th>Sexo</th>
                        <th>Cidade/UF</th>
                        <th>Viagens</th>
                        <th>Registros BPA</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($patients)): ?>
                        <tr>
                            <td colspan="8" class="text-center">Nenhum paciente cadastrado.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($patients as $patient): ?>
                            <tr>
                                <td><?= $patient['id'] ?></td>
                                <td><?= $patient['name'] ?></td>
                                <td><?= $patient['cns'] ?></td>
                                <td><?= date('d/m/Y', strtotime($patient['birth_date'])) ?></td>
                                <td><?= $patient['sex'] === 'M' ? 'Masculino' : 'Feminino' ?></td>
                                <td><?= $patient['city'] ?>/<?= $patient['state'] ?></td>
                                <td><?= $patient['trip_count'] ?></td>
                                <td><?= $patient['bpa_records_count'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
