<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/

require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Adicionar novo CID
        if ($_POST['action'] === 'add') {
            $code = $_POST['code'];
            $description = $_POST['description'];
            
            $stmt = $conn->prepare("
                INSERT INTO cid10 (code, description)
                VALUES (?, ?)
            ");
            $stmt->bind_param("ss", $code, $description);
            
            if ($stmt->execute()) {
                $message = "CID adicionado com sucesso.";
            } else {
                $error = "Erro ao adicionar CID: " . $conn->error;
            }
            $stmt->close();
        }
        // Editar CID
        else if ($_POST['action'] === 'edit' && isset($_POST['id'])) {
            $id = $_POST['id'];
            $code = $_POST['code'];
            $description = $_POST['description'];
            
            $stmt = $conn->prepare("
                UPDATE cid10 
                SET code = ?, description = ?
                WHERE id = ?
            ");
            $stmt->bind_param("ssi", $code, $description, $id);
            
            if ($stmt->execute()) {
                $message = "CID atualizado com sucesso.";
            } else {
                $error = "Erro ao atualizar CID: " . $conn->error;
            }
            $stmt->close();
        }
        // Excluir CID
        else if ($_POST['action'] === 'delete' && isset($_POST['id'])) {
            $id = $_POST['id'];
            
            // Verificar se o CID está em uso
            $check = $conn->prepare("SELECT COUNT(*) as count FROM trip_passengers WHERE cid_id = ?");
            $check->bind_param("i", $id);
            $check->execute();
            $result = $check->get_result();
            $count = $result->fetch_assoc()['count'];
            
            if ($count > 0) {
                $error = "Não é possível excluir este CID pois ele está associado a passageiros.";
            } else {
                $stmt = $conn->prepare("DELETE FROM cid10 WHERE id = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $message = "CID excluído com sucesso.";
                } else {
                    $error = "Erro ao excluir CID: " . $conn->error;
                }
                $stmt->close();
            }
        }
    }
}

// Definir ação
$action = $_GET['action'] ?? 'list';
$cid_id = $_GET['id'] ?? null;

// Obter dados para formulários
if ($action === 'edit' && $cid_id) {
    $stmt = $conn->prepare("SELECT * FROM cid10 WHERE id = ?");
    $stmt->bind_param("i", $cid_id);
    $stmt->execute();
    $cid = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$cid) {
        $error = "CID não encontrado.";
        $action = 'list';
    }
}

// Listar CIDs
if ($action === 'list') {
    // Definir paginação
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = 20;
    $offset = ($page - 1) * $limit;
    
    // Definir busca
    $search = $_GET['search'] ?? '';
    
    // Contar total de registros
    if (!empty($search)) {
        $stmt = $conn->prepare("SELECT COUNT(*) as total FROM cid10 WHERE code LIKE ? OR description LIKE ?");
        $search_param = "%$search%";
        $stmt->bind_param("ss", $search_param, $search_param);
        $stmt->execute();
    } else {
        $stmt = $conn->prepare("SELECT COUNT(*) as total FROM cid10");
        $stmt->execute();
    }
    
    $total = $stmt->get_result()->fetch_assoc()['total'];
    $total_pages = ceil($total / $limit);
    
    // Buscar registros
    if (!empty($search)) {
        $stmt = $conn->prepare("
            SELECT * FROM cid10 
            WHERE code LIKE ? OR description LIKE ? 
            ORDER BY code 
            LIMIT ? OFFSET ?
        ");
        $search_param = "%$search%";
        $stmt->bind_param("ssii", $search_param, $search_param, $limit, $offset);
    } else {
        $stmt = $conn->prepare("
            SELECT * FROM cid10 
            ORDER BY code 
            LIMIT ? OFFSET ?
        ");
        $stmt->bind_param("ii", $limit, $offset);
    }
    
    $stmt->execute();
    $cids = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <?php if ($action === 'add'): ?>
            <i class="fas fa-plus-circle me-2"></i>Novo CID-10
        <?php elseif ($action === 'edit'): ?>
            <i class="fas fa-edit me-2"></i>Editar CID-10
        <?php else: ?>
            <i class="fas fa-notes-medical me-2"></i>Gerenciamento de CID-10
        <?php endif; ?>
    </h1>
    
    <?php if ($action === 'list'): ?>
        <a href="?action=add" class="btn btn-sm btn-success">
            <i class="fas fa-plus me-1"></i> Novo CID-10
        </a>
    <?php else: ?>
        <a href="cid10.php" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    <?php endif; ?>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($action === 'add' || $action === 'edit'): ?>
    <!-- Formulário de CID -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <?= $action === 'add' ? 'Novo CID-10' : 'Editar CID-10' ?>
            </h6>
        </div>
        <div class="card-body">
            <form method="post" action="cid10.php">
                <input type="hidden" name="action" value="<?= $action ?>">
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="id" value="<?= $cid['id'] ?>">
                <?php endif; ?>
                
                <div class="row mb-3">
                    <div class="col-md-3">
                        <label for="code" class="form-label">Código CID-10*</label>
                        <input type="text" class="form-control" id="code" name="code" required 
                               value="<?= $action === 'edit' ? $cid['code'] : '' ?>" 
                               placeholder="Ex: A00.0" maxlength="6">
                    </div>
                    <div class="col-md-9">
                        <label for="description" class="form-label">Descrição*</label>
                        <input type="text" class="form-control" id="description" name="description" required 
                               value="<?= $action === 'edit' ? $cid['description'] : '' ?>" 
                               placeholder="Descrição do CID">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-12">
                        <!-- Active field removed as it doesn't exist in the database -->
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Salvar
                    </button>
                    <a href="cid10.php" class="btn btn-secondary ms-2">
                        <i class="fas fa-times me-1"></i> Cancelar
                    </a>
                </div>
            </form>
        </div>
    </div>
<?php else: ?>
    <!-- Lista de CIDs -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">CID-10 Cadastrados</h6>
        </div>
        <div class="card-body">
            <!-- Busca -->
            <form method="get" class="mb-4">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Buscar por código ou descrição" value="<?= $search ?>">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                            <?php if (!empty($search)): ?>
                                <a href="cid10.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-times"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </form>
            
            <?php if (empty($cids)): ?>
                <div class="alert alert-info">
                    <?php if (!empty($search)): ?>
                        Nenhum CID encontrado com o termo "<?= $search ?>". <a href="cid10.php" class="alert-link">Limpar busca</a>.
                    <?php else: ?>
                        Nenhum CID cadastrado. <a href="?action=add" class="alert-link">Cadastrar novo CID</a>.
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Descrição</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cids as $cid): ?>
                                <tr>
                                    <td><?= $cid['code'] ?></td>
                                    <td><?= $cid['description'] ?></td>
                                    <td>
                                        <a href="?action=edit&id=<?= $cid['id'] ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-danger" 
                                                data-bs-toggle="modal" data-bs-target="#deleteModal<?= $cid['id'] ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        
                                        <!-- Modal de Confirmação de Exclusão -->
                                        <div class="modal fade" id="deleteModal<?= $cid['id'] ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Confirmar Exclusão</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Tem certeza que deseja excluir o CID <strong><?= $cid['code'] ?> - <?= $cid['description'] ?></strong>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                                        <form method="post" action="cid10.php">
                                                            <input type="hidden" name="action" value="delete">
                                                            <input type="hidden" name="id" value="<?= $cid['id'] ?>">
                                                            <button type="submit" class="btn btn-danger">Excluir</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Paginação -->
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Navegação de página">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $page - 1 ?><?= !empty($search) ? '&search=' . $search : '' ?>">Anterior</a>
                            </li>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <?php if ($i == 1 || $i == $total_pages || ($i >= $page - 2 && $i <= $page + 2)): ?>
                                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                        <a class="page-link" href="?page=<?= $i ?><?= !empty($search) ? '&search=' . $search : '' ?>"><?= $i ?></a>
                                    </li>
                                <?php elseif ($i == $page - 3 || $i == $page + 3): ?>
                                    <li class="page-item disabled">
                                        <span class="page-link">...</span>
                                    </li>
                                <?php endif; ?>
                            <?php endfor; ?>
                            
                            <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $page + 1 ?><?= !empty($search) ? '&search=' . $search : '' ?>">Próxima</a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
