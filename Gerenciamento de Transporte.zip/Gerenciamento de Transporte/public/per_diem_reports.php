<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
require_once '../config/database_transp.php';

// Iniciar buffer de saída
ob_start();

require_once 'includes/header.php';

// Verificar login
requireLogin();

$conn = connectMySQL();
$message = '';
$error = '';

// Processar ações
$action = $_GET['action'] ?? 'list';
$driver_id = $_GET['driver_id'] ?? null;
$month = $_GET['month'] ?? date('Y-m');

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Marcar diárias como pagas
        if ($_POST['action'] === 'mark_paid' && isset($_POST['per_diem_ids'])) {
            $ids = $_POST['per_diem_ids'];
            $payment_date = date('Y-m-d');
            
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $types = str_repeat('i', count($ids));
            
            $stmt = $conn->prepare("UPDATE driver_per_diems SET payment_status = 'paid', payment_date = ? WHERE id IN ($placeholders)");
            $params = array_merge([$payment_date], $ids);
            $stmt->bind_param('s' . $types, ...$params);
            
            if ($stmt->execute()) {
                $message = "Diárias marcadas como pagas com sucesso.";
            } else {
                $error = "Erro ao atualizar status de pagamento: " . $conn->error;
            }
            $stmt->close();
        }
    }
}

// Obter motoristas
$drivers = $conn->query("SELECT id, name FROM drivers WHERE active = 1 ORDER BY name")->fetch_all(MYSQLI_ASSOC);

// Ação específica
if ($action === 'view' && $driver_id && $month) {
    // Obter detalhes do motorista
    $stmt = $conn->prepare("SELECT * FROM drivers WHERE id = ?");
    $stmt->bind_param("i", $driver_id);
    $stmt->execute();
    $driver = $stmt->get_result()->fetch_assoc();
    
    // Obter diárias do motorista no mês selecionado
    $start_date = $month . '-01';
    $end_date = date('Y-m-t', strtotime($start_date));
    
    $stmt = $conn->prepare("
        SELECT pd.*, t.trip_date, t.departure_time, l.name as location_name, l.city as location_city, l.distance
        FROM driver_per_diems pd
        JOIN trips t ON pd.trip_id = t.id
        JOIN locations l ON t.location_id = l.id
        WHERE pd.driver_id = ? AND t.trip_date BETWEEN ? AND ?
        ORDER BY t.trip_date, t.departure_time
    ");
    $stmt->bind_param("iss", $driver_id, $start_date, $end_date);
    $stmt->execute();
    $per_diems = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Calcular totais
    $total_amount = 0;
    $total_paid = 0;
    $total_pending = 0;
    
    foreach ($per_diems as $pd) {
        $total_amount += $pd['amount'];
        if ($pd['payment_status'] === 'paid') {
            $total_paid += $pd['amount'];
        } else {
            $total_pending += $pd['amount'];
        }
    }
} else {
    // Obter resumo de diárias por motorista
    $result = $conn->query("
        SELECT 
            d.id, 
            d.name,
            COUNT(pd.id) as trip_count,
            SUM(pd.amount) as total_amount,
            SUM(CASE WHEN pd.payment_status = 'paid' THEN pd.amount ELSE 0 END) as paid_amount,
            SUM(CASE WHEN pd.payment_status = 'pending' THEN pd.amount ELSE 0 END) as pending_amount
        FROM drivers d
        LEFT JOIN driver_per_diems pd ON d.id = pd.driver_id
        WHERE d.active = 1
        GROUP BY d.id
        ORDER BY d.name
    ");
    $driver_summary = $result->fetch_all(MYSQLI_ASSOC);
}

$conn->close();
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <?php if ($action === 'view'): ?>
            <i class="fas fa-file-invoice-dollar me-2"></i>Relatório de Diárias - <?= htmlspecialchars($driver['name']) ?>
        <?php else: ?>
            <i class="fas fa-file-invoice-dollar me-2"></i>Relatórios de Diárias
        <?php endif; ?>
    </h1>
    
    <?php if ($action === 'view'): ?>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a href="per_diem_reports.php" class="btn btn-sm btn-outline-secondary">
                <i class="fas fa-arrow-left me-1"></i> Voltar
            </a>
            <button type="button" class="btn btn-sm btn-outline-primary ms-2" onclick="window.print();">
                <i class="fas fa-print me-1"></i> Imprimir
            </button>
        </div>
    <?php endif; ?>
</div>

<?php if ($message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $message ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= $error ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<?php if ($action === 'view'): ?>
    <!-- Relatório de Diárias do Motorista -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">
                Diárias de <?= htmlspecialchars($driver['name']) ?> - <?= date('F Y', strtotime($month)) ?>
            </h6>
            <form class="d-flex align-items-center">
                <input type="hidden" name="action" value="view">
                <input type="hidden" name="driver_id" value="<?= $driver_id ?>">
                <label for="month" class="me-2">Mês:</label>
                <input type="month" id="month" name="month" class="form-control form-control-sm" value="<?= $month ?>" onchange="this.form.submit()">
            </form>
        </div>
        <div class="card-body">
            <?php if (count($per_diems) > 0): ?>
                <form method="post">
                    <input type="hidden" name="action" value="mark_paid">
                    
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="select-all">
                                            <label class="form-check-label" for="select-all"></label>
                                        </div>
                                    </th>
                                    <th>Data</th>
                                    <th>Destino</th>
                                    <th>Distância</th>
                                    <th>Tipo de Diária</th>
                                    <th>Valor</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($per_diems as $pd): ?>
                                    <tr>
                                        <td>
                                            <?php if ($pd['payment_status'] === 'pending'): ?>
                                                <div class="form-check">
                                                    <input class="form-check-input per-diem-checkbox" type="checkbox" name="per_diem_ids[]" value="<?= $pd['id'] ?>">
                                                    <label class="form-check-label"></label>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= date('d/m/Y', strtotime($pd['trip_date'])) ?></td>
                                        <td><?= htmlspecialchars($pd['location_name']) ?> - <?= htmlspecialchars($pd['location_city']) ?></td>
                                        <td><?= $pd['distance'] ?> km</td>
                                        <td>
                                            <?php 
                                                if ($pd['per_diem_type'] === 'full_day') echo 'Diária Inteira';
                                                else if ($pd['per_diem_type'] === 'half_day') echo 'Meia Diária';
                                                else if ($pd['per_diem_type'] === 'short_trip') echo 'Viagem Próxima';
                                                else if ($pd['per_diem_type'] === 'long_trip') echo 'Viagem Distante';
                                            ?>
                                        </td>
                                        <td>R$ <?= number_format($pd['amount'], 2, ',', '.') ?></td>
                                        <td>
                                            <?php if ($pd['payment_status'] === 'paid'): ?>
                                                <span class="badge bg-success">Pago em <?= date('d/m/Y', strtotime($pd['payment_date'])) ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark">Pendente</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr class="table-secondary">
                                    <th colspan="5" class="text-end">Total:</th>
                                    <th>R$ <?= number_format($total_amount, 2, ',', '.') ?></th>
                                    <th></th>
                                </tr>
                                <tr>
                                    <th colspan="5" class="text-end">Pago:</th>
                                    <td>R$ <?= number_format($total_paid, 2, ',', '.') ?></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th colspan="5" class="text-end">Pendente:</th>
                                    <td>R$ <?= number_format($total_pending, 2, ',', '.') ?></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    
                    <?php if ($total_pending > 0): ?>
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-3">
                            <button type="submit" class="btn btn-success" id="mark-paid-btn" disabled>
                                <i class="fas fa-check me-1"></i> Marcar Selecionados como Pagos
                            </button>
                        </div>
                    <?php endif; ?>
                </form>
                
                <div class="mt-4 print-only">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Motorista:</strong> <?= htmlspecialchars($driver['name']) ?></p>
                            <p><strong>Documento:</strong> <?= htmlspecialchars($driver['document']) ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Período:</strong> <?= date('F Y', strtotime($month)) ?></p>
                            <p><strong>Total a Receber:</strong> R$ <?= number_format($total_pending, 2, ',', '.') ?></p>
                        </div>
                    </div>
                    
                    <div class="row mt-5">
                        <div class="col-md-6">
                            <div class="border-top pt-2">
                                Assinatura do Motorista
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="border-top pt-2">
                                Assinatura do Responsável
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    Nenhuma diária registrada para este motorista no período selecionado.
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php else: ?>
    <!-- Lista de Motoristas com Resumo de Diárias -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Resumo de Diárias por Motorista</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered datatable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Motorista</th>
                            <th>Viagens</th>
                            <th>Total</th>
                            <th>Pago</th>
                            <th>Pendente</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($driver_summary as $summary): ?>
                            <tr>
                                <td><?= htmlspecialchars($summary['name']) ?></td>
                                <td><?= $summary['trip_count'] ?: 0 ?></td>
                                <td>R$ <?= number_format($summary['total_amount'] ?: 0, 2, ',', '.') ?></td>
                                <td>R$ <?= number_format($summary['paid_amount'] ?: 0, 2, ',', '.') ?></td>
                                <td>R$ <?= number_format($summary['pending_amount'] ?: 0, 2, ',', '.') ?></td>
                                <td>
                                    <a href="?action=view&driver_id=<?= $summary['id'] ?>&month=<?= date('Y-m') ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-file-alt"></i> Ver Relatório
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>

<script>
    // Selecionar/deselecionar todos os checkboxes
    document.addEventListener('DOMContentLoaded', function() {
        const selectAllCheckbox = document.getElementById('select-all');
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', function() {
                const checkboxes = document.querySelectorAll('.per-diem-checkbox');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = selectAllCheckbox.checked;
                });
                updateMarkPaidButton();
            });
            
            // Atualizar botão quando checkboxes individuais são alterados
            const checkboxes = document.querySelectorAll('.per-diem-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', updateMarkPaidButton);
            });
            
            function updateMarkPaidButton() {
                const markPaidBtn = document.getElementById('mark-paid-btn');
                const checkedBoxes = document.querySelectorAll('.per-diem-checkbox:checked');
                markPaidBtn.disabled = checkedBoxes.length === 0;
            }
        }
    });
</script>

<style>
    @media print {
        .no-print, .dataTables_filter, .dataTables_length, .dataTables_paginate, .dataTables_info {
            display: none !important;
        }
        
        .print-only {
            display: block !important;
        }
        
        .card {
            border: none !important;
        }
        
        .card-header {
            background-color: white !important;
            border-bottom: 1px solid #000 !important;
        }
        
        .table-bordered {
            border: 1px solid #000 !important;
        }
        
        .table-bordered th, .table-bordered td {
            border: 1px solid #000 !important;
        }
    }
    
    .print-only {
        display: none;
    }
</style>

<?php require_once 'includes/footer.php'; ?>
