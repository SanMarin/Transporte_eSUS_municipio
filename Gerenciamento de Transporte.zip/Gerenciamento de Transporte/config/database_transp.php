<?php
/*
Sistema desenvolvido por Alexandre SanMarin.

Ferramenta destinada ao controle do transporte de pacientes da rede SUS, incluindo acompanhantes, garantindo organização, rastreabilidade e gestão completa das viagens.

Possui módulo de acesso exclusivo para motoristas, permitindo iniciar viagens, registrar etapas e acompanhar os valores de suas diárias.

Inclui módulo para geração de arquivos BPA-I, possibilitando o registro no SIA/SUS e contribuindo para o aumento do faturamento do município usuário.

Todas as funcionalidades foram desenvolvidas com foco no uso interno de cada município, sem requisitos avançados de segurança. A abertura de portas, configurações de rede ou qualquer exposição externa do sistema é de total responsabilidade do usuário ou da equipe técnica responsável pela implantação.

Temos também um sistema de indicadores para análise detalhada das informações provenientes do e-SUS PEC de cada município, oferecendo suporte estratégico para gestão e tomada de decisão.
Acompanhamento de todas as atividades dos ACS e equipe de enfermagem.

Para contato ou suporte: WhatsApp (14) 98807-4089.

Melhorias e ajustes são bem-vindos.
*/
// Configurações do banco de dados MySQL
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'bpa_transport_system');

// Configurações do banco de dados PostgreSQL (ESUS PEC)
define('PG_HOST', '192.168.1.1'); //ip do servidor esus
define('PG_PORT', '7903'); // porta do bd postgres
define('PG_USER', 'esus_leitura');
define('PG_PASS', 'Z0v1~ergegeyeryATCv_JF0a]'); //Senha do servidor e-sus
define('PG_NAME', 'esus');

// Função para conectar ao MySQL
function connectMySQL() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Falha na conexão com o banco de dados MySQL: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8");
    return $conn;
}

// Função para conectar ao PostgreSQL
function connectPostgreSQL() {
    $dsn = "pgsql:host=" . PG_HOST . ";port=" . PG_PORT . ";dbname=" . PG_NAME . ";";
    
    try {
        $pdo = new PDO($dsn, PG_USER, PG_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        return $pdo;
    } catch (PDOException $e) {
        die("Falha na conexão com o banco de dados PostgreSQL: " . $e->getMessage());
    }
}

// Função para buscar paciente no ESUS PEC por CNS
function fetchPatientFromESUS($cns) {
    try {
        $pdo = connectPostgreSQL();
        
        $sql = "SELECT DISTINCT ON (t3.co_fat_cidadao_pec)
                t1.no_cidadao AS name,
                t2.dt_nascimento AS birth_date,
                t1.co_dim_sexo AS sex,
                t3.co_dim_raca_cor AS race,
                t3.co_dim_etnia AS ethnicity,
                t3.co_dim_nacionalidade AS nationality,
                t3.co_dim_municipio_cidadao AS ibge_code,
                t2.ds_cep AS cep,
                t2.tp_logradouro AS address_type,
                t2.ds_logradouro AS address,
                t2.nu_numero AS address_number,
                t2.ds_complemento AS address_complement,                   
                t2.no_bairro AS neighborhood,
                t2.nu_telefone_celular AS phone,
                t3.no_email,
                UPPER(t11.ds_tipo_localizacao) AS ds_tipo_localizacao
                FROM tb_fat_cidadao_pec t1
                LEFT JOIN tb_cidadao t2 ON t1.co_cidadao = t2.co_seq_cidadao
                LEFT JOIN tb_fat_cad_individual t3 ON t2.co_unico_ultima_ficha = t3.nu_uuid_ficha
                LEFT JOIN tb_fat_cad_dom_familia t7 ON t7.co_fat_cidadao_pec = t1.co_seq_fat_cidadao_pec AND t7.st_mudou = 0
                LEFT JOIN tb_fat_cad_domiciliar t8 ON t7.co_fat_cad_domiciliar = t8.co_seq_fat_cad_domiciliar
                LEFT JOIN tb_cds_cad_domiciliar t9 ON t8.nu_uuid_ficha = t9.co_unico_ficha
                LEFT JOIN tb_cds_domicilio t10 ON t9.co_unico_ficha = t10.co_unico_ultima_ficha
                LEFT JOIN tb_dim_tipo_localizacao t11 ON t11.co_seq_dim_tipo_localizacao = t8.co_dim_tipo_localizacao
                LEFT JOIN tb_tipo_logradouro t12 ON t10.tp_logradouro = t12.co_tipo_logradouro
                WHERE t2.nu_cns = :cns
                LIMIT 1";
        //:cns
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':cns', $cns, PDO::PARAM_STR);
        $stmt->execute();
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            // Formatar os dados para o padrão do nosso sistema
            $result['sex'] = ($result['sex'] == 'MASCULINO') ? 'M' : 'F';
            
            // Converter data de nascimento para o formato correto
            //if (isset($result['birth_date'])) {
             //   $date = new DateTime($result['birth_date']);
            //    $result['birth_date'] = $date->format('Y-m-d');
            //}
            
            return $result;
        }
        
        return null;
    } catch (PDOException $e) {
        error_log("Erro ao buscar paciente no ESUS: " . $e->getMessage());
        return null;
    }
}
?>
